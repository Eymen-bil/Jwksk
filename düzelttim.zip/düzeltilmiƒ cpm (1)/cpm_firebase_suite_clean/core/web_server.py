# -*- coding: utf-8 -*-
"""
=============================================================================
🌐 CORE / LOCALHOST WEB SERVER & INTERACTIVE DASHBOARD (PRO EDITION - DÜZELTİLMİŞ)
=============================================================================
"""

import os
import json
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
import socket
from urllib.parse import parse_qs, urlparse

from .colors import C, p_header, p_success, p_info
from .config import RESULTS_DIR, load_session, get_active_id_token
from .auth import login_request, register_request, change_email_request, change_password_request
from .cpm import get_live_online_map, boost_account, get_all_cars, get_clan_info, save_player_records
from .security import check_sponge_device
from .valuator import valuate_account, parse_car_details


def find_latest_accounts_data():
    if os.path.exists("valid_accounts.json"):
        try:
            with open("valid_accounts.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list) and data:
                    return data
        except Exception:
            pass

    if os.path.exists(RESULTS_DIR):
        json_files = []
        for root, _, files in os.walk(RESULTS_DIR):
            for file in files:
                if file.endswith(".json") and "valid" in file:
                    json_files.append(os.path.join(root, file))
        if json_files:
            json_files.sort(key=os.path.getmtime, reverse=True)
            try:
                with open(json_files[0], "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    return []


class DashboardHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/accounts":
            accounts = find_latest_accounts_data()
            for a in accounts:
                val = valuate_account(a)
                a["valuation"] = val
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(accounts, ensure_ascii=False).encode("utf-8"))
            return

        elif path == "/api/stats":
            online_map, _ = get_live_online_map()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(online_map or {}, ensure_ascii=False).encode("utf-8"))
            return

        elif path == "/api/session":
            sess = load_session() or {}
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(sess, ensure_ascii=False).encode("utf-8"))
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(self.get_html_page().encode("utf-8"))

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        try:
            payload = json.loads(body)
        except Exception:
            payload = {}

        if path == "/api/garage":
            tok = payload.get("token") or get_active_id_token()
            cars, err = get_all_cars(tok)
            parsed_cars = [parse_car_details(c) for c in cars] if isinstance(cars, list) else []
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps({"cars": parsed_cars, "error": err}, ensure_ascii=False).encode("utf-8"))
            return

        elif path == "/api/change-email":
            tok = payload.get("token") or get_active_id_token()
            new_em = payload.get("new_email")
            cur_pw = payload.get("password")
            res, err = change_email_request(tok, new_em, current_password=cur_pw)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            if res and "email" in res:
                self.wfile.write(json.dumps({"success": True, "email": res["email"]}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": err}).encode("utf-8"))
            return

        elif path == "/api/change-password":
            tok = payload.get("token") or get_active_id_token()
            new_pw = payload.get("new_password")
            cur_pw = payload.get("password")
            res, err = change_password_request(tok, new_pw, current_password=cur_pw)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            if res and "idToken" in res:
                self.wfile.write(json.dumps({"success": True}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": err}).encode("utf-8"))
            return

        elif path == "/api/create-account":
            em = payload.get("email")
            pw = payload.get("password")
            res, err = register_request(em, pw)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            if res and "idToken" in res:
                self.wfile.write(json.dumps({"success": True, "email": res["email"], "uid": res.get("localId")}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": err}).encode("utf-8"))
            return

        elif path == "/api/boost":
            tok = payload.get("token") or get_active_id_token()
            coins = int(payload.get("coins", 50000))
            money = int(payload.get("money", 50000000))
            lvl = int(payload.get("level", 100))

            ok, msg = save_player_records(id_token=tok, hard_currency=coins, money=money, level=lvl)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            if ok:
                self.wfile.write(json.dumps({"success": True, "message": "Hesap güçlendirildi"}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": str(msg)}).encode("utf-8"))
            return

        elif path == "/api/sponge":
            dev_id = payload.get("device_id")
            res, err = check_sponge_device(dev_id)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(res or {"error": err}).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()

    def get_html_page(self):
        return """<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔥 CPM & Firebase Master Suite Pro Dashboard</title>
    <style>
        :root {
            --bg: #0b0f19;
            --card: #111827;
            --card-sub: #161e2e;
            --border: #1f2937;
            --text: #f9fafb;
            --text-dim: #9ca3af;
            --cyan: #06b6d4;
            --green: #10b981;
            --purple: #8b5cf6;
            --yellow: #f59e0b;
            --red: #ef4444;
            --blue: #3b82f6;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background-color: var(--bg); color: var(--text); padding: 24px; min-height: 100vh; }
        .container { max-width: 1440px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border); }
        .brand h1 { font-size: 26px; font-weight: 800; background: linear-gradient(135deg, var(--cyan) 0%, var(--blue) 50%, var(--purple) 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; display: flex; align-items: center; gap: 10px; }
        .brand p { color: var(--text-dim); font-size: 13px; margin-top: 4px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background-color: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 18px; position: relative; overflow: hidden; }
        .stat-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: var(--cyan); }
        .stat-card.green::before { background: var(--green); }
        .stat-card.purple::before { background: var(--purple); }
        .stat-card.yellow::before { background: var(--yellow); }
        .stat-label { color: var(--text-dim); font-size: 12px; text-transform: uppercase; font-weight: 700; margin-bottom: 8px; }
        .stat-val { font-size: 26px; font-weight: 800; }
        .filter-bar { background-color: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px; }
        .search-box { flex: 1; min-width: 280px; }
        .search-input { width: 100%; background-color: #0b0f19; border: 1px solid #374151; border-radius: 8px; padding: 10px 14px; color: #fff; font-size: 14px; outline: none; transition: border-color 0.2s; }
        .search-input:focus { border-color: var(--cyan); }
        .pill-group { display: flex; gap: 8px; flex-wrap: wrap; }
        .pill { background-color: #1f2937; color: var(--text-dim); border: 1px solid #374151; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .pill.active { background-color: var(--cyan); color: #0b0f19; border-color: var(--cyan); }
        .table-card { background-color: var(--card); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
        th { background-color: #161e2e; color: var(--text-dim); font-weight: 700; padding: 12px 16px; border-bottom: 1px solid var(--border); text-transform: uppercase; font-size: 11px; }
        td { padding: 14px 16px; border-bottom: 1px solid #1f2937; vertical-align: middle; }
        tr:hover td { background-color: #161e2e; }
        .badge { display: inline-flex; align-items: center; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }
        .badge-green { background-color: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
        .badge-cyan { background-color: rgba(6, 182, 212, 0.15); color: #22d3ee; border: 1px solid rgba(6, 182, 212, 0.3); }
        .badge-purple { background-color: rgba(139, 92, 246, 0.15); color: #a78bfa; border: 1px solid rgba(139, 92, 246, 0.3); }
        .badge-yellow { background-color: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
        .badge-red { background-color: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
        .btn { background-color: #1f2937; color: #fff; border: 1px solid #374151; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s; display: inline-flex; align-items: center; gap: 6px; }
        .btn:hover { background-color: #374151; }
        .btn-green { background: linear-gradient(135deg, var(--green) 0%, #059669 100%); border: none; }
        .btn-primary { background: linear-gradient(135deg, var(--cyan) 0%, var(--blue) 100%); border: none; }
        .btn-purple { background: linear-gradient(135deg, var(--purple) 0%, #6d28d9 100%); border: none; }
        .code-box { font-family: monospace; background-color: #0b0f19; padding: 4px 8px; border-radius: 4px; display: inline-flex; align-items: center; gap: 6px; }
        .copy-btn { background: none; border: none; color: var(--text-dim); cursor: pointer; font-size: 12px; }
        .copy-btn:hover { color: var(--cyan); }
        #toast { position: fixed; bottom: 24px; right: 24px; background: var(--green); color: #fff; padding: 10px 18px; border-radius: 8px; font-size: 13px; font-weight: 600; display: none; z-index: 9999; box-shadow: 0 4px 12px rgba(0,0,0,0.5); }
        .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.75); display: none; justify-content: center; align-items: center; z-index: 1000; padding: 20px; }
        .modal-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; max-width: 800px; width: 100%; max-height: 85vh; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5); }
        .modal-head { padding: 18px 24px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
        .modal-head h2 { font-size: 18px; font-weight: 800; color: var(--text); }
        .modal-body { padding: 20px 24px; overflow-y: auto; flex: 1; }
        .modal-foot { padding: 14px 24px; border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 10px; }
        .garage-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; }
        .car-item { background: var(--card-sub); border: 1px solid var(--border); border-radius: 10px; padding: 12px; display: flex; flex-direction: column; gap: 6px; }
        .car-title { font-weight: 700; font-size: 13px; color: var(--cyan); }
        .input-group { margin-bottom: 14px; }
        .input-group label { display: block; font-size: 12px; color: var(--text-dim); margin-bottom: 6px; font-weight: 600; }
        .input-group input { width: 100%; background: #0b0f19; border: 1px solid #374151; border-radius: 8px; padding: 10px 14px; color: #fff; font-size: 13px; outline: none; }
        .input-group input:focus { border-color: var(--cyan); }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="brand">
                <h1>🔥 CPM & Firebase Master Suite Pro Paneli</h1>
                <p id="onlineStatus">🌐 Canlı Sunucu Durumu: Yükleniyor...</p>
            </div>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="btn btn-purple" onclick="openCreateModal()">➕ Yeni Hesap Oluştur</button>
                <button class="btn btn-green" onclick="copyAllAccounts()">📋 Tüm Hesapları Kopyala</button>
                <button class="btn btn-primary" onclick="exportFilteredJSON()">💾 Filtrelenenleri İndir</button>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card green">
                <div class="stat-label">Toplam Geçerli Hesap</div>
                <div class="stat-val" id="statValid">0</div>
            </div>
            <div class="stat-card purple">
                <div class="stat-label">👑 Tahmini Portföy Değeri</div>
                <div class="stat-val" id="statValuation">0 ₺</div>
            </div>
            <div class="stat-card yellow">
                <div class="stat-label">🚗 Toplam Araç Sayısı</div>
                <div class="stat-val" id="statCars">0</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">💎 VIP Ultra (150+ Araç)</div>
                <div class="stat-val" id="statVip">0</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">🌐 Canlı Oyuncu Sayısı</div>
                <div class="stat-val" id="statOnline">0</div>
            </div>
        </div>

        <div class="filter-bar">
            <div class="search-box">
                <input type="text" id="searchInput" class="search-input" placeholder="🔍 E-posta, UID, Seviye, Plaka veya Araç ID ara..." onkeyup="filterTable()">
            </div>
            <div class="pill-group">
                <button class="pill active" onclick="setFilter('all', this)">Tümü</button>
                <button class="pill" onclick="setFilter('god', this)">💎 God Tier</button>
                <button class="pill" onclick="setFilter('vip', this)">👑 VIP Ultra (150+)</button>
                <button class="pill" onclick="setFilter('clan', this)">👥 Klan Üyeleri</button>
                <button class="pill" onclick="setFilter('clean', this)">🛡️ 0 Şikayet (Temiz)</button>
            </div>
        </div>

        <div class="table-card">
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Hesap (E-Posta : Şifre)</th>
                            <th>Seviye</th>
                            <th>Toplam Araç</th>
                            <th>Değerleme & Puan</th>
                            <th>Klan</th>
                            <th>Kayıt Tarihi</th>
                            <th>İşlemler & Garaj</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="garageModal" class="modal-overlay">
        <div class="modal-card">
            <div class="modal-head">
                <h2 id="garageModalTitle">🏎️ Garaj Araçları</h2>
                <button class="btn" onclick="closeModal('garageModal')">✕</button>
            </div>
            <div class="modal-body" id="garageModalBody">
                <div class="garage-grid" id="garageGrid"></div>
            </div>
            <div class="modal-foot">
                <button class="btn btn-primary" onclick="closeModal('garageModal')">Kapat</button>
            </div>
        </div>
    </div>

    <div id="securityModal" class="modal-overlay">
        <div class="modal-card" style="max-width: 500px;">
            <div class="modal-head">
                <h2>🔐 Hesap Güvenliği & Güncelleme</h2>
                <button class="btn" onclick="closeModal('securityModal')">✕</button>
            </div>
            <div class="modal-body">
                <div class="input-group">
                    <label>Mevcut Şifre (Gerekliyse):</label>
                    <input type="password" id="secCurrentPassword" placeholder="Mevcut Şifre">
                </div>
                <div class="input-group">
                    <label>Yeni E-Posta Adresi:</label>
                    <input type="email" id="secNewEmail" placeholder="yeni_mail@gmail.com">
                </div>
                <div class="input-group">
                    <label>Yeni Şifre:</label>
                    <input type="password" id="secNewPassword" placeholder="Yeni Güçlü Şifre">
                </div>
                <input type="hidden" id="secToken">
            </div>
            <div class="modal-foot">
                <button class="btn btn-green" onclick="submitEmailChange()">📧 Maili Değiştir</button>
                <button class="btn btn-purple" onclick="submitPasswordChange()">🔑 Şifreyi Değiştir</button>
                <button class="btn" onclick="closeModal('securityModal')">İptal</button>
            </div>
        </div>
    </div>

    <div id="createModal" class="modal-overlay">
        <div class="modal-card" style="max-width: 480px;">
            <div class="modal-head">
                <h2>➕ Yeni CPM Hesabı Aç</h2>
                <button class="btn" onclick="closeModal('createModal')">✕</button>
            </div>
            <div class="modal-body">
                <div class="input-group">
                    <label>E-Posta:</label>
                    <input type="email" id="createEmail" placeholder="hesap@gmail.com">
                </div>
                <div class="input-group">
                    <label>Şifre:</label>
                    <input type="password" id="createPassword" placeholder="GucluSifre123!">
                </div>
            </div>
            <div class="modal-foot">
                <button class="btn btn-green" onclick="submitCreateAccount()">🚀 Hesabı Aç</button>
                <button class="btn" onclick="closeModal('createModal')">İptal</button>
            </div>
        </div>
    </div>

    <div id="toast">Kopyalandı!</div>

    <script>
        let rawAccounts = [];
        let currentFilter = 'all';

        async function initData() {
            try {
                const res = await fetch('/api/accounts');
                rawAccounts = await res.json();
                renderStats();
                renderTable(rawAccounts);
            } catch (e) {
                console.error(e);
            }

            try {
                const sRes = await fetch('/api/stats');
                const sData = await sRes.json();
                if (sData && sData.total_online) {
                    document.getElementById('onlineStatus').innerText = `🌐 Canlı Sunucu: ${sData.total_online.toLocaleString()} oyuncu aktif`;
                    document.getElementById('statOnline').innerText = sData.total_online.toLocaleString();
                }
            } catch (e) {}
        }

        function renderStats() {
            document.getElementById('statValid').innerText = rawAccounts.length;
            const totalCars = rawAccounts.reduce((sum, a) => sum + (a.cpm_total_cars || 0), 0);
            const totalVal = rawAccounts.reduce((sum, a) => sum + ((a.valuation && a.valuation.estimated_tl) || 0), 0);
            const vipCount = rawAccounts.filter(a => (a.cpm_total_cars || 0) >= 150).length;

            document.getElementById('statCars').innerText = totalCars.toLocaleString();
            document.getElementById('statValuation').innerText = totalVal.toLocaleString() + ' ₺';
            document.getElementById('statVip').innerText = vipCount;
        }

        function renderTable(data) {
            const tbody = document.getElementById('tableBody');
            tbody.innerHTML = '';

            data.forEach((acc, idx) => {
                const cars = acc.cpm_total_cars || 0;
                const unl = acc.cpm_unlocked_cars || 0;
                const cust = acc.cpm_custom_cars || (acc.cpm_cars ? acc.cpm_cars.length : 0);
                const lvl = acc.cpm_level !== null && acc.cpm_level !== undefined ? acc.cpm_level : '-';

                const val = acc.valuation || {};
                const valTier = val.valuation_tier || '🥉 BRONZE';
                const estTl = (val.estimated_tl || 0).toLocaleString() + ' ₺';

                let badgeClass = 'badge-cyan';
                if (valTier.includes('MYTHIC') || valTier.includes('GOD')) badgeClass = 'badge-purple';
                else if (valTier.includes('VIP ULTRA') || valTier.includes('GOLD')) badgeClass = 'badge-yellow';

                const clanBadge = acc.cpm_clan_id ? `<span class="badge badge-purple">ID: ${acc.cpm_clan_id}</span>` : '<span style="color: #6b7280;">-</span>';
                const prof = acc.firebase_profile || {};
                const created = prof.createdAt ? prof.createdAt.split(' ')[0] : '-';

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong>#${idx + 1}</strong></td>
                    <td>
                        <div class="code-box">
                            <span>${acc.email} : ${acc.password}</span>
                            <button class="copy-btn" onclick="copyText('${acc.email}:${acc.password}')" title="Hesabı Kopyala">📋</button>
                        </div>
                    </td>
                    <td><span class="badge badge-green">Lv. ${lvl}</span></td>
                    <td>
                        <strong>${cars}</strong> adet
                        <div style="font-size: 11px; color: #9ca3af;">Açık: ${unl} | Garaj: ${cust}</div>
                    </td>
                    <td>
                        <span class="badge ${badgeClass}">${valTier}</span>
                        <div style="font-size: 11px; color: #10b981; font-weight: 700; margin-top: 2px;">Tahmini: ${estTl}</div>
                    </td>
                    <td>${clanBadge}</td>
                    <td style="font-size: 12px; color: #9ca3af;">${created}</td>
                    <td>
                        <div style="display: flex; gap: 6px;">
                            <button class="btn btn-primary" style="padding: 4px 8px; font-size: 11px;" onclick="viewGarage('${acc.idToken || ''}', '${acc.email}')">🏎️ Garaj</button>
                            <button class="btn" style="padding: 4px 8px; font-size: 11px;" onclick="openSecurityModal('${acc.idToken || ''}', '${acc.email}', '${acc.password}')">⚙️ Güvenlik</button>
                        </div>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        async function viewGarage(token, email) {
            document.getElementById('garageModalTitle').innerText = `🏎️ Garaj Detayı: ${email}`;
            const grid = document.getElementById('garageGrid');
            grid.innerHTML = '<div style="color: var(--text-dim);">Garaj arabaları yükleniyor...</div>';
            openModal('garageModal');

            try {
                const res = await fetch('/api/garage', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token: token })
                });
                const data = await res.json();
                grid.innerHTML = '';
                if (data.cars && data.cars.length > 0) {
                    data.cars.forEach((c, i) => {
                        const div = document.createElement('div');
                        div.className = 'car-item';
                        const sirenBadge = c.has_police ? '<span class="badge badge-green">🚨 Siren VAR</span>' : '<span class="badge" style="background:#1f2937; color:#6b7280;">Siren Yok</span>';
                        const vinylBadge = c.has_vinyl ? '<span class="badge badge-purple">🎨 Çizim VAR</span>' : '<span class="badge" style="background:#1f2937; color:#6b7280;">Çizim Yok</span>';
                        const plateBadge = c.license_plate ? `<span class="badge badge-yellow">🏷️ ${c.license_plate}</span>` : '';
                        div.innerHTML = `
                            <div class="car-title">#${i+1} ${c.name}</div>
                            <div style="font-size: 11px; color: var(--text-dim);">ID: ${c.car_id} | Kategori: ${c.tier}</div>
                            <div style="display: flex; gap: 4px; flex-wrap: wrap; margin-top: 4px;">
                                ${sirenBadge}
                                ${vinylBadge}
                                ${plateBadge}
                            </div>
                        `;
                        grid.appendChild(div);
                    });
                } else {
                    grid.innerHTML = '<div style="color: var(--text-dim);">Garajda kayıtlı araç bulunamadı.</div>';
                }
            } catch (e) {
                grid.innerHTML = '<div style="color: var(--red);">Garaj yüklenirken hata oluştu.</div>';
            }
        }

        function openSecurityModal(token, email, password) {
            document.getElementById('secToken').value = token;
            document.getElementById('secCurrentPassword').value = password || '';
            document.getElementById('secNewEmail').value = '';
            document.getElementById('secNewPassword').value = '';
            openModal('securityModal');
        }

        function openCreateModal() {
            document.getElementById('createEmail').value = '';
            document.getElementById('createPassword').value = '';
            openModal('createModal');
        }

        async function submitEmailChange() {
            const tok = document.getElementById('secToken').value;
            const newEm = document.getElementById('secNewEmail').value.trim();
            const curPw = document.getElementById('secCurrentPassword').value.trim();

            if (!newEm) { alert('Lütfen yeni bir e-posta adresi yazın.'); return; }

            const res = await fetch('/api/change-email', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: tok, new_email: newEm, password: curPw })
            });
            const data = await res.json();
            if (data.success) {
                showToast('E-posta başarıyla değiştirildi!');
                closeModal('securityModal');
                initData();
            } else {
                alert('Hata: ' + (data.error || 'E-posta değiştirilemedi.'));
            }
        }

        async function submitPasswordChange() {
            const tok = document.getElementById('secToken').value;
            const newPw = document.getElementById('secNewPassword').value.trim();
            const curPw = document.getElementById('secCurrentPassword').value.trim();

            if (!newPw) { alert('Lütfen yeni bir şifre yazın.'); return; }

            const res = await fetch('/api/change-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: tok, new_password: newPw, password: curPw })
            });
            const data = await res.json();
            if (data.success) {
                showToast('Şifre başarıyla güncellendi!');
                closeModal('securityModal');
                initData();
            } else {
                alert('Hata: ' + (data.error || 'Şifre güncellenemedi.'));
            }
        }

        async function submitCreateAccount() {
            const em = document.getElementById('createEmail').value.trim();
            const pw = document.getElementById('createPassword').value.trim();

            if (!em || !pw) { alert('E-posta ve şifre zorunludur.'); return; }

            const res = await fetch('/api/create-account', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: em, password: pw })
            });
            const data = await res.json();
            if (data.success) {
                showToast('Yeni hesap başarıyla açıldı!');
                closeModal('createModal');
                initData();
            } else {
                alert('Kayıt Hatası: ' + (data.error || 'Hesap açılamadı.'));
            }
        }

        function openModal(id) { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }

        function showToast(msg) {
            const t = document.getElementById('toast');
            t.innerText = msg;
            t.style.display = 'block';
            setTimeout(() => { t.style.display = 'none'; }, 2500);
        }

        function copyText(text) {
            if (!text) return;
            navigator.clipboard.writeText(text).then(() => { showToast('Kopyalandı!'); });
        }

        function copyAllAccounts() {
            const txt = rawAccounts.map(a => `${a.email}:${a.password}`).join('\\n');
            copyText(txt);
        }

        function exportFilteredJSON() {
            const query = document.getElementById('searchInput').value.toLowerCase();
            const filtered = rawAccounts.filter(a => {
                const matchSearch = JSON.stringify(a).toLowerCase().includes(query);
                if (!matchSearch) return false;
                if (currentFilter === 'god') return (a.valuation && a.valuation.valuation_tier && a.valuation.valuation_tier.includes('GOD'));
                if (currentFilter === 'vip') return (a.cpm_total_cars || 0) >= 150;
                if (currentFilter === 'clan') return !!a.cpm_clan_id;
                if (currentFilter === 'clean') return (a.cpm_reports || 0) === 0;
                return true;
            });

            const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `cpm_accounts_${Date.now()}.json`;
            a.click();
        }

        function setFilter(type, el) {
            document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
            el.classList.add('active');
            currentFilter = type;
            filterTable();
        }

        function filterTable() {
            const query = document.getElementById('searchInput').value.toLowerCase();
            const filtered = rawAccounts.filter(a => {
                const matchSearch = JSON.stringify(a).toLowerCase().includes(query);
                if (!matchSearch) return false;
                if (currentFilter === 'god') return (a.valuation && a.valuation.valuation_tier && a.valuation.valuation_tier.includes('GOD'));
                if (currentFilter === 'vip') return (a.cpm_total_cars || 0) >= 150;
                if (currentFilter === 'clan') return !!a.cpm_clan_id;
                if (currentFilter === 'clean') return (a.cpm_reports || 0) === 0;
                return true;
            });
            renderTable(filtered);
        }

        initData();
    </script>
</body>
</html>"""


def start_local_web_dashboard(port=5000, auto_open=True):
    server_address = ("127.0.0.1", port)
    try:
        httpd = HTTPServer(server_address, DashboardHandler)
    except OSError:
        port += 1
        server_address = ("127.0.0.1", port)
        httpd = HTTPServer(server_address, DashboardHandler)

    url = f"http://127.0.0.1:{port}"
    p_header(f"🌐 LOCALHOST WEB DASHBOARD BAŞLATILDI")
    print(f"  {C.BOLD}Panel Adresi{C.RESET} : {C.GREEN}{C.BOLD}{url}{C.RESET}")
    print(f"  {C.DIM}Durdurmak için Ctrl+C tuşlarına basın.{C.RESET}\n")

    if auto_open:
        try:
            webbrowser.open(url)
        except Exception:
            pass

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        p_info("\nWeb sunucusu durduruldu.")
        httpd.server_close()