# -*- coding: utf-8 -*-
"""
=============================================================================
🔐 CORE / FIREBASE AUTH OPERATIONS (TAM SÜRÜM)
=============================================================================
"""

import os
import json
import uuid
import random
import time
from .colors import C, p_header, p_success, p_warn, p_error
from .config import Config, SESSION_FILE, save_session, load_session, get_active_id_token
from .http import http_request, format_timestamp
from .jwt_utils import decode_jwt


def login_request(email, password, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}"
    payload = {"email": email, "password": password, "returnSecureToken": True}
    return http_request(url, method="POST", payload=payload)


def register_request(email, password, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={key}"
    payload = {"email": email, "password": password, "returnSecureToken": True}
    return http_request(url, method="POST", payload=payload)


def anonymous_login_request(api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={key}"
    payload = {"returnSecureToken": True}
    return http_request(url, method="POST", payload=payload)


def send_password_reset_request(email, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={key}"
    payload = {"requestType": "PASSWORD_RESET", "email": email}
    return http_request(url, method="POST", payload=payload)


def send_email_verification_request(id_token, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={key}"
    payload = {"requestType": "VERIFY_EMAIL", "idToken": id_token}
    return http_request(url, method="POST", payload=payload)


def update_profile_request(id_token, display_name=None, photo_url=None, delete_attrs=None, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={key}"
    payload = {"idToken": id_token, "returnSecureToken": True}
    if display_name is not None:
        payload["displayName"] = display_name
    if photo_url is not None:
        payload["photoUrl"] = photo_url
    if delete_attrs:
        payload["deleteAttribute"] = delete_attrs
    return http_request(url, method="POST", payload=payload)


def change_email_request(id_token, new_email, current_password=None, api_key=None):
    key = api_key or Config.get_api_key()
    tok = id_token

    if current_password and not tok:
        sess = load_session()
        c_em = sess.get("email") if sess else None
        if c_em:
            r_log, _ = login_request(c_em, current_password, api_key=key)
            if r_log and "idToken" in r_log:
                tok = r_log["idToken"]

    if not tok:
        return None, "idToken bulunamadı ve giriş yapılamadı"

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={key}"
    payload = {"idToken": tok, "email": new_email, "returnSecureToken": True}
    res, err = http_request(url, method="POST", payload=payload)
    if res and "idToken" in res:
        sess = load_session() or {}
        sess["email"] = res.get("email", new_email)
        sess["idToken"] = res.get("idToken")
        sess["refreshToken"] = res.get("refreshToken", sess.get("refreshToken"))
        save_session(sess)
    return res, err


def change_password_request(id_token, new_password, current_password=None, api_key=None):
    key = api_key or Config.get_api_key()
    tok = id_token

    if current_password and not tok:
        sess = load_session()
        c_em = sess.get("email") if sess else None
        if c_em:
            r_log, _ = login_request(c_em, current_password, api_key=key)
            if r_log and "idToken" in r_log:
                tok = r_log["idToken"]

    if not tok:
        return None, "idToken bulunamadı ve giriş yapılamadı"

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={key}"
    payload = {"idToken": tok, "password": new_password, "returnSecureToken": True}
    res, err = http_request(url, method="POST", payload=payload)
    if res and "idToken" in res:
        sess = load_session() or {}
        sess["idToken"] = res.get("idToken")
        sess["refreshToken"] = res.get("refreshToken", sess.get("refreshToken"))
        save_session(sess)
    return res, err


def lockdown_account(id_token, new_email, new_password, current_password=None, api_key=None):
    em_res, em_err = change_email_request(id_token, new_email, current_password=current_password, api_key=api_key)
    if em_err or not em_res or "idToken" not in em_res:
        return False, f"E-posta güncellenemedi: {em_err}"

    new_tok = em_res["idToken"]

    pw_res, pw_err = change_password_request(new_tok, new_password, api_key=api_key)
    if pw_err or not pw_res:
        return False, f"E-posta değişti ({new_email}) ancak şifre güncellenemedi: {pw_err}"

    send_email_verification_request(pw_res.get("idToken", new_tok), api_key=api_key)

    return True, {
        "email": new_email,
        "password": new_password,
        "uid": pw_res.get("localId") or em_res.get("localId"),
        "idToken": pw_res.get("idToken", new_tok)
    }


FIRST_NAMES = [
    "alexander", "benjamin", "christopher", "daniel", "emmanuel", "frederick",
    "gabriel", "harrison", "ignacio", "jonathan", "kendrick", "lawrence",
    "maximilian", "nicholas", "orlando", "patricia", "quintin", "roderick",
    "sebastian", "theodore", "valentin", "william", "xavier", "zachary",
    "dominic", "matthew", "anthony", "leonardo", "augustus", "victor", "adrian", "julian"
]

LAST_NAMES = [
    "henderson", "vanderbilt", "morrison", "holloway", "sterling", "blackwood",
    "kensington", "montgomery", "cunningham", "fitzgerald", "harrington", "livingston",
    "pemberton", "richardson", "welloughby", "strathmore", "carrington", "beauchamp",
    "davenport", "huntington", "standish", "rothschild", "kingsley"
]


def generate_realistic_email(domain="gmail.com"):
    fn = random.choice(FIRST_NAMES)
    ln = random.choice(LAST_NAMES)
    sep = random.choice([".", "_", ""])
    rand_num = random.randint(100000, 9999999)
    unique_suffix = uuid.uuid4().hex[:4]
    return f"{fn}{sep}{ln}{rand_num}{unique_suffix}@{domain}"


def generate_batch_accounts(count=5, password="Me261211@", domain="gmail.com", output_file="created_accounts.txt", threads=25, as_json=False):
    from concurrent.futures import ThreadPoolExecutor, as_completed
    import threading

    created = []
    file_lock = threading.Lock()
    counter_lock = threading.Lock()
    done_count = 0

    if not as_json:
        p_header(f"⚡ TURBO HESAP FABRİKASI ({count} Hesap | {threads} Paralel İş Parçacığı)")
        print(f"  {C.BOLD}Sabit Şifre{C.RESET}   : {password}")
        print(f"  {C.BOLD}Çıktı Dosyası{C.RESET} : {output_file}\n")

    def _worker(idx):
        nonlocal done_count
        em = generate_realistic_email(domain=domain)
        res, err = register_request(em, password)

        with counter_lock:
            done_count += 1
            cur_idx = done_count

        if res and "idToken" in res:
            uid = res.get("localId", "")
            rec = {"email": em, "password": password, "uid": uid, "idToken": res.get("idToken")}
            with file_lock:
                created.append(rec)
                with open(output_file, "a", encoding="utf-8") as f:
                    f.write(f"{em}:{password}\n")
            if not as_json:
                print(f"  {C.CYAN}[{cur_idx:02d}/{count:02d}]{C.RESET} {C.BOLD}{em:<46}{C.RESET} -> {C.GREEN}BAŞARILI ✓{C.RESET} (UID: {uid[:8]}...)")
            return rec
        else:
            if not as_json:
                print(f"  {C.RED}[{cur_idx:02d}/{count:02d}] {em:<46} -> HATA: {err}{C.RESET}")
            return None

    worker_count = min(threads, count) if count > 0 else 1
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = [executor.submit(_worker, i) for i in range(1, count + 1)]
        for f in as_completed(futures):
            pass

    if not as_json:
        print()
        p_success(f"Toplam {len(created)}/{count} adet yeni hesap turbo hızda oluşturuldu!")
        print(f"  {C.BOLD}Kaydedilen Dosya:{C.RESET} {output_file}\n")

    return created


def delete_account_request(id_token, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:delete?key={key}"
    payload = {"idToken": id_token}
    return http_request(url, method="POST", payload=payload)


def lookup_account_request(id_token, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:lookup?key={key}"
    payload = {"idToken": id_token}
    return http_request(url, method="POST", payload=payload)


def refresh_token_request(refresh_token_str, api_key=None):
    key = api_key or Config.get_api_key()
    url = f"https://securetoken.googleapis.com/v1/token?key={key}"
    payload = {"grant_type": "refresh_token", "refresh_token": refresh_token_str}
    res, err = http_request(url, method="POST", payload=payload)
    if res and "id_token" in res:
        sess = load_session() or {}
        sess["idToken"] = res["id_token"]
        sess["refreshToken"] = res.get("refresh_token", refresh_token_str)
        sess["expiresIn"] = res.get("expires_in")
        sess["userId"] = res.get("user_id")
        sess["project_id"] = res.get("project_id")
        save_session(sess)
    return res, err


def inspect_single_account(id_token=None, scan_db=True, as_json=False):
    tok = id_token or get_active_id_token()
    if not tok:
        if as_json:
            print(json.dumps({"error": "idToken bulunamadı."}, indent=2))
        else:
            p_error("İncelenecek hesap için idToken bulunamadı.")
        return None

    lookup_res, err = lookup_account_request(tok)
    if err or not lookup_res or not lookup_res.get("users"):
        if as_json:
            print(json.dumps({"error": f"Hesap bilgisi çekilemedi: {err}"}, indent=2))
        else:
            p_error(f"Hesap bilgisi çekilemedi: {err}")
        return None

    user = lookup_res["users"][0]
    uid = user.get("localId")

    jwt_info = decode_jwt(tok)
    custom_claims = {}
    if user.get("customAttributes"):
        try:
            custom_claims = json.loads(user["customAttributes"])
        except Exception:
            custom_claims = {"raw": user["customAttributes"]}
    elif jwt_info and jwt_info.get("custom_claims"):
        custom_claims = jwt_info["custom_claims"]

    from .cpm import get_user_connection, get_car_status, get_all_cars, get_clan_info
    conn_data, _ = get_user_connection(tok)
    car_status_data, _ = get_car_status(tok)
    all_cars_data, _ = get_all_cars(tok)
    clan_info = get_clan_info(tok)

    unlocked_count = 0
    unlocked_ids = []
    if car_status_data and isinstance(car_status_data, dict) and "carStatus" in car_status_data:
        unlocked_ids = [i for i, x in enumerate(car_status_data["carStatus"]) if x == 1]
        unlocked_count = len(unlocked_ids)

    custom_cars_count = 0
    custom_cars_ids = []
    if all_cars_data and isinstance(all_cars_data, list):
        custom_cars_ids = [c.get("CarID") for c in all_cars_data if isinstance(c, dict) and "CarID" in c]
        custom_cars_count = len(custom_cars_ids)

    total_cars = max(unlocked_count, custom_cars_count)
    level = conn_data.get("level", 0) if isinstance(conn_data, dict) else 0
    reports = conn_data.get("reports", 0) if isinstance(conn_data, dict) else 0
    can_play = conn_data.get("canPlay", 1) if isinstance(conn_data, dict) else 1

    report = {
        "uid": uid,
        "email": user.get("email"),
        "displayName": user.get("displayName"),
        "photoUrl": user.get("photoUrl"),
        "emailVerified": user.get("emailVerified", False),
        "disabled": user.get("disabled", False),
        "createdAt": format_timestamp(user.get("createdAt")),
        "lastLoginAt": format_timestamp(user.get("lastLoginAt")),
        "passwordUpdatedAt": format_timestamp(user.get("passwordUpdatedAt")),
        "providers": [p.get("providerId") for p in user.get("providerUserInfo", [])],
        "customClaims": custom_claims,
        "cpm_level": level,
        "cpm_reports": reports,
        "cpm_can_play": can_play,
        "cpm_total_cars": total_cars,
        "cpm_unlocked_cars": unlocked_count,
        "cpm_unlocked_ids": unlocked_ids,
        "cpm_custom_cars": custom_cars_count,
        "cpm_custom_ids": custom_cars_ids,
        "cpm_clan_id": clan_info.get("clan_id"),
        "idToken": tok
    }

    if as_json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return report

    p_header(f"🔍 HESAP İÇERİK KARTI: {report['email'] or report['uid']}")
    print(f"  {C.BOLD}UID (localId){C.RESET}         : {C.YELLOW}{report['uid']}{C.RESET}")
    print(f"  {C.BOLD}E-posta{C.RESET}               : {C.CYAN}{report['email'] or '(Belirtilmemiş)'}{C.RESET}")
    print(f"  {C.BOLD}Görünen İsim{C.RESET}          : {report['displayName'] or '(Yok)'}")
    print(f"  {C.BOLD}Hesap Durumu{C.RESET}          : {C.RED + 'KİLİTLİ/DEVRE DIŞI' if report['disabled'] else C.GREEN + 'AKTİF'}{C.RESET}")
    print(f"  {C.BOLD}Kayıt Tarihi{C.RESET}          : {report['createdAt']}")
    print(f"  {C.BOLD}Son Giriş Zamanı{C.RESET}      : {report['lastLoginAt']}")
    print(f"  ────────────────────────────────────────────────────────────")
    print(f"  {C.BOLD}🎮 CPM Seviye{C.RESET}         : {C.GREEN}Level {report['cpm_level']}{C.RESET}")
    print(f"  {C.BOLD}🚗 Toplam Açık Araç{C.RESET}   : {C.CYAN}{report['cpm_unlocked_cars']} adet{C.RESET}")
    print(f"  {C.BOLD}🛠️ Modifiyeli Garaj{C.RESET}   : {C.MAGENTA}{report['cpm_custom_cars']} adet{C.RESET}")
    if report["cpm_clan_id"]:
        print(f"  {C.BOLD}👥 Klan ID{C.RESET}            : {C.YELLOW}{report['cpm_clan_id']}{C.RESET}")
    print(f"  {C.BOLD}🛡️ Şikayet Sayısı{C.RESET}     : {report['cpm_reports']} (Ban Riski: {'TEMİZ' if report['cpm_reports'] < 3 else 'RİSKLİ'})")
    print()
    return report


def show_saved_active_accounts(as_json=False):
    candidates = []

    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r", encoding="utf-8") as f:
                s = json.load(f)
                tok = s.get("idToken") or s.get("id_token")
                if tok:
                    candidates.append({"token": tok, "source": SESSION_FILE, "email": s.get("email")})
        except Exception:
            pass

    if os.path.exists("valid_accounts.json"):
        try:
            with open("valid_accounts.json", "r", encoding="utf-8") as f:
                v_list = json.load(f)
                if isinstance(v_list, list):
                    for v in v_list:
                        tok = v.get("idToken") or v.get("id_token")
                        if tok:
                            candidates.append({"token": tok, "source": "valid_accounts.json", "email": v.get("email")})
        except Exception:
            pass

    seen_tokens = set()
    tokens_to_inspect = []
    for item in candidates:
        if item["token"] and item["token"] not in seen_tokens:
            seen_tokens.add(item["token"])
            tokens_to_inspect.append(item)

    if not tokens_to_inspect:
        if as_json:
            print(json.dumps({"error": "Kayıtlı aktif hesap/token bulunamadı."}, indent=2))
        else:
            p_warn("Kayıtlı aktif hesap veya token bulunamadı.")
        return

    if not as_json:
        p_header(f"💎 KAYITLI AKTİF HESAPLARIN İÇERİKLERİ ({len(tokens_to_inspect)} Hesap)")

    detailed_results = []
    for item in tokens_to_inspect:
        report = inspect_single_account(id_token=item["token"], scan_db=True, as_json=False)
        if report:
            report["source_file"] = item["source"]
            detailed_results.append(report)

    out_file = "active_accounts_detailed.json"
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(detailed_results, f, indent=2, ensure_ascii=False)

    if as_json:
        print(json.dumps(detailed_results, indent=2, ensure_ascii=False))
    else:
        p_success(f"Aktif hesapların tüm içerikleri '{out_file}' dosyasına kaydedildi!")