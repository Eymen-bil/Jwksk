# 🔥 CPM & Firebase Master Suite (Pro Edition V2.2)

Sıfır harici kütüphane bağımlılığıyla (saf Python 3 standart kütüphaneleri: `urllib`, `json`, `base64`, `argparse`, `http.server`, `concurrent.futures`), **Firebase Kimlik Doğrulama**, **Car Parking Multiplayer (CPM) Oyun Motoru**, **Hesap Kilitleme & Taşıma**, **Hesap Üretici Fabrikası**, **Garaj Dışa Aktarma & Karşılaştırma**, **Hesap Değerleme & Nadir Araç Tespiti**, **Dönen Proxy Motoru** ve **Localhost Web Dashboard** sunucusunu bir araya getiren hepsi bir arada profesyonel güç paketi.

---

## 🚀 Hızlı Başlangıç & Çalıştırma

### 1. 🌐 Localhost Web Paneli (İnteraktif Dashboard & Garaj Modal)
Tek komutla `http://127.0.0.1:5000` üzerinde tarayıcı tabanlı arama, filtreleme, portföy değerleme, **garaj araçlarını görsel inceleme** ve **tarayıcıdan tek tıkla e-posta/şifre değiştirme** paneli açar:
```bash
python firebase_auth_tool.py web
# veya
python checker.py --web
```

### 2. ⚡ Turbo Hesap Checker & Akıllı Kategori Ayrıştırma
`user.txt` içindeki hesapları paralel 25 worker ile saniyeler içinde tarar, hesap değerini hesaplar ve otomatik olarak 7 ayrı kategoriye böler:
```bash
python checker.py
```

### 3. 🖥️ Renkli TUI Menüsü (Terminal Konsol)
```bash
python firebase_auth_tool.py
```

---

## 💎 V2.2 İle Eklenen Yeni Güçlü Özellikler

### 1. 🔒 Tek Tıkla Hesap Kilitleme & Güvenceye Alma (`auth lockdown`)
Hesabın hem e-posta adresini hem şifresini tek işlemde günceller ve hesabı kilitler:
```bash
python firebase_auth_tool.py auth lockdown -e yeni_mail@gmail.com -p YeniGucluSifre123!
```

### 2. 🏭 Toplu Temiz Hesap Üretici Fabrika (`auth generate`)
İstenilen sayıda taze, temiz ve benzersiz CPM / Firebase hesabı üretip `created_accounts.txt` dosyasına kaydeder:
```bash
python firebase_auth_tool.py auth generate --count 10 --prefix cpm_user --domain gmail.com
```

### 3. 📑 Garajı CSV / JSON Olarak Dışa Aktarma (`cpm export`)
Aktif hesaptaki tüm araçları (ID, Araç İsmi, Kategori, Polis Çakarı, Çizim, Plaka) Excel uyumlu CSV veya JSON formatında dışa aktarır:
```bash
python firebase_auth_tool.py cpm export --format csv -o garajim.csv
```

### 4. 🔄 İki Hesabın Garajını Karşılaştırma (`cpm compare`)
İki farklı hesabın garajını kıyaslar, ortak ve farklı araçları listeler:
```bash
python firebase_auth_tool.py cpm compare --t1 <TOKEN_1> --t2 <TOKEN_2>
```

### 5. 📦 Toplu Hesap Taşıyıcı & Migrator (`batch migrate`)
`user.txt` içindeki tüm hesapları belirlediğiniz bir e-posta şablonuna (örn: `efe_{i}@gmail.com`) ve güçlü şifrelere topluca taşır:
```bash
python firebase_auth_tool.py batch migrate --pattern "cpm_hesap_{i}@gmail.com" -p "GucluSifre2026!"
```

### 6. ⚡ Akıllı Hesap & Garaj Filtreleme Motoru (`query`)
Binlerce hesap arasından tek satırda istediğin kriterdeki hesapları anında süzer ve şık bir tabloda listeler/kaydeder:
```bash
# 150'den fazla arabası olan ve 0 şikayetli temiz hesapları listele:
python firebase_auth_tool.py query --min-cars 150 --clean-only

# Sadece F1 (ID 100) aracı olan ve polis çakarlı hesapları filtreleyip kaydet:
python firebase_auth_tool.py query --has-f1 --has-siren -o f1_sirenli.txt

# Belirli bir arabası (Örn: Chiron ID 80) olan veya en az 1.000 TL değer biçilenleri bul:
python firebase_auth_tool.py query --car-id 80 --min-value 1000
```

### 7. 📊 Sunucu Havuzları Doluluk Grafiği (Bar Chart)
Canlı oyun sunucusundaki tüm havuzların doluluk oranını terminal üzerinde grafiksel çubuklarla gösterir.

---

## 📌 Popüler CLI Komut Örnekleri

```bash
# Akıllı Filtreleme
python firebase_auth_tool.py query --min-cars 150 --clean-only

# E-Posta Değiştirme
python firebase_auth_tool.py auth change-email -e yeni_mail@gmail.com

# Garajdaki Araçları İnceleme
python firebase_auth_tool.py cpm garage

# Açık Araç Kilitlerini Görme
python firebase_auth_tool.py cpm cars

# Garajı CSV Olarak İndirme
python firebase_auth_tool.py cpm export --format csv -o garaj.csv

# Şifre Sıfırlama Maili Gönderme
python firebase_auth_tool.py auth reset-pass -e efeejdar193@gmail.com

# Cihaz HWID Ban Sorgula
python firebase_auth_tool.py security sponge -d 0123456789abcdef

# Canlı Online Haritası
python firebase_auth_tool.py online map
```
