#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
🔥 FIREBASE & CPM MASTER SUITE (ALL-IN-ONE POWER CLI & TUI)
=============================================================================
"""

import sys
import os
import json
import argparse
from core import (
    C, init_terminal, p_info, p_success, p_warn, p_error, p_header,
    Config, SESSION_FILE, USERS_FILE,
    save_session, load_session, get_active_id_token, decode_jwt, print_jwt_analysis,
    login_request, register_request, anonymous_login_request,
    send_password_reset_request, send_email_verification_request,
    update_profile_request, change_password_request, change_email_request, delete_account_request,
    lookup_account_request, refresh_token_request, inspect_single_account,
    show_saved_active_accounts, lockdown_account, generate_batch_accounts,
    boost_account, get_all_cars, get_car_status, get_clan_info, get_daily_tasks, get_live_online_map,
    export_garage_to_file, compare_two_garages,
    generate_device_id, check_sponge_device, check_account_safety,
    FirestoreClient, RTDBClient, generate_html_dashboard,
    run_batch_checker, run_batch_inspector, run_account_switcher,
    run_batch_boost, run_batch_change_passwords, run_batch_migrate_accounts,
    query_accounts, execute_account_query,
    ProxyManager, start_local_web_dashboard, valuate_account
)

init_terminal()

# =============================================================================
# 🖥️ İNTERAKTİF MENÜ MODU (TUI)
# =============================================================================
def interactive_menu():
    while True:
        sess = load_session()
        active_email = sess.get("email") if sess else "Giriş Yapılmadı"
        
        token_status = f"{C.RED}Yok{C.RESET}"
        if sess and sess.get("idToken"):
            jwt_info = decode_jwt(sess["idToken"])
            if jwt_info:
                if jwt_info.get("is_expired"):
                    token_status = f"{C.RED}Süresi Dolmuş{C.RESET}"
                else:
                    m, s = divmod(jwt_info.get("remaining_seconds", 0), 60)
                    token_status = f"{C.GREEN}Aktif ({m} dk {s} sn){C.RESET}"

        proxy_str = f"{C.GREEN}{ProxyManager.count()} Proxy Aktif{C.RESET}" if ProxyManager.is_enabled() else f"{C.DIM}Devre Dışı{C.RESET}"

        print(f"""
{C.CYAN}{C.BOLD}=============================================================
🔥  FIREBASE & CPM MASTER SUITE (PRO TOOLKIT)
============================================================={C.RESET}
  {C.DIM}Aktif Hesap :{C.RESET} {C.BOLD}{active_email}{C.RESET}
  {C.DIM}Token Durumu:{C.RESET} {token_status}
  {C.DIM}Proxy Havuzu:{C.RESET} {proxy_str}
  {C.DIM}Proje ID    :{C.RESET} {Config.get_project_id()}
-------------------------------------------------------------
  {C.BOLD}{C.CYAN}[1]{C.RESET} 🔐 Auth Suite (Giriş, Kayıt, JWT, Profil, Şifre Değiştir)
  {C.BOLD}{C.GREEN}[2]{C.RESET} 🏎️ CPM Booster (Para/Altın Basma, Level, Garaj, Kilitler)
  {C.BOLD}{C.YELLOW}[3]{C.RESET} ⚡ Toplu İşlemler (user.txt Toplu Altın Basma / Şifre Değiştirme)
  {C.BOLD}{C.BLUE}[4]{C.RESET} 👥 user.txt Yönetimi (Turbo Checker, Değerleme & HTML)
  {C.BOLD}{C.MAGENTA}[5]{C.RESET} 🌐 Localhost Web Panelini Başlat (Browser Dashboard)
  {C.BOLD}{C.RED}[6]{C.RESET} 🛡️ Güvenlik & Anti-Ban (Sponge Cihaz Banı & Donanım ID)
  {C.BOLD}{C.CYAN}[7]{C.RESET} 🗺️ Canlı Oyun & Sunucu (Online Haritası, Klan Mesajları)
  {C.BOLD}{C.WHITE}[8]{C.RESET} 🗄️ Firestore & Realtime DB Test Kiti
  {C.BOLD}{C.WHITE}[9]{C.RESET} ⚙️ Sistem Ayarları (API Key & Project ID)
  {C.BOLD}{C.RED}[0]{C.RESET} 🚪 Çıkış
-------------------------------------------------------------""")

        choice = input(f"{C.BOLD}Seçiminiz [0-9]: {C.RESET}").strip()

        # 1. AUTH SUITE
        if choice == "1":
            while True:
                p_header("🔐 AUTH İŞLEMLERİ")
                print("  1. E-posta / Şifre Girişi")
                print("  2. Yeni Kayıt (Register)")
                print("  3. Anonim Giriş")
                print("  4. Hesap Bilgileri (Lookup)")
                print("  5. 🔍 Kapsamlı Hesap İnceleme (Inspect & Değerleme)")
                print("  6. Token Yenile (Refresh)")
                print("  7. Şifre Sıfırlama Maili Gönder")
                print("  8. Profil Güncelle (İsim/Fotoğraf)")
                print("  9. Şifre Değiştir")
                print(" 10. 📧 E-Posta Adresi Değiştir (Change Email)")
                print(" 11. 🔒 Hesabı Kilitle & Güvenceye Al (Lockdown: Mail + Şifre)")
                print(" 12. 🏭 Toplu Temiz Hesap Üretici (Account Generator)")
                print(" 13. Hesabı Kalıcı Olarak Sil")
                print(" 14. JWT Token Analizi")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                if sub == "1":
                    e = input("E-posta: ").strip()
                    p = input("Şifre: ").strip()
                    r, err = login_request(e, p)
                    if r and "idToken" in r:
                        save_session(r)
                        p_success("Giriş başarılı!")
                    else:
                        p_error(err)
                elif sub == "2":
                    e = input("E-posta: ").strip()
                    p = input("Şifre: ").strip()
                    r, err = register_request(e, p)
                    if r and "idToken" in r:
                        save_session(r)
                        p_success("Kayıt başarılı!")
                    else:
                        p_error(err)
                elif sub == "3":
                    r, err = anonymous_login_request()
                    if r and "idToken" in r:
                        save_session(r)
                        p_success("Anonim oturum açıldı!")
                    else:
                        p_error(err)
                elif sub == "4":
                    t = get_active_id_token()
                    if t:
                        r, err = lookup_account_request(t)
                        if r:
                            print(json.dumps(r.get("users", [{}])[0], indent=2, ensure_ascii=False))
                        else:
                            p_error(err)
                    else:
                        p_warn("Giriş yapılmamış.")
                elif sub == "5":
                    t = get_active_id_token()
                    if t:
                        inspect_single_account(id_token=t, scan_db=True)
                    else:
                        p_warn("Aktif oturum bulunamadı. Lütfen önce giriş yapın.")
                elif sub == "6":
                    s = load_session()
                    rf = (s.get("refreshToken") if s else None) or input("Refresh Token: ").strip()
                    if rf:
                        r, err = refresh_token_request(rf)
                        if r and "id_token" in r:
                            p_success("Token yenilendi!")
                        else:
                            p_error(err)
                elif sub == "7":
                    e = input("E-posta: ").strip()
                    r, err = send_password_reset_request(e)
                    if err:
                        p_error(err)
                    else:
                        p_success("Sıfırlama maili yollandı!")
                elif sub == "8":
                    t = get_active_id_token()
                    if t:
                        n = input("Yeni İsim: ").strip() or None
                        ph = input("Yeni Fotoğraf URL: ").strip() or None
                        r, err = update_profile_request(t, display_name=n, photo_url=ph)
                        if err:
                            p_error(err)
                        else:
                            p_success("Profil güncellendi!")
                elif sub == "9":
                    t = get_active_id_token()
                    if t:
                        np = input("Yeni Şifre: ").strip()
                        cur_p = input("Mevcut Şifre (Gerekliyse): ").strip() or None
                        r, err = change_password_request(t, np, current_password=cur_p)
                        if r and "idToken" in r:
                            save_session(r)
                            p_success("Şifre güncellendi!")
                        else:
                            p_error(err)
                elif sub == "10":
                    t = get_active_id_token()
                    if t:
                        new_em = input("Yeni E-Posta Adresi: ").strip()
                        cur_p = input("Mevcut Şifre (Gerekliyse): ").strip() or None
                        if new_em:
                            r, err = change_email_request(t, new_em, current_password=cur_p)
                            if r and "idToken" in r:
                                p_success(f"E-Posta adresi başarıyla '{new_em}' olarak değiştirildi!")
                            else:
                                p_error(err)
                    else:
                        p_warn("Aktif oturum bulunamadı.")
                elif sub == "11":
                    t = get_active_id_token()
                    if t:
                        new_em = input("Yeni E-Posta Adresi: ").strip()
                        new_pw = input("Yeni Güçlü Şifre: ").strip()
                        cur_p = input("Mevcut Şifre: ").strip() or None
                        if new_em and new_pw:
                            ok, res_data = lockdown_account(t, new_em, new_pw, current_password=cur_p)
                            if ok:
                                p_success(f"Hesap başarıyla kilitlendi ve güvenceye alındı!\nYeni Mail: {new_em} | Yeni Şifre: {new_pw}")
                            else:
                                p_error(res_data)
                    else:
                        p_warn("Aktif oturum bulunamadı.")
                elif sub == "12":
                    cnt_in = input("Üretilecek Hesap Sayısı (varsayılan: 5): ").strip()
                    cnt = int(cnt_in) if cnt_in.isdigit() else 5
                    pw_in = input("Hesap Şifresi (varsayılan: Me261211@): ").strip() or "Me261211@"
                    generate_batch_accounts(count=cnt, password=pw_in)
                elif sub == "13":
                    t = get_active_id_token()
                    if t:
                        c = input("Hesabı silmek için 'EVET' yazın: ").strip()
                        if c == "EVET":
                            r, err = delete_account_request(t)
                            if err:
                                p_error(err)
                            else:
                                if os.path.exists(SESSION_FILE):
                                    os.remove(SESSION_FILE)
                                p_success("Hesap silindi.")
                elif sub == "14":
                    t = get_active_id_token(auto_refresh=False) or input("JWT Token: ").strip()
                    if t:
                        print_jwt_analysis(t)
                elif sub == "0":
                    break
                input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")

        # 2. CPM BOOSTER
        elif choice == "2":
            while True:
                p_header("🏎️ CPM HESAP GÜÇLENDİRİCİ & GARAJ")
                print("  1. 🪙 Hesaba Altın (Coins) ve Para Bas")
                print("  2. ⭐ Seviye Yükselt (Level Booster)")
                print("  3. 🚗 Garajdaki Tüm Modifiyeli Araçları Listele")
                print("  4. 🔓 Açık Araçların Kilit Durumunu Sorgula")
                print("  5. 📑 Garajı CSV / JSON Olarak Dışa Aktar")
                print("  6. 🔄 İki Hesabın Garajını Karşılaştır (Compare Garages)")
                print("  7. 👥 Klan Bilgilerini ve İsteklerini Göster")
                print("  8. 📜 Günlük Görevleri Listele")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                t = get_active_id_token()
                if not t and sub != "0":
                    p_warn("Lütfen önce bir hesapla giriş yapın.")
                    input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")
                    continue

                if sub == "1":
                    c_in = input("Yüklenecek Altın Miktarı (Örn: 50000): ").strip()
                    m_in = input("Yüklenecek Nakit Para Miktarı (Örn: 50000000): ").strip()
                    coins = int(c_in) if c_in.isdigit() else 50000
                    money = int(m_in) if m_in.isdigit() else 50000000
                    boost_account(t, coins=coins, money=money)
                elif sub == "2":
                    l_in = input("Ayarlanacak Seviye (Örn: 100): ").strip()
                    lvl = int(l_in) if l_in.isdigit() else 100
                    boost_account(t, level=lvl)
                elif sub == "3":
                    cars, err = get_all_cars(t)
                    if cars and isinstance(cars, list):
                        from core.valuator import parse_car_details
                        p_header(f"🚗 GARAJDAKİ MODİFİYELİ ARAÇLAR ({len(cars)} Araç)")
                        for idx, car in enumerate(cars, 1):
                            p_car = parse_car_details(car)
                            siren = f"{C.GREEN}VAR 🚨{C.RESET}" if p_car["has_police"] else f"{C.DIM}Yok{C.RESET}"
                            vinyl = f"{C.MAGENTA}VAR 🎨{C.RESET}" if p_car["has_vinyl"] else f"{C.DIM}Yok{C.RESET}"
                            plate = f"{C.YELLOW}{p_car['license_plate']}{C.RESET}" if p_car["license_plate"] else f"{C.DIM}(Plaka Yok){C.RESET}"
                            print(f"  {C.CYAN}[{idx:02d}]{C.RESET} {C.BOLD}{p_car['name']:<26}{C.RESET} (ID: {p_car['car_id']:<3}) | Siren: {siren:<15} | Çizim: {vinyl:<17} | Plaka: {plate}")
                    else:
                        p_warn("Garajda kayıtlı araç bulunamadı veya hata oluştu.")
                elif sub == "4":
                    st, err = get_car_status(t)
                    if st and "carStatus" in st:
                        unl = [i for i, x in enumerate(st["carStatus"]) if x == 1]
                        p_success(f"Toplam Açık Araç: {len(unl)} adet")
                        print(f"Araç ID'leri: {unl}")
                    else:
                        p_error(f"Araç durumu çekilemedi: {err}")
                elif sub == "5":
                    fmt = input("Format seçin (csv/json, varsayılan: csv): ").strip() or "csv"
                    out_f = f"garage_export.{fmt.lower()}"
                    res_path, err = export_garage_to_file(t, output_path=out_f, output_format=fmt)
                    if res_path:
                        p_success(f"Garaj tablosu '{res_path}' dosyasına aktarıldı!")
                    else:
                        p_error(err)
                elif sub == "6":
                    em2 = input("Karşılaştırılacak 2. Hesabın E-Postası: ").strip()
                    pw2 = input("2. Hesabın Şifresi: ").strip()
                    r2, err2 = login_request(em2, pw2)
                    if r2 and "idToken" in r2:
                        comp = compare_two_garages(t, r2["idToken"])
                        p_header("🔄 GARAJ KARŞILAŞTIRMA RAPORU")
                        print(f"  {C.BOLD}Aktif Hesap Toplam Araç  {C.RESET}: {comp['account_1_total']}")
                        print(f"  {C.BOLD}2. Hesap Toplam Araç     {C.RESET}: {comp['account_2_total']}")
                        print(f"  {C.BOLD}Ortak Araç Sayısı        {C.RESET}: {comp['common_count']}")
                        print(f"  {C.BOLD}Sadece Aktif Hesapta Olan{C.RESET}: {comp['only_in_account_1']}")
                        print(f"  {C.BOLD}Sadece 2. Hesapta Olan   {C.RESET}: {comp['only_in_account_2']}")
                    else:
                        p_error(f"2. hesaba giriş yapılamadı: {err2}")
                elif sub == "7":
                    c_info = get_clan_info(t)
                    print(json.dumps(c_info, indent=2, ensure_ascii=False))
                elif sub == "8":
                    tasks, err = get_daily_tasks(t)
                    if tasks:
                        print(json.dumps(tasks, indent=2, ensure_ascii=False))
                    else:
                        p_error(f"Görevler alınamadı: {err}")
                elif sub == "0":
                    break
                input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")

        # 3. TOPLU İŞLEMLER
        elif choice == "3":
            while True:
                p_header("⚡ TOPLU İŞLEMLER (BATCH POWER TOOLS)")
                print("  1. 🪙 user.txt İçindeki Tüm Hesaplara Otomatik Altın/Para Bas")
                print("  2. 🔐 user.txt İçindeki Tüm Hesapların Şifrelerini Topluca Güncelle")
                print("  3. 📦 user.txt Hesaplarını Topluca Yeni Maillere Taşı (Batch Migrate)")
                print("  4. 🌐 results/ Klasöründeki En Son JSON'dan HTML Dashboard Üret")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                if sub == "1":
                    c_in = input("Her hesaba yüklenecek Altın (varsayılan: 50000): ").strip()
                    m_in = input("Her hesaba yüklenecek Para (varsayılan: 50000000): ").strip()
                    coins = int(c_in) if c_in.isdigit() else 50000
                    money = int(m_in) if m_in.isdigit() else 50000000
                    run_batch_boost(coins=coins, money=money)
                elif sub == "2":
                    run_batch_change_passwords()
                elif sub == "3":
                    pat = input("E-Posta Şablonu (Örn: cpm_hesap_{i}@gmail.com): ").strip() or "cpm_user_{i}@gmail.com"
                    pw = input("Yeni Şifre (Boş bırakılırsa rastgele üretilir): ").strip() or None
                    run_batch_migrate_accounts(email_pattern=pat, password=pw)
                elif sub == "4":
                    if os.path.exists("valid_accounts.json"):
                        out_html = "valid_accounts_dashboard.html"
                        generate_html_dashboard("valid_accounts.json", out_html)
                        p_success(f"HTML Dashboard başarıyla üretildi: '{out_html}'")
                    else:
                        p_warn("'valid_accounts.json' bulunamadı. Lütfen önce checker çalıştırın.")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                if sub == "1":
                    c_in = input("Her hesaba yüklenecek Altın (varsayılan: 50000): ").strip()
                    m_in = input("Her hesaba yüklenecek Para (varsayılan: 50000000): ").strip()
                    coins = int(c_in) if c_in.isdigit() else 50000
                    money = int(m_in) if m_in.isdigit() else 50000000
                    run_batch_boost(coins=coins, money=money)
                elif sub == "2":
                    run_batch_change_passwords()
                elif sub == "3":
                    if os.path.exists("valid_accounts.json"):
                        out_html = "valid_accounts_dashboard.html"
                        generate_html_dashboard("valid_accounts.json", out_html)
                        p_success(f"HTML Dashboard başarıyla üretildi: '{out_html}'")
                    else:
                        p_warn("'valid_accounts.json' bulunamadı. Lütfen önce checker çalıştırın.")
                elif sub == "0":
                    break
                input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")

        # 4. USER.TXT CHECKER
        elif choice == "4":
            while True:
                p_header("👥 USER.TXT YÖNETİMİ, CHECKER & DEĞERLEME")
                print("  1. 🚀 Turbo Hesap Kontrolü (Değerleme, Kategoriler & HTML)")
                print("  2. 🔍 Tüm Hesapların İçeriklerini Derin Tara (Batch Inspector)")
                print("  3. 💎 Kayıtlı Aktif Hesapları Dök (Show Active Accounts)")
                print("  4. 🔄 Hızlı Hesap Değiştirici (Account Switcher)")
                print("  5. ⚡ Akıllı Filtreleme & Arama Motoru (Smart Query Engine)")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                if sub == "1":
                    run_batch_checker()
                elif sub == "2":
                    run_batch_inspector()
                elif sub == "3":
                    show_saved_active_accounts()
                elif sub == "4":
                    run_account_switcher()
                elif sub == "5":
                    p_header("⚡ AKILLI HESAP & GARAJ FİLTRELEME")
                    f_min_c = input("Min Araç Sayısı (Boş bırakılabilir): ").strip()
                    f_f1 = input("Sadece F1 (ID 100) olanlar mı? (e/h): ").strip().lower() == "e"
                    f_sir = input("Sadece Polis Çakarı olanlar mı? (e/h): ").strip().lower() == "e"
                    f_vin = input("Sadece Çizimli/Vinyl olanlar mı? (e/h): ").strip().lower() == "e"
                    f_cln = input("Sadece 0 Şikayetli Temiz hesaplar mı? (e/h): ").strip().lower() == "e"
                    f_out = input("Sonuçları dosyaya kaydet (Örn: filtrelenenler.txt, boş bırakılabilir): ").strip() or None
                    
                    filters = {
                        "min_cars": int(f_min_c) if f_min_c.isdigit() else None,
                        "has_f1": f_f1,
                        "has_siren": f_sir,
                        "has_vinyl": f_vin,
                        "clean_only": f_cln
                    }
                    execute_account_query(filters, output_path=f_out)
                elif sub == "0":
                    break
                input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")

        # 5. LOCALHOST WEB PANEL
        elif choice == "5":
            start_local_web_dashboard()

        # 6. GÜVENLİK & SPONGE ANTI-BAN
        elif choice == "6":
            while True:
                p_header("🛡️ GÜVENLİK & SPONGE ANTI-BAN SORGULAYICI")
                print("  1. 🕵️ Cihaz / HWID Donanım Banı Sorgula (Sponge Status)")
                print("  2. 🎲 Rastgele Temiz Cihaz Kimliği (Device ID) Üret")
                print("  3. ⚠️ Aktif Hesabın Şikayet (Report) & Ban Güvenlik Durumu")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                if sub == "1":
                    dev_in = input("Sorgulanacak Device ID (Boş bırakılırsa rastgele üretilir): ").strip()
                    res, err = check_sponge_device(dev_in or None)
                    if res:
                        banned = res.get("is_banned", False)
                        print(f"\n  {C.BOLD}Device ID{C.RESET}   : {res['device_id']}")
                        print(f"  {C.BOLD}Ban Durumu{C.RESET}  : {C.RED + 'DONANIM BANI VAR (BANNED)' if banned else C.GREEN + 'TEMİZ (CLEAN)'}{C.RESET}")
                    else:
                        p_error(f"Sorgu hatası: {err}")
                elif sub == "2":
                    gen_id = generate_device_id()
                    p_success(f"Yeni Donanım Kimliği Üretildi: {C.BOLD}{gen_id}{C.RESET}")
                elif sub == "3":
                    t = get_active_id_token()
                    if t:
                        safety, err = check_account_safety(t)
                        if safety:
                            p_header("🛡️ HESAP GÜVENLİK DURUMU")
                            print(f"  {C.BOLD}Şikayet Sayısı (Reports){C.RESET}: {safety['reports']}")
                            print(f"  {C.BOLD}Oynayabilir mi (canPlay){C.RESET} : {'Evet' if safety['can_play'] == 1 else 'HAYIR (BANLI)'}")
                            print(f"  {C.BOLD}Güvenlik Durumu          {C.RESET}: {C.GREEN + 'GÜVENLİ' if safety['is_safe'] else C.RED + 'RİSKLİ/BAN'}{C.RESET}")
                        else:
                            p_error(err)
                    else:
                        p_warn("Lütfen önce giriş yapın.")
                elif sub == "0":
                    break
                input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")

        # 7. CANLI OYUN & SUNUCU
        elif choice == "7":
            while True:
                p_header("🌐 CANLI OYUN & SUNUCU MODÜLÜ")
                print("  1. 🗺️ Canlı Global Online Oyuncu & Sunucu Havuz Haritası")
                print("  2. 📊 Havuz Yoğunluk Grafiği (Bar Chart)")
                print("  3. 👥 Aktif Hesabın Klan Mesajlarını ve Geçmişini Oku")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                if sub == "1":
                    m_data, err = get_live_online_map()
                    if m_data:
                        p_header("🗺️ CANLI SUNUCU DURUMU")
                        print(f"  {C.BOLD}Toplam Çevrimiçi Oyuncu{C.RESET}: {C.GREEN}{m_data.get('total_online'):,} kişi{C.RESET}")
                        print(f"  {C.BOLD}Oda Havuzları Dağılımı {C.RESET}:")
                        pools = m_data.get("pools", {})
                        for p_no, count in pools.items():
                            print(f"    • Havuz #{p_no:<2}: {count:>5} oyuncu")
                    else:
                        p_error(f"Harita alınamadı: {err}")
                elif sub == "2":
                    m_data, err = get_live_online_map()
                    if m_data and "pools" in m_data:
                        p_header("📊 SUNUCU HAVUZLARI DOLULUK GRAFİĞİ")
                        pools = m_data["pools"]
                        max_cnt = max([int(c) for c in pools.values()] or [1])
                        for p_no, count in sorted(pools.items(), key=lambda x: int(x[0]) if x[0].isdigit() else 0):
                            cnt = int(count)
                            bars = int((cnt / max_cnt) * 30)
                            bar_str = "█" * bars + "░" * (30 - bars)
                            color = C.RED if cnt > (max_cnt * 0.75) else (C.YELLOW if cnt > (max_cnt * 0.4) else C.CYAN)
                            print(f"  Havuz #{p_no:<2} |{color}{bar_str}{C.RESET}| {cnt:>4} oyuncu")
                    else:
                        p_error(err or "Harita verisi alınamadı.")
                elif sub == "3":
                    t = get_active_id_token()
                    if t:
                        c_info = get_clan_info(t)
                        print(json.dumps(c_info, indent=2, ensure_ascii=False))
                    else:
                        p_warn("Lütfen önce giriş yapın.")
                elif sub == "0":
                    break
                input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")

        # 8. FIRESTORE & RTDB
        elif choice == "8":
            while True:
                p_header("🗄️ FIRESTORE & REALTIME DATABASE")
                print("  1. Firestore Belge Oku (GET)")
                print("  2. Realtime Database Oku (GET)")
                print("  3. Realtime Database Yaz (PUT)")
                print("  0. Geri")
                sub = input(f"\n{C.BOLD}Seçiminiz: {C.RESET}").strip()
                if sub == "1":
                    col = input("Koleksiyon: ").strip()
                    doc = input("Belge ID: ").strip()
                    d, err = FirestoreClient.get_document(col, doc)
                    if err: p_error(err)
                    else: print(json.dumps(d, indent=2, ensure_ascii=False))
                elif sub == "2":
                    p_path = input("RTDB Yolu: ").strip()
                    r, err = RTDBClient.get_data(p_path)
                    if err: p_error(err)
                    else: print(json.dumps(r, indent=2, ensure_ascii=False) if isinstance(r, (dict, list)) else r)
                elif sub == "3":
                    p_path = input("RTDB Yolu: ").strip()
                    d_in = input("JSON Değeri: ").strip()
                    try: val = json.loads(d_in)
                    except: val = d_in
                    r, err = RTDBClient.set_data(p_path, val)
                    if err: p_error(err)
                    else: p_success("Yazıldı!")
                elif sub == "0":
                    break
                input(f"\n{C.DIM}Devam etmek için Enter'a basın...{C.RESET}")

        # 9. AYARLAR
        elif choice == "9":
            p_header("⚙️ SİSTEM AYARLARI")
            print(f"1. API Key Değiştir (Mevcut: {Config.get_api_key()})")
            print(f"2. Project ID Değiştir (Mevcut: {Config.get_project_id()})")
            print(f"3. RTDB URL Değiştir (Mevcut: {Config.get_rtdb_url()})")
            print("0. Geri")
            c = input("\nSeçiminiz: ").strip()
            if c == "1":
                k = input("Yeni API Key: ").strip()
                if k: Config.set_api_key(k); p_success("API Key güncellendi.")
            elif c == "2":
                pid = input("Yeni Project ID: ").strip()
                if pid: Config.set_project_id(pid); p_success("Project ID güncellendi.")
            elif c == "3":
                url = input("Yeni RTDB URL: ").strip()
                if url: Config.set_rtdb_url(url); p_success("RTDB URL güncellendi.")

        # 0. ÇIKIŞ
        elif choice == "0":
            p_info("Çıkış yapıldı. İyi çalışmalar!")
            break


# =============================================================================
# 🚀 CLI MOTORU & SUBCOMMAND İŞLEYİCİSİ
# =============================================================================
def build_cli_parser():
    common_parser = argparse.ArgumentParser(add_help=False)
    common_parser.add_argument("--json", action="store_true", help="Çıktıyı ham JSON formatında yazdırır")
    common_parser.add_argument("--key", "-k", help="Firebase API Key")
    common_parser.add_argument("--project", help="Firebase Project ID")

    parser = argparse.ArgumentParser(
        prog="firebase_auth_tool.py",
        description=f"{C.BOLD}🔥 Firebase & CPM Master Suite Power CLI{C.RESET}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[common_parser]
    )

    subparsers = parser.add_subparsers(dest="subcommand", help="Kullanılabilir Komut Grupları")

    # 1. AUTH
    p_auth = subparsers.add_parser("auth", help="🔐 Kimlik Doğrulama & Oturum", parents=[common_parser])
    auth_subs = p_auth.add_subparsers(dest="auth_action")
    
    p_login = auth_subs.add_parser("login", parents=[common_parser])
    p_login.add_argument("-e", "--email", required=True)
    p_login.add_argument("-p", "--password", required=True)

    p_reg = auth_subs.add_parser("register", parents=[common_parser])
    p_reg.add_argument("-e", "--email", required=True)
    p_reg.add_argument("-p", "--password", required=True)

    auth_subs.add_parser("anon", parents=[common_parser])
    p_insp = auth_subs.add_parser("inspect", parents=[common_parser])
    p_insp.add_argument("-t", "--token")
    auth_subs.add_parser("status", parents=[common_parser])
    auth_subs.add_parser("logout", parents=[common_parser])
    
    p_reset = auth_subs.add_parser("reset-pass", parents=[common_parser])
    p_reset.add_argument("-e", "--email", required=True)
    
    p_chp = auth_subs.add_parser("change-pass", parents=[common_parser])
    p_chp.add_argument("-p", "--password", required=True)
    p_chp.add_argument("-t", "--token")

    p_chem = auth_subs.add_parser("change-email", parents=[common_parser])
    p_chem.add_argument("-e", "--email", required=True)
    p_chem.add_argument("-t", "--token")

    p_lock = auth_subs.add_parser("lockdown", help="Hesabı tek tıkla güvenceye al (Mail + Şifre)", parents=[common_parser])
    p_lock.add_argument("-e", "--email", required=True, help="Yeni E-Posta")
    p_lock.add_argument("-p", "--password", required=True, help="Yeni Şifre")
    p_lock.add_argument("--current-pass", help="Mevcut Şifre")
    p_lock.add_argument("-t", "--token", help="idToken")

    p_gen = auth_subs.add_parser("generate", help="Toplu temiz CPM hesabı üret (Turbo Multi-Threaded)", parents=[common_parser])
    p_gen.add_argument("-c", "--count", type=int, default=5, help="Üretilecek hesap sayısı (Örn: 30)")
    p_gen.add_argument("-w", "--threads", type=int, default=25, help="Paralel iş parçacığı / worker sayısı (varsayılan: 25)")
    p_gen.add_argument("-p", "--password", default="Me261211@", help="Hesap şifresi (varsayılan: Me261211@)")
    p_gen.add_argument("--domain", default="gmail.com", help="E-posta alan adı (varsayılan: gmail.com)")
    p_gen.add_argument("-o", "--output", default="created_accounts.txt", help="Çıktı dosyası")

    p_del = auth_subs.add_parser("delete-account", parents=[common_parser])
    p_del.add_argument("-t", "--token")
    p_del.add_argument("--confirm", action="store_true")

    p_jwt = auth_subs.add_parser("jwt", parents=[common_parser])
    p_jwt.add_argument("-t", "--token")

    # 2. CPM BOOSTER
    p_cpm = subparsers.add_parser("cpm", help="🏎️ CPM Hesap & Garaj Düzenleyici", parents=[common_parser])
    cpm_subs = p_cpm.add_subparsers(dest="cpm_action")
    
    p_cboost = cpm_subs.add_parser("boost", help="Para, altın ve seviye bas", parents=[common_parser])
    p_cboost.add_argument("--coins", type=int, default=50000, help="Yüklenecek Altın (Coin)")
    p_cboost.add_argument("--money", type=int, default=50000000, help="Yüklenecek Nakit Para")
    p_cboost.add_argument("--level", type=int, default=100, help="Ayarlanacak Seviye")
    p_cboost.add_argument("-t", "--token", help="idToken")

    p_cgarage = cpm_subs.add_parser("garage", help="Garajdaki araçları listele", parents=[common_parser])
    p_cgarage.add_argument("-t", "--token", help="idToken")

    p_ccars = cpm_subs.add_parser("cars", help="Açık araç kilit durumunu göster", parents=[common_parser])
    p_ccars.add_argument("-t", "--token", help="idToken")

    p_cexp = cpm_subs.add_parser("export", help="Garajı CSV veya JSON olarak kaydet", parents=[common_parser])
    p_cexp.add_argument("--format", default="csv", choices=["csv", "json"], help="Çıktı formatı")
    p_cexp.add_argument("-o", "--output", default="garage_export.csv", help="Çıktı dosyası")
    p_cexp.add_argument("-t", "--token", help="idToken")

    p_ccomp = cpm_subs.add_parser("compare", help="İki hesabın garajını karşılaştır", parents=[common_parser])
    p_ccomp.add_argument("--t1", required=True, help="1. Hesap Token")
    p_ccomp.add_argument("--t2", required=True, help="2. Hesap Token")

    # 3. BATCH
    p_batch = subparsers.add_parser("batch", help="⚡ user.txt Toplu İşlemler", parents=[common_parser])
    b_subs = p_batch.add_subparsers(dest="batch_action")

    p_bboost = b_subs.add_parser("boost", help="Tüm hesaplara altın ve para bas", parents=[common_parser])
    p_bboost.add_argument("-f", "--file", default=USERS_FILE)
    p_bboost.add_argument("--coins", type=int, default=50000)
    p_bboost.add_argument("--money", type=int, default=50000000)
    p_bboost.add_argument("--level", type=int, default=100)

    p_bcp = b_subs.add_parser("change-pass", help="Tüm hesapların şifrelerini değiştir", parents=[common_parser])
    p_bcp.add_argument("-f", "--file", default=USERS_FILE)

    p_bmig = b_subs.add_parser("migrate", help="Tüm hesapları yeni e-posta ve şifrelere taşı", parents=[common_parser])
    p_bmig.add_argument("-f", "--file", default=USERS_FILE)
    p_bmig.add_argument("--pattern", default="cpm_user_{i}@gmail.com", help="Yeni E-Posta Şablonu")
    p_bmig.add_argument("-p", "--password", help="Yeni Şifre")

    p_bhtml = b_subs.add_parser("html-report", help="JSON dosyasından HTML Dashboard üret", parents=[common_parser])
    p_bhtml.add_argument("-i", "--input", default="valid_accounts.json")
    p_bhtml.add_argument("-o", "--output", default="dashboard.html")

    # 4. USERS
    p_users = subparsers.add_parser("users", help="👥 user.txt Yönetimi & Checker", parents=[common_parser])
    u_subs = p_users.add_subparsers(dest="users_action")
    
    p_ucheck = u_subs.add_parser("check", parents=[common_parser])
    p_ucheck.add_argument("-f", "--file", default=USERS_FILE)
    p_ucheck.add_argument("--delay", type=float, default=0.05)

    u_subs.add_parser("show-active", parents=[common_parser])

    p_usw = u_subs.add_parser("switch", parents=[common_parser])
    p_usw.add_argument("-i", "--index", type=int)

    # 5. SECURITY
    p_sec = subparsers.add_parser("security", help="🛡️ Güvenlik & Anti-Ban", parents=[common_parser])
    s_subs = p_sec.add_subparsers(dest="security_action")
    
    p_sponge = s_subs.add_parser("sponge", help="Cihaz donanım banı sorgula", parents=[common_parser])
    p_sponge.add_argument("-d", "--device-id", help="Device ID")

    s_subs.add_parser("gen-device", help="Rastgele temiz Device ID üret", parents=[common_parser])

    # 6. ONLINE
    p_on = subparsers.add_parser("online", help="🌐 Canlı Sunucu & Havuz", parents=[common_parser])
    on_subs = p_on.add_subparsers(dest="online_action")
    on_subs.add_parser("map", help="Canlı çevrimiçi oyuncu haritası", parents=[common_parser])

    # 7. WEB
    # 7. WEB
    p_web = subparsers.add_parser("web", help="🌐 Localhost Web Dashboard Başlat", parents=[common_parser])
    p_web.add_argument("--port", type=int, default=5000, help="Sunucu Portu")

    # 8. QUERY (AKILLI FİLTRELEME & ARAMA)
    p_qry = subparsers.add_parser("query", help="⚡ Akıllı Hesap & Garaj Filtreleme Motoru", parents=[common_parser])
    p_qry.add_argument("-f", "--file", help="Kaynak JSON veya TXT hesap dosyası")
    p_qry.add_argument("--min-cars", type=int, help="Minimum araç sayısı (Örn: 100)")
    p_qry.add_argument("--max-cars", type=int, help="Maksimum araç sayısı (Örn: 50)")
    p_qry.add_argument("--min-level", type=int, help="Minimum seviye (Örn: 10)")
    p_qry.add_argument("--has-f1", action="store_true", help="F1 (Formula 1) aracı olanlar")
    p_qry.add_argument("--has-siren", "--has-police", action="store_true", help="Polis çakarı olanlar")
    p_qry.add_argument("--has-vinyl", action="store_true", help="Özel çizimli (vinyl) olanlar")
    p_qry.add_argument("--has-clan", action="store_true", help="Klan üyesi olanlar")
    p_qry.add_argument("--clean-only", action="store_true", help="0 şikayetli temiz hesaplar")
    p_qry.add_argument("--car-id", type=int, help="Belirli bir araç ID'si olanlar (Örn: 80)")
    p_qry.add_argument("--min-value", type=int, help="Minimum tahmini TL değeri (Örn: 500)")
    p_qry.add_argument("--tier", help="Belirli kategori (Örn: GOD, VIP, MYTHIC)")
    p_qry.add_argument("-s", "--search", help="E-posta veya plaka içinde metin ara")
    p_qry.add_argument("-o", "--output", help="Sonuçları kaydetmek için dosya yolu (.txt veya .json)")

    # 9. MENU
    subparsers.add_parser("menu", help="İnteraktif Konsol Menüsünü Başlat", parents=[common_parser])

    return parser


def handle_cli():
    parser = build_cli_parser()

    if len(sys.argv) == 1:
        interactive_menu()
        return

    args = parser.parse_args()
    as_json = getattr(args, "json", False)

    if args.subcommand == "menu":
        interactive_menu()
        return

    if args.subcommand == "web":
        start_local_web_dashboard(port=args.port)
        return

    if args.subcommand == "query":
        filters = {
            "min_cars": getattr(args, "min_cars", None),
            "max_cars": getattr(args, "max_cars", None),
            "min_level": getattr(args, "min_level", None),
            "has_f1": getattr(args, "has_f1", False),
            "has_siren": getattr(args, "has_siren", False),
            "has_vinyl": getattr(args, "has_vinyl", False),
            "has_clan": getattr(args, "has_clan", False),
            "clean_only": getattr(args, "clean_only", False),
            "car_id": getattr(args, "car_id", None),
            "min_value": getattr(args, "min_value", None),
            "tier": getattr(args, "tier", None),
            "search": getattr(args, "search", None)
        }
        execute_account_query(filters, file_path=args.file, output_path=args.output, as_json=as_json)
        return

    # AUTH
    if args.subcommand == "auth":
        if args.auth_action == "login":
            r, err = login_request(args.email, args.password)
            if r and "idToken" in r:
                save_session(r)
                if as_json: print(json.dumps(r, indent=2))
                else: p_success(f"Giriş başarılı! UID: {r.get('localId')}")
            else:
                if as_json: print(json.dumps({"error": err}, indent=2))
                else: p_error(err)
        elif args.auth_action == "register":
            r, err = register_request(args.email, args.password)
            if r and "idToken" in r:
                save_session(r)
                if as_json: print(json.dumps(r, indent=2))
                else: p_success(f"Kayıt başarılı! Yeni hesap oluşturuldu. UID: {r.get('localId')}")
            else:
                if as_json: print(json.dumps({"error": err}, indent=2))
                else: p_error(err)
        elif args.auth_action == "anon":
            r, err = anonymous_login_request()
            if r and "idToken" in r:
                save_session(r)
                if as_json: print(json.dumps(r, indent=2))
                else: p_success(f"Anonim oturum açıldı! UID: {r.get('localId')}")
            else:
                if as_json: print(json.dumps({"error": err}, indent=2))
                else: p_error(err)
        elif args.auth_action == "inspect":
            inspect_single_account(id_token=args.token, as_json=as_json)
        elif args.auth_action == "status":
            sess = load_session()
            if not sess:
                p_warn("Giriş yapılmamış.")
            else:
                inspect_single_account(as_json=as_json)
        elif args.auth_action == "reset-pass":
            r, err = send_password_reset_request(args.email)
            if err:
                if as_json: print(json.dumps({"error": err}, indent=2))
                else: p_error(err)
            else:
                if as_json: print(json.dumps({"success": True}, indent=2))
                else: p_success(f"Şifre sıfırlama bağlantısı '{args.email}' adresine gönderildi.")
        elif args.auth_action == "change-pass":
            tok = args.token or get_active_id_token()
            if not tok:
                p_error("Lütfen giriş yapın veya -t ile token belirtin.")
            else:
                r, err = change_password_request(tok, args.password)
                if r and "idToken" in r:
                    save_session(r)
                    if as_json: print(json.dumps(r, indent=2))
                    else: p_success("Şifre başarıyla güncellendi!")
                else:
                    if as_json: print(json.dumps({"error": err}, indent=2))
                    else: p_error(err)
        elif args.auth_action == "change-email":
            tok = args.token or get_active_id_token()
            if not tok:
                p_error("Lütfen giriş yapın veya -t ile token belirtin.")
            else:
                r, err = change_email_request(tok, args.email)
                if r and "idToken" in r:
                    save_session(r)
                    if as_json: print(json.dumps(r, indent=2))
                    else: p_success(f"E-Posta adresi başarıyla '{args.email}' olarak güncellendi!")
                else:
                    if as_json: print(json.dumps({"error": err}, indent=2))
                    else: p_error(err)
        elif args.auth_action == "lockdown":
            tok = args.token or get_active_id_token()
            if not tok:
                p_error("Lütfen giriş yapın veya -t ile token belirtin.")
            else:
                cur_p = getattr(args, "current_pass", None)
                ok, res_data = lockdown_account(tok, args.email, args.password, current_password=cur_p)
                if ok:
                    if as_json: print(json.dumps(res_data, indent=2))
                    else: p_success(f"Hesap başarıyla kilitlendi ve güvenceye alındı!\nYeni Mail: {args.email} | Yeni Şifre: {args.password}")
                else:
                    if as_json: print(json.dumps({"error": res_data}, indent=2))
                    else: p_error(res_data)
        elif args.auth_action == "generate":
            created = generate_batch_accounts(count=args.count, password=args.password, domain=args.domain, output_file=args.output, threads=args.threads, as_json=as_json)
            if as_json: print(json.dumps(created, indent=2))
        elif args.auth_action == "delete-account":
            tok = args.token or get_active_id_token()
            if not tok:
                p_error("Lütfen giriş yapın veya -t ile token belirtin.")
            elif not args.confirm:
                p_warn("Hesabı silmek için lütfen '--confirm' parametresini ekleyin.")
            else:
                r, err = delete_account_request(tok)
                if err:
                    if as_json: print(json.dumps({"error": err}, indent=2))
                    else: p_error(err)
                else:
                    if os.path.exists(SESSION_FILE): os.remove(SESSION_FILE)
                    if as_json: print(json.dumps({"success": True}, indent=2))
                    else: p_success("Hesap ve oturum kalıcı olarak silindi.")
        elif args.auth_action == "jwt":
            tok = args.token or get_active_id_token(auto_refresh=False)
            if not tok:
                p_error("Token belirtilmedi veya aktif oturum yok.")
            else:
                print_jwt_analysis(tok, as_json=as_json)
        elif args.auth_action == "logout":
            if os.path.exists(SESSION_FILE): os.remove(SESSION_FILE)
            p_success("Çıkış yapıldı.")

    # CPM BOOSTER
    elif args.subcommand == "cpm":
        if args.cpm_action == "boost":
            boost_account(id_token=args.token, coins=args.coins, money=args.money, level=args.level, as_json=as_json)
        elif args.cpm_action == "garage":
            tok = getattr(args, "token", None) or get_active_id_token()
            cars, err = get_all_cars(tok)
            if as_json:
                print(json.dumps(cars or {"error": err}, indent=2, ensure_ascii=False))
            else:
                if cars and isinstance(cars, list):
                    from core.valuator import parse_car_details
                    p_header(f"🚗 GARAJDAKİ MODİFİYELİ ARAÇLAR ({len(cars)} Araç)")
                    for idx, car in enumerate(cars, 1):
                        p_car = parse_car_details(car)
                        siren = f"{C.GREEN}VAR 🚨{C.RESET}" if p_car["has_police"] else f"{C.DIM}Yok{C.RESET}"
                        vinyl = f"{C.MAGENTA}VAR 🎨{C.RESET}" if p_car["has_vinyl"] else f"{C.DIM}Yok{C.RESET}"
                        plate = f"{C.YELLOW}{p_car['license_plate']}{C.RESET}" if p_car["license_plate"] else f"{C.DIM}(Plaka Yok){C.RESET}"
                        print(f"  {C.CYAN}[{idx:02d}]{C.RESET} {C.BOLD}{p_car['name']:<26}{C.RESET} (ID: {p_car['car_id']:<3}) | Siren: {siren:<15} | Çizim: {vinyl:<17} | Plaka: {plate}")
                    print()
                elif cars == []:
                    p_warn("Garajda kayıtlı araç bulunamadı.")
                else:
                    p_error(err or "Garaj verisi alınamadı.")
        elif args.cpm_action == "cars":
            tok = getattr(args, "token", None) or get_active_id_token()
            st, err = get_car_status(tok)
            if as_json:
                print(json.dumps(st or {"error": err}, indent=2, ensure_ascii=False))
            else:
                if st and isinstance(st, dict) and "carStatus" in st:
                    unlocked_ids = [i for i, x in enumerate(st["carStatus"]) if x == 1]
                    p_header(f"🔓 AÇIK ARAÇ KİLİTLERİ (Toplam {len(unlocked_ids)} Araç Açık)")
                    print(f"  {C.BOLD}Açık Araç ID'leri:{C.RESET} {unlocked_ids}\n")
                else:
                    p_error(err or "Araç kilit durumu çekilemedi.")
        elif args.cpm_action == "export":
            tok = getattr(args, "token", None) or get_active_id_token()
            out_p, err = export_garage_to_file(tok, output_path=args.output, output_format=args.format)
            if out_p:
                if as_json: print(json.dumps({"success": True, "file": out_p}))
                else: p_success(f"Garaj tablosu '{out_p}' dosyasına aktarıldı!")
            else:
                if as_json: print(json.dumps({"error": err}))
                else: p_error(err)
        elif args.cpm_action == "compare":
            comp = compare_two_garages(args.t1, args.t2)
            if as_json:
                print(json.dumps(comp, indent=2, ensure_ascii=False))
            else:
                p_header("🔄 GARAJ KARŞILAŞTIRMA RAPORU")
                print(f"  {C.BOLD}1. Hesap Toplam Araç  {C.RESET}: {comp['account_1_total']}")
                print(f"  {C.BOLD}2. Hesap Toplam Araç  {C.RESET}: {comp['account_2_total']}")
                print(f"  {C.BOLD}Ortak Araç Sayısı     {C.RESET}: {comp['common_count']}")
                print(f"  {C.BOLD}Sadece 1. Hesapta Olan{C.RESET}: {comp['only_in_account_1']}")
                print(f"  {C.BOLD}Sadece 2. Hesapta Olan{C.RESET}: {comp['only_in_account_2']}")

    # BATCH
    elif args.subcommand == "batch":
        if args.batch_action == "boost":
            run_batch_boost(file_path=args.file, coins=args.coins, money=args.money, level=args.level)
        elif args.batch_action == "change-pass":
            run_batch_change_passwords(file_path=args.file)
        elif args.batch_action == "migrate":
            run_batch_migrate_accounts(file_path=args.file, email_pattern=args.pattern, password=args.password)
        elif args.batch_action == "html-report":
            generate_html_dashboard(args.input, args.output)
            p_success(f"HTML Raporu üretildi: {args.output}")

    # USERS
    elif args.subcommand == "users":
        if args.users_action == "check":
            run_batch_checker(file_path=args.file, delay=args.delay, as_json=as_json)
        elif args.users_action == "show-active":
            show_saved_active_accounts(as_json=as_json)
        elif args.users_action == "switch":
            run_account_switcher(target_index=args.index)

    # SECURITY
    elif args.subcommand == "security":
        if args.security_action == "sponge":
            res, err = check_sponge_device(args.device_id)
            if as_json: print(json.dumps(res or {"error": err}, indent=2))
            else:
                if res:
                    print(f"Device ID: {res['device_id']} | Ban: {'BANLI' if res['is_banned'] else 'TEMİZ'}")
                else: p_error(err)
        elif args.security_action == "gen-device":
            gen_id = generate_device_id()
            if as_json: print(json.dumps({"device_id": gen_id}, indent=2))
            else: p_success(f"Device ID: {gen_id}")

    # ONLINE
    elif args.subcommand == "online":
        if args.online_action == "map":
            m_data, err = get_live_online_map()
            if as_json: print(json.dumps(m_data or {"error": err}, indent=2))
            else:
                if m_data:
                    p_header("🗺️ CANLI SUNUCU DURUMU")
                    print(f"Toplam Çevrimiçi: {m_data.get('total_online'):,} oyuncu")
                    for k, v in m_data.get("pools", {}).items():
                        print(f"  • Havuz #{k}: {v} oyuncu")
                else: p_error(err)


if __name__ == "__main__":
    handle_cli()
