# -*- coding: utf-8 -*-
"""
=============================================================================
🔑 CORE / JWT UTILITIES
=============================================================================
"""

import json
import base64
import time
from datetime import datetime
from .colors import C, p_header, p_success, p_warn, p_error

def decode_jwt(token):
    """Harici kütüphanesiz JWT Token ayrıştırır ve kalan süreyi hesaplar."""
    if not token or not isinstance(token, str):
        return None
    parts = token.split(".")
    if len(parts) != 3:
        return None

    def b64_url_decode(s):
        s += "=" * ((4 - len(s) % 4) % 4)
        return json.loads(base64.urlsafe_b64decode(s.encode("utf-8")).decode("utf-8", errors="ignore"))

    try:
        header = b64_url_decode(parts[0])
        payload = b64_url_decode(parts[1])
        exp = payload.get("exp", 0)
        auth_time = payload.get("auth_time", 0)
        iat = payload.get("iat", 0)
        now = time.time()
        
        is_expired = (now >= exp) if exp else False
        remaining_seconds = int(exp - now) if exp else 0

        project_id = payload.get("aud")
        if not project_id and "iss" in payload:
            project_id = payload["iss"].split("/")[-1]

        standard_claims = {"iss", "aud", "auth_time", "user_id", "sub", "iat", "exp", "email", "email_verified", "firebase"}
        custom_claims = {k: v for k, v in payload.items() if k not in standard_claims}

        return {
            "header": header,
            "payload": payload,
            "custom_claims": custom_claims,
            "is_expired": is_expired,
            "remaining_seconds": remaining_seconds,
            "exp_date": datetime.fromtimestamp(exp).strftime("%Y-%m-%d %H:%M:%S") if exp else "Bilinmiyor",
            "auth_date": datetime.fromtimestamp(auth_time).strftime("%Y-%m-%d %H:%M:%S") if auth_time else "Bilinmiyor",
            "iat_date": datetime.fromtimestamp(iat).strftime("%Y-%m-%d %H:%M:%S") if iat else "Bilinmiyor",
            "user_id": payload.get("user_id") or payload.get("sub"),
            "email": payload.get("email"),
            "email_verified": payload.get("email_verified", False),
            "sign_in_provider": payload.get("firebase", {}).get("sign_in_provider", "Bilinmiyor"),
            "project_id": project_id
        }
    except Exception as e:
        return {"error": str(e)}


def print_jwt_analysis(token, as_json=False):
    analysis = decode_jwt(token)
    if not analysis or "error" in analysis:
        if as_json:
            print(json.dumps({"error": analysis.get("error") if analysis else "Geçersiz Token"}, indent=2))
        else:
            p_error(f"JWT çözümlenemedi: {analysis.get('error') if analysis else 'Geçersiz Token'}")
        return

    if as_json:
        print(json.dumps(analysis, indent=2, ensure_ascii=False))
        return

    p_header("JWT TOKEN DETAYLI ANALİZİ")
    print(f"  {C.BOLD}Kullanıcı E-posta{C.RESET}  : {C.CYAN}{analysis.get('email') or '(Belirtilmemiş)'}{C.RESET}")
    print(f"  {C.BOLD}Kullanıcı ID (UID){C.RESET} : {C.YELLOW}{analysis.get('user_id')}{C.RESET}")
    print(f"  {C.BOLD}Firebase Proje ID{C.RESET}  : {C.MAGENTA}{analysis.get('project_id')}{C.RESET}")
    print(f"  {C.BOLD}Giriş Sağlayıcı{C.RESET}    : {analysis.get('sign_in_provider')}")
    print(f"  {C.BOLD}E-posta Onaylı mı?{C.RESET} : {C.GREEN + 'Evet' if analysis.get('email_verified') else C.RED + 'Hayır'}{C.RESET}")
    print(f"  {C.BOLD}Giriş Zamanı{C.RESET}       : {analysis.get('auth_date')}")
    print(f"  {C.BOLD}Son Geçerlilik (Exp){C.RESET}: {analysis.get('exp_date')}")
    
    if analysis.get("custom_claims"):
        print(f"  {C.BOLD}Özel Yetkiler (Claims){C.RESET}: {C.YELLOW}{json.dumps(analysis['custom_claims'])}{C.RESET}")

    if analysis.get("is_expired"):
        p_warn(f"DURUM: {C.BG_RED}{C.WHITE} SÜRESİ DOLMUŞ {C.RESET} (Lütfen token yenileyin!)")
    else:
        rem_m, rem_s = divmod(analysis.get("remaining_seconds", 0), 60)
        p_success(f"DURUM: {C.BG_GREEN}{C.WHITE} GEÇERLİ {C.RESET} (Kalan Süre: {rem_m} dakika {rem_s} saniye)")
