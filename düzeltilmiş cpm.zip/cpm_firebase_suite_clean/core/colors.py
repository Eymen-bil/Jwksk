# -*- coding: utf-8 -*-
"""
=============================================================================
🎨 CORE / COLORS & CLI FORMATTING
=============================================================================
"""

import sys
import os

class C:
    RESET    = "\033[0m"
    BOLD     = "\033[1m"
    DIM      = "\033[2m"
    RED      = "\033[91m"
    GREEN    = "\033[92m"
    YELLOW   = "\033[93m"
    BLUE     = "\033[94m"
    MAGENTA  = "\033[95m"
    CYAN     = "\033[96m"
    WHITE    = "\033[97m"
    BG_CYAN  = "\033[46m"
    BG_RED   = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_BLUE  = "\033[44m"


def init_terminal():
    """Windows konsolunda UTF-8, satır tamponlama ve ANSI renk desteğini etkinleştirir."""
    if sys.platform == "win32":
        try:
            if hasattr(sys.stdout, "reconfigure"):
                sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
            if hasattr(sys.stderr, "reconfigure"):
                sys.stderr.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        except Exception:
            pass
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except Exception:
            os.system('')

init_terminal()

def _safe_print(text):
    try:
        print(text, flush=True)
    except UnicodeEncodeError:
        try:
            sys.stdout.buffer.write(text.encode("utf-8", errors="replace") + b"\n")
            sys.stdout.flush()
        except Exception:
            pass

def p_info(msg):
    _safe_print(f" {C.CYAN}[*]{C.RESET} {msg}")

def p_success(msg):
    _safe_print(f" {C.GREEN}[✓]{C.RESET} {C.GREEN}{msg}{C.RESET}")

def p_warn(msg):
    _safe_print(f" {C.YELLOW}[!]{C.RESET} {C.YELLOW}{msg}{C.RESET}")

def p_error(msg):
    _safe_print(f" {C.RED}[✗] HATA:{C.RESET} {C.RED}{msg}{C.RESET}")

def p_header(title):
    line = "─" * 66
    _safe_print(f"\n{C.CYAN}{C.BOLD}┌{line}┐{C.RESET}")
    _safe_print(f"{C.CYAN}{C.BOLD}│  🔥 {title.ljust(62)} │{C.RESET}")
    _safe_print(f"{C.CYAN}{C.BOLD}└{line}┘{C.RESET}")
