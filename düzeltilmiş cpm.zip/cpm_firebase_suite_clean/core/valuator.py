# -*- coding: utf-8 -*-
"""
=============================================================================
💎 CORE / CPM CAR CATALOG & ACCOUNT VALUATOR
=============================================================================
Car Parking Multiplayer (CPM) araç kataloğu, nadir/özel araç tespit motoru,
plaka (license plate) ve polis çakarı/çizim çözücüsü, piyasa değerleme algoritması.
=============================================================================
"""

import base64
import json
import re

# Popüler CPM Araba ID ve Model Kataloğu
CPM_CAR_CATALOG = {
    1: {"name": "Lada Riva (2107)", "tier": "Common", "base_price": 5000},
    2: {"name": "Volkswagen Golf Mk1", "tier": "Common", "base_price": 10000},
    3: {"name": "BMW E30 M3", "tier": "Rare", "base_price": 75000},
    4: {"name": "Mercedes-Benz 190E (W201)", "tier": "Rare", "base_price": 80000},
    5: {"name": "Toyota Supra Mk4 (A80)", "tier": "Legendary", "base_price": 250000},
    6: {"name": "Nissan Skyline GT-R R34", "tier": "Legendary", "base_price": 300000},
    7: {"name": "Mazda RX-7 (FD3S)", "tier": "Rare", "base_price": 150000},
    8: {"name": "Honda Civic Type R (EK9)", "tier": "Common", "base_price": 30000},
    9: {"name": "Ford Mustang GT 1969", "tier": "Rare", "base_price": 120000},
    10: {"name": "Chevrolet Camaro SS", "tier": "Rare", "base_price": 130000},
    14: {"name": "BMW M5 E60 (V10)", "tier": "Epic", "base_price": 280000},
    18: {"name": "Mercedes-AMG C63 (W204)", "tier": "Epic", "base_price": 270000},
    21: {"name": "Audi RS6 Avant (C7)", "tier": "Epic", "base_price": 350000},
    22: {"name": "Porsche 911 GT3 RS (991)", "tier": "Epic", "base_price": 400000},
    25: {"name": "Nissan Silvia S15", "tier": "Rare", "base_price": 110000},
    30: {"name": "Jeep Grand Cherokee Trackhawk", "tier": "Epic", "base_price": 320000},
    35: {"name": "Mercedes-Benz G63 AMG (G-Wagon)", "tier": "Epic", "base_price": 450000},
    40: {"name": "Lamborghini Huracán", "tier": "Legendary", "base_price": 600000},
    45: {"name": "Ferrari 458 Italia", "tier": "Legendary", "base_price": 650000},
    50: {"name": "McLaren 720S", "tier": "Legendary", "base_price": 700000},
    60: {"name": "Rolls-Royce Cullinan", "tier": "Legendary", "base_price": 850000},
    70: {"name": "Bugatti Veyron", "tier": "Mythic", "base_price": 1200000},
    80: {"name": "Bugatti Chiron", "tier": "Mythic", "base_price": 1500000},
    90: {"name": "Koenigsegg Agera RS", "tier": "Mythic", "base_price": 1800000},
    100: {"name": "Formula 1 Car (F1)", "tier": "Blacklist", "base_price": 3000000},
    105: {"name": "Mercedes-AMG Project One", "tier": "Mythic", "base_price": 2200000},
    110: {"name": "Lamborghini Aventador SVJ", "tier": "Mythic", "base_price": 2000000},
    120: {"name": "Pagani Huayra BC", "tier": "Mythic", "base_price": 2500000},
    130: {"name": "Kenworth / Peterbilt Heavy Truck", "tier": "Special", "base_price": 500000},
    140: {"name": "Hovercraft / Special Vehicle", "tier": "Blacklist", "base_price": 3500000}
}


def decode_license_plate(texts_b64):
    """
    GetAllCars2 içindeki b64 kodlu 'texts' alanından araç plakasını veya ismini ayrıştırır.
    Oyunun otomatik ürettiği motor seri numaralarını (RI360... vb.) eler, gerçek kullanıcı plakalarını alır.
    """
    if not texts_b64 or not isinstance(texts_b64, str):
        return None
    try:
        raw = base64.b64decode(texts_b64 + "=" * ((4 - len(texts_b64) % 4) % 4))
        matches = re.findall(rb'[a-zA-Z0-9_\-\. ]{3,32}', raw)
        for m in matches:
            s = m.decode("utf-8", errors="ignore").strip()
            # Motorun otomatik ürettiği dahili kimlikleri (örn: RI360742_13HV786) filtrele
            if s and not s.isdigit() and len(s) >= 4:
                if re.match(r'^[A-Z]{2}\d{5,}_', s):
                    continue
                return s
    except Exception:
        pass
    return None


def parse_car_details(car_obj):
    """
    Bir araç nesnesinin modifiye, polis çakarı, çizim (vinyl) ve plaka durumunu deşifre eder.
    """
    if not isinstance(car_obj, dict):
        return {}

    car_id = car_obj.get("CarID", 0)
    meta = CPM_CAR_CATALOG.get(car_id, {
        "name": f"CPM Araç #{car_id}",
        "tier": "Normal" if car_id < 60 else ("Epic" if car_id < 90 else "Mythic"),
        "base_price": 100000
    })

    # 1. Polis Çakarı ve FSO Tespiti
    has_police = False
    pol_raw = car_obj.get("installedPoliceLights")
    fso_raw = car_obj.get("fsoData")
    
    if isinstance(pol_raw, list):
        if any(isinstance(x, (int, float)) and x > 0 for x in pol_raw):
            has_police = True
    elif isinstance(pol_raw, str):
        # Varsayılan boş maske: "GxcA+Cf/CwBCjwCAVwA="
        if pol_raw not in ["GxcA+Cf/CwBCjwCAVwA=", "None", ""] and ("GxcA+CcB" in pol_raw or len(pol_raw) > 20):
            has_police = True

    if isinstance(fso_raw, list):
        if any(isinstance(x, (int, float)) and x > 0 for x in fso_raw):
            has_police = True
    elif isinstance(fso_raw, str):
        # Varsayılan boş fsoData: "GyMA+CcBEP6DqADghH8Y"
        if fso_raw not in ["GyMA+CcBEP6DqADghH8Y", "None", ""] and len(fso_raw) > 24:
            has_police = True

    # 2. Özel Çizim (Vinyl / Window Vinyl) Tespiti
    has_vinyl = False
    vinyl_raw = car_obj.get("Vynils")
    win_raw = car_obj.get("WindowVinyls")
    if isinstance(vinyl_raw, str) and len(vinyl_raw) > 30:
        has_vinyl = True
    if isinstance(win_raw, str) and len(win_raw) > 30:
        has_vinyl = True

    # 3. Plaka / İsim
    plate = decode_license_plate(car_obj.get("texts"))

    # 4. Modifiye Parçaları (BoughtParts)
    has_bought_parts = False
    bp = car_obj.get("BoughtParts")
    if isinstance(bp, list) and any(x > 0 for x in bp):
        has_bought_parts = True
    elif isinstance(bp, str) and len(bp) > 12 and bp not in ["Gx8B+KcBAo7+wwYc5hgGwBPqBQACG97HCREF"]:
        has_bought_parts = True

    return {
        "car_id": car_id,
        "name": meta["name"],
        "tier": meta["tier"],
        "base_price": meta["base_price"],
        "has_police": has_police,
        "has_vinyl": has_vinyl,
        "has_bought_parts": has_bought_parts,
        "license_plate": plate,
        "flag_id": car_obj.get("flagID", -1)
    }


def valuate_account(account_data):
    """
    Bir hesabın değerini (Değer Skoru, Nadirlik Seviyesi, Tahmini TL/USD Değeri) hesaplar.
    """
    if not isinstance(account_data, dict):
        return {}

    total_cars = account_data.get("cpm_total_cars", 0)
    level = account_data.get("cpm_level", 0) or 0
    clan_id = account_data.get("cpm_clan_id")
    reports = account_data.get("cpm_reports", 0) or 0
    can_play = account_data.get("cpm_can_play", 1)

    # Garaj detayları varsa analiz et
    cars_list = account_data.get("garage_cars", [])
    police_car_count = 0
    vinyl_car_count = 0
    mythic_count = 0
    blacklist_count = 0

    if cars_list and isinstance(cars_list, list):
        for c in cars_list:
            if isinstance(c, dict):
                if c.get("has_police") or (c.get("installedPoliceLights") and len(str(c["installedPoliceLights"])) > 5) or (c.get("fsoData") and len(str(c["fsoData"])) > 24):
                    police_car_count += 1
                if c.get("has_vinyl") or (c.get("Vynils") and len(str(c["Vynils"])) > 30) or (c.get("WindowVinyls") and len(str(c["WindowVinyls"])) > 30):
                    vinyl_car_count += 1
                cid = c.get("CarID") or c.get("car_id", 0)
                if cid in (70, 80, 90, 105, 110, 120):
                    mythic_count += 1
                elif cid in (100, 140):
                    blacklist_count += 1

    # Hesap Puanlama Algoritması
    score = 0
    score += total_cars * 25                # Her araba +25 puan
    score += level * 10                     # Her seviye +10 puan
    score += police_car_count * 150         # Her polis aracı +150 puan
    score += vinyl_car_count * 200          # Her çizimli araç +200 puan
    score += mythic_count * 300             # Her süper araba +300 puan
    score += blacklist_count * 500          # Blacklist / F1 +500 puan

    if clan_id:
        score += 200                        # Klan üyeliği +200 puan
    if reports == 0 and can_play == 1:
        score += 150                        # Tertemiz hesap bonusu +150 puan
    elif reports >= 3:
        score = max(0, score - 300)         # Şikayetli hesap cezası -300 puan

    # Tier Derecelendirme
    if score >= 3500:
        valuation_tier = "💎 MYTHIC GOD TIER"
        estimated_tl = round(score * 0.45, -1)
    elif score >= 2000:
        valuation_tier = "👑 VIP ULTRA"
        estimated_tl = round(score * 0.35, -1)
    elif score >= 1000:
        valuation_tier = "🥇 VIP GOLD"
        estimated_tl = round(score * 0.25, -1)
    elif score >= 400:
        valuation_tier = "🥈 SILVER"
        estimated_tl = round(score * 0.15, -1)
    else:
        valuation_tier = "🥉 BRONZE"
        estimated_tl = round(score * 0.10, -1)

    return {
        "score": score,
        "valuation_tier": valuation_tier,
        "estimated_tl": max(50, int(estimated_tl)),
        "police_car_count": police_car_count,
        "vinyl_car_count": vinyl_car_count,
        "mythic_count": mythic_count,
        "blacklist_count": blacklist_count
    }
