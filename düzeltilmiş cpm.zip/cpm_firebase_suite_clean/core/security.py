# -*- coding: utf-8 -*-
"""
=============================================================================
🛡️ CORE / SECURITY & ANTI-BAN (SPONGE STATUS)
=============================================================================
"""

import uuid
from .config import OGAMES_BASE_URL, get_active_id_token
from .http import http_request
from .cpm import cpm_ogames_headers, get_user_connection

def generate_device_id():
    """Rastgele temiz yeni Donanım Kimliği (Device ID / HWID) üretir."""
    return f"cpm_dev_{uuid.uuid4().hex[:16]}"


def check_sponge_device(device_id=None):
    """Sponge anti-cheat donanım banı sorgulaması yapar."""
    dev_id = device_id or generate_device_id()
    url = f"{OGAMES_BASE_URL}/check-service/sponge/v1/status"
    headers = cpm_ogames_headers(device_id=dev_id)
    res, err = http_request(url, method="GET", headers=headers)
    if res and isinstance(res, dict):
        return {"device_id": dev_id, "is_banned": res.get("result", False)}, None
    return None, err


def check_account_safety(id_token=None):
    """Hesabın şikayet (report) sayısını ve ban riskini analiz eder."""
    tok = id_token or get_active_id_token()
    if not tok:
        return None, "idToken bulunamadı"
    
    conn, err = get_user_connection(tok)
    if conn and isinstance(conn, dict):
        rep = conn.get("reports", 0)
        cp = conn.get("canPlay", 1)
        is_safe = rep < 3 and cp == 1
        return {
            "reports": rep,
            "can_play": cp,
            "is_safe": is_safe,
            "status_text": "GÜVENLİ" if is_safe else "RİSKLİ / KISITLI"
        }, None
    return None, err
