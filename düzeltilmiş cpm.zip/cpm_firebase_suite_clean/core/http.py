# -*- coding: utf-8 -*-
"""
=============================================================================
🌐 CORE / HTTP CLIENT & NETWORK UTILS (WITH PROXY SUPPORT)
=============================================================================
"""

import json
import urllib.request
import urllib.error
from datetime import datetime
from .proxy import ProxyManager

FIREBASE_ERRORS = {
    "EMAIL_EXISTS": "Bu e-posta adresi zaten başka bir hesap tarafından kullanılıyor.",
    "OPERATION_NOT_ALLOWED": "Bu giriş yöntemi Firebase konsolunda aktif edilmemiş.",
    "TOO_MANY_ATTEMPTS_TRY_LATER": "Çok fazla başarısız istek yapıldı. Güvenlik için lütfen biraz bekleyin.",
    "EMAIL_NOT_FOUND": "Bu e-posta adresine ait bir kullanıcı bulunamadı.",
    "INVALID_PASSWORD": "Şifre hatalı.",
    "USER_DISABLED": "Bu kullanıcı hesabı yönetici tarafından devre dışı bırakılmış.",
    "TOKEN_EXPIRED": "Token süresi dolmuş. Lütfen yenileyin veya tekrar giriş yapın.",
    "INVALID_ID_TOKEN": "Geçersiz ID Token formatı veya kimlik doğrulanamadı.",
    "USER_NOT_FOUND": "Kullanıcı kaydı bulunamadı.",
    "INVALID_REFRESH_TOKEN": "Refresh token geçersiz veya iptal edilmiş.",
    "MISSING_PASSWORD": "Şifre alanı boş bırakılamaz.",
    "WEAK_PASSWORD : Password should be at least 6 characters": "Şifre çok zayıf (En az 6 karakter olmalıdır).",
    "INVALID_EMAIL": "Geçersiz e-posta formatı.",
    "CREDENTIAL_TOO_OLD_LOGIN_AGAIN": "Bu işlem hassas bilgi içerdiğinden lütfen tekrar giriş yapın.",
    "PERMISSION_DENIED": "Erişim reddedildi! Firestore / RTDB güvenlik kuralları bu işleme izin vermiyor."
}

def translate_error(err_str):
    for k, v in FIREBASE_ERRORS.items():
        if k in str(err_str):
            return f"{v} ({k})"
    return str(err_str)


def format_timestamp(ms_val):
    if not ms_val:
        return "Bilinmiyor"
    try:
        ts = int(ms_val) / 1000.0
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(ms_val)


def get_opener(proxy=None):
    """Proxy destekli URL Opener oluşturur."""
    p_url = proxy or (ProxyManager.get_proxy() if ProxyManager.is_enabled() else None)
    if p_url:
        proxy_handler = urllib.request.ProxyHandler({'http': p_url, 'https': p_url})
        return urllib.request.build_opener(proxy_handler)
    return urllib.request.build_opener()


def http_request(url, method="GET", payload=None, headers=None, timeout=4.0, proxy=None):
    if headers is None:
        headers = {}
    
    data = None
    if payload is not None:
        if isinstance(payload, (dict, list)):
            data = json.dumps(payload).encode("utf-8")
            if "Content-Type" not in headers:
                headers["Content-Type"] = "application/json"
        elif isinstance(payload, str):
            data = payload.encode("utf-8")

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    opener = get_opener(proxy)
    try:
        with opener.open(req, timeout=timeout) as response:
            res_body = response.read().decode("utf-8")
            try:
                return json.loads(res_body), None
            except json.JSONDecodeError:
                return res_body, None
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8")
        try:
            err_json = json.loads(err_body)
            if "error" in err_json:
                err_obj = err_json["error"]
                if isinstance(err_obj, dict):
                    err_msg = err_obj.get("message", str(e))
                else:
                    err_msg = str(err_obj)
            elif "message" in err_json:
                err_msg = err_json["message"]
            else:
                err_msg = err_body
        except Exception:
            err_msg = err_body or str(e)
        return None, translate_error(err_msg)
    except Exception as e:
        return None, translate_error(str(e))


def http_post(url, payload=None, headers=None, timeout=4.0, proxy=None):
    return http_request(url, method="POST", payload=payload, headers=headers, timeout=timeout, proxy=proxy)
