# -*- coding: utf-8 -*-
"""
=============================================================================
🏎️ CORE / CPM GAME ENGINE & CLOUD FUNCTIONS (DÜZELTİLMİŞ)
=============================================================================
"""

import json
import uuid
from .colors import p_success, p_error
from .config import CF_BASE_URL, OGAMES_BASE_URL, get_active_id_token
from .http import http_request

def cpm_headers(id_token=None):
    tok = id_token or get_active_id_token()
    headers = {"Content-Type": "application/json"}
    if tok:
        headers["Authorization"] = f"Bearer {tok}"
    return headers


def cpm_ogames_headers(id_token=None, device_id=None):
    tok = id_token or get_active_id_token()
    dev_id = device_id or f"cpm_dev_{uuid.uuid4().hex[:16]}"
    headers = {
        "Content-Type": "application/json",
        "X-Client-Platform": "Android",
        "X-Client-Version": "4.9.10",
        "X-Client-Build": "181",
        "X-Client-Env": "prod",
        "X-Client-DeviceId": dev_id
    }
    if tok:
        headers["Authorization"] = f"Bearer {tok}"
    return headers


def get_user_connection(id_token=None):
    url = f"{CF_BASE_URL}/GetUserConnectionData2"
    res, err = http_request(url, method="POST", payload={"data": {}}, headers=cpm_headers(id_token))
    if res and isinstance(res, dict) and "result" in res:
        try:
            return json.loads(res["result"]) if isinstance(res["result"], str) else res["result"], None
        except Exception:
            return res["result"], None
    return None, err


def save_player_records(id_token=None, hard_currency=None, money=None, level=None):
    url = f"{CF_BASE_URL}/SavePlayerRecordsPartially8"
    
    conn, _ = get_user_connection(id_token)
    if not conn or not isinstance(conn, dict):
        return False, "Kullanıcı verisi çekilemedi"
    
    current_hard = conn.get("hard_currency", 0) or 0
    current_money = conn.get("money", 0) or 0
    current_level = conn.get("level", 0) or 0
    
    new_hard = hard_currency if hard_currency is not None else current_hard
    new_money = money if money is not None else current_money
    new_level = level if level is not None else current_level
    
    payload = {
        "data": {
            "hard_currency": new_hard,
            "money": new_money,
            "level": new_level,
            "experience": conn.get("experience", 0),
            "cars": conn.get("cars", []),
            "houses": conn.get("houses", []),
            "clan_id": conn.get("clan_id", 0),
            "canPlay": conn.get("canPlay", 1),
            "reports": conn.get("reports", 0)
        }
    }
    
    res, err = http_request(url, method="POST", payload=payload, headers=cpm_headers(id_token))
    if res and isinstance(res, dict) and "result" in res:
        try:
            parsed = json.loads(res["result"]) if isinstance(res["result"], str) else res["result"]
            return True, parsed
        except Exception:
            return True, res["result"]
    return False, err


def boost_account(id_token=None, coins=50000, money=50000000, level=100, as_json=False):
    tok = id_token or get_active_id_token()
    if not tok:
        if as_json:
            print(json.dumps({"error": "idToken bulunamadı."}, indent=2))
        else:
            p_error("Aktif oturum bulunamadı. Lütfen giriş yapın.")
        return False

    success, res = save_player_records(tok, hard_currency=coins, money=money, level=level)
    if success:
        if as_json:
            print(json.dumps({"success": True, "coins": coins, "money": money, "level": level}, indent=2))
        else:
            p_success(f"Hesap Güçlendirildi! 🪙 Altın: +{coins:,} | 💵 Para: +{money:,} | ⭐ Seviye: {level}")
        return True
    else:
        if as_json:
            print(json.dumps({"error": str(res)}, indent=2))
        else:
            p_error(f"Güçlendirme başarısız: {res}")
        return False


def get_all_cars(id_token=None):
    url = f"{CF_BASE_URL}/GetAllCars2"
    res, err = http_request(url, method="POST", payload={"data": {}}, headers=cpm_headers(id_token))
    if res and isinstance(res, dict) and "result" in res:
        try:
            return json.loads(res["result"]) if isinstance(res["result"], str) else res["result"], None
        except Exception:
            return res["result"], None
    return None, err


def get_car_status(id_token=None):
    url = f"{CF_BASE_URL}/WSGetCarIDnStatusV3"
    res, err = http_request(url, method="POST", payload={"data": {}}, headers=cpm_headers(id_token))
    if res and isinstance(res, dict) and "result" in res:
        try:
            return json.loads(res["result"]) if isinstance(res["result"], str) else res["result"], None
        except Exception:
            return res["result"], None
    return None, err


def get_deleted_cars(id_token=None):
    url = f"{CF_BASE_URL}/WSGetDeletedCarListV3"
    res, err = http_request(url, method="POST", payload={"data": {}}, headers=cpm_headers(id_token))
    if res and isinstance(res, dict) and "result" in res:
        try:
            return json.loads(res["result"]) if isinstance(res["result"], str) else res["result"], None
        except Exception:
            return res["result"], None
    return None, err


def get_clan_info(id_token=None):
    headers = cpm_headers(id_token)
    info = {"clan_id": None, "has_requests": 0, "messages": None, "history": None}
    
    r_id, _ = http_request(f"{CF_BASE_URL}/GetClanId", method="POST", payload={"data": {}}, headers=headers)
    if r_id and "result" in r_id:
        info["clan_id"] = r_id["result"] or None

    r_req, _ = http_request(f"{CF_BASE_URL}/HasClanRequests", method="POST", payload={"data": {}}, headers=headers)
    if r_req and "result" in r_req:
        info["has_requests"] = r_req["result"]

    r_msg, _ = http_request(f"{CF_BASE_URL}/GetClanMessages", method="POST", payload={"data": {}}, headers=headers)
    if r_msg and "result" in r_msg:
        try:
            info["messages"] = json.loads(r_msg["result"]) if isinstance(r_msg["result"], str) else r_msg["result"]
        except Exception:
            pass

    r_his, _ = http_request(f"{CF_BASE_URL}/GetClanHistory", method="POST", payload={"data": {}}, headers=headers)
    if r_his and "result" in r_his:
        info["history"] = r_his["result"]

    return info


def get_daily_tasks(id_token=None):
    url = f"{CF_BASE_URL}/GetDailyTaskCall"
    res, err = http_request(url, method="POST", payload={"data": {}}, headers=cpm_headers(id_token))
    if res and "result" in res:
        try:
            return json.loads(res["result"]) if isinstance(res["result"], str) else res["result"], None
        except Exception:
            return res["result"], None
    return None, err


def get_live_online_map():
    url = f"{OGAMES_BASE_URL}/check-service/v1/online/map?version=181_2.40"
    res, err = http_request(url, method="GET")
    time_res, _ = http_request(f"{OGAMES_BASE_URL}/check-service/v1/time", method="GET")
    if res and isinstance(res, dict):
        return {
            "server_time": time_res,
            "total_online": res.get("all", 0),
            "pools": res.get("pools", {})
        }, None
    return None, err


def export_garage_to_file(id_token=None, output_path="garage_export.csv", output_format="csv"):
    from .valuator import parse_car_details
    cars, err = get_all_cars(id_token)
    if not cars or not isinstance(cars, list):
        return None, err or "Garajda araç bulunamadı."

    parsed = [parse_car_details(c) for c in cars]

    if output_format.lower() == "csv":
        import csv
        with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(["#", "CarID", "Araç Adı", "Kategori/Tier", "Siren/Çakar", "Özel Çizim", "Plaka"])
            for idx, c in enumerate(parsed, 1):
                writer.writerow([
                    idx, c.get("car_id"), c.get("name"), c.get("tier"),
                    "VAR" if c.get("has_police") else "YOK",
                    "VAR" if c.get("has_vinyl") else "YOK",
                    c.get("license_plate") or "-"
                ])
    else:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(parsed, f, indent=2, ensure_ascii=False)

    return output_path, None


def compare_two_garages(token1, token2):
    from .valuator import parse_car_details
    cars1, _ = get_all_cars(token1)
    cars2, _ = get_all_cars(token2)

    cars1 = cars1 if isinstance(cars1, list) else []
    cars2 = cars2 if isinstance(cars2, list) else []

    p1 = [parse_car_details(c) for c in cars1]
    p2 = [parse_car_details(c) for c in cars2]

    ids1 = set(c["car_id"] for c in p1)
    ids2 = set(c["car_id"] for c in p2)

    return {
        "account_1_total": len(p1),
        "account_2_total": len(p2),
        "common_count": len(ids1 & ids2),
        "only_in_account_1": sorted(list(ids1 - ids2)),
        "only_in_account_2": sorted(list(ids2 - ids1)),
        "common_ids": sorted(list(ids1 & ids2))
    }