# auth.py içinde sadece change_email_request ve change_password_request fonksiyonlarını değiştir:

def change_email_request(id_token, new_email, current_password=None, api_key=None):
    key = api_key or Config.get_api_key()
    tok = id_token
    
    # DÜZELTME: current_password verilmişse ve id_token yoksa, önce login yap
    if current_password and not tok:
        sess = load_session()
        c_em = sess.get("email") if sess else None
        if c_em:
            r_log, _ = login_request(c_em, current_password, api_key=key)
            if r_log and "idToken" in r_log:
                tok = r_log["idToken"]
    
    if not tok:
        return None, "idToken bulunamadı ve giriş yapılamadı"

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={key}"
    payload = {"idToken": tok, "email": new_email, "returnSecureToken": True}
    res, err = http_request(url, method="POST", payload=payload)
    if res and "idToken" in res:
        sess = load_session() or {}
        sess["email"] = res.get("email", new_email)
        sess["idToken"] = res.get("idToken")
        sess["refreshToken"] = res.get("refreshToken", sess.get("refreshToken"))
        save_session(sess)
    return res, err


def change_password_request(id_token, new_password, current_password=None, api_key=None):
    key = api_key or Config.get_api_key()
    tok = id_token
    
    # DÜZELTME: current_password verilmişse ve id_token yoksa, önce login yap
    if current_password and not tok:
        sess = load_session()
        c_em = sess.get("email") if sess else None
        if c_em:
            r_log, _ = login_request(c_em, current_password, api_key=key)
            if r_log and "idToken" in r_log:
                tok = r_log["idToken"]
    
    if not tok:
        return None, "idToken bulunamadı ve giriş yapılamadı"

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={key}"
    payload = {"idToken": tok, "password": new_password, "returnSecureToken": True}
    res, err = http_request(url, method="POST", payload=payload)
    if res and "idToken" in res:
        sess = load_session() or {}
        sess["idToken"] = res.get("idToken")
        sess["refreshToken"] = res.get("refreshToken", sess.get("refreshToken"))
        save_session(sess)
    return res, err