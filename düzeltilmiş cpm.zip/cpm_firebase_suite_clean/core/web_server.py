# -*- coding: utf-8 -*-
"""
=============================================================================
🌐 CORE / LOCALHOST WEB SERVER & INTERACTIVE DASHBOARD (PRO EDITION - DÜZELTİLMİŞ)
=============================================================================
"""

import os
import json
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
import socket
from urllib.parse import parse_qs, urlparse

from .colors import C, p_header, p_success, p_info
from .config import RESULTS_DIR, load_session, get_active_id_token
from .auth import login_request, register_request, change_email_request, change_password_request
from .cpm import get_live_online_map, boost_account, get_all_cars, get_clan_info, save_player_records
from .security import check_sponge_device
from .valuator import valuate_account, parse_car_details

def find_latest_accounts_data():
    if os.path.exists("valid_accounts.json"):
        try:
            with open("valid_accounts.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list) and data:
                    return data
        except Exception:
            pass

    if os.path.exists(RESULTS_DIR):
        json_files = []
        for root, _, files in os.walk(RESULTS_DIR):
            for file in files:
                if file.endswith(".json") and "valid" in file:
                    json_files.append(os.path.join(root, file))
        if json_files:
            json_files.sort(key=os.path.getmtime, reverse=True)
            try:
                with open(json_files[0], "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    return []


class DashboardHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/accounts":
            accounts = find_latest_accounts_data()
            for a in accounts:
                val = valuate_account(a)
                a["valuation"] = val
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(accounts, ensure_ascii=False).encode("utf-8"))
            return

        elif path == "/api/stats":
            online_map, _ = get_live_online_map()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(online_map or {}, ensure_ascii=False).encode("utf-8"))
            return

        elif path == "/api/session":
            sess = load_session() or {}
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(sess, ensure_ascii=False).encode("utf-8"))
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(self.get_html_page().encode("utf-8"))

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        try:
            payload = json.loads(body)
        except Exception:
            payload = {}

        if path == "/api/garage":
            tok = payload.get("token") or get_active_id_token()
            cars, err = get_all_cars(tok)
            parsed_cars = [parse_car_details(c) for c in cars] if isinstance(cars, list) else []
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps({"cars": parsed_cars, "error": err}, ensure_ascii=False).encode("utf-8"))
            return

        elif path == "/api/change-email":
            tok = payload.get("token") or get_active_id_token()
            new_em = payload.get("new_email")
            cur_pw = payload.get("password")
            res, err = change_email_request(tok, new_em, current_password=cur_pw)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            if res and "email" in res:
                self.wfile.write(json.dumps({"success": True, "email": res["email"]}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": err}).encode("utf-8"))
            return

        elif path == "/api/change-password":
            tok = payload.get("token") or get_active_id_token()
            new_pw = payload.get("new_password")
            cur_pw = payload.get("password")
            res, err = change_password_request(tok, new_pw, current_password=cur_pw)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            if res and "idToken" in res:
                self.wfile.write(json.dumps({"success": True}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": err}).encode("utf-8"))
            return

        elif path == "/api/create-account":
            em = payload.get("email")
            pw = payload.get("password")
            res, err = register_request(em, pw)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            if res and "idToken" in res:
                self.wfile.write(json.dumps({"success": True, "email": res["email"], "uid": res.get("localId")}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": err}).encode("utf-8"))
            return

        elif path == "/api/boost":
            tok = payload.get("token") or get_active_id_token()
            coins = int(payload.get("coins", 50000))
            money = int(payload.get("money", 50000000))
            lvl = int(payload.get("level", 100))
            
            ok, msg = save_player_records(id_token=tok, hard_currency=coins, money=money, level=lvl)
            
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            if ok:
                self.wfile.write(json.dumps({"success": True, "message": "Hesap güçlendirildi"}).encode("utf-8"))
            else:
                self.wfile.write(json.dumps({"success": False, "error": str(msg)}).encode("utf-8"))
            return

        elif path == "/api/sponge":
            dev_id = payload.get("device_id")
            res, err = check_sponge_device(dev_id)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(res or {"error": err}).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()

    def get_html_page(self):
        return """<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔥 CPM & Firebase Master Suite Pro Dashboard</title>
    <style>
        :root {
            --bg: #0b0f19;
            --card: #111827;
            --card-sub: #161e2e;
            --border: #1f2937;
            --text: #f9fafb;
            --text-dim: #9ca3af;
            --cyan: #06b6d4;
            --green: #10b981;
            --purple: #8b5cf6;
            --yellow: #f59e0b;
            --red: #ef4444;
            --blue: #3b82f6;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background-color: var(--bg); color: var(--text); padding: 24px; min-height: 100vh; }
        .container { max-width: 1440px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--border); }
        .brand h1 { font-size: 26px; font-weight: 800; background: linear-gradient(135deg, var(--cyan) 0%, var(--blue) 50%, var(--purple) 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; display: flex; align-items: center; gap: 10px; }
        .brand p { color: var(--text-dim); font-size: 13px; margin-top: 4px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background-color: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 18px; position: relative; overflow: hidden; }
        .stat-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: var(--cyan); }
        .stat-card.green::before { background: var(--green); }
        .stat-card.purple::before { background: var(--purple); }
        .stat-card.yellow::before { background: var(--yellow); }
        .stat-label { color: var(--text-dim); font-size: 12px; text-transform: uppercase; font-weight: 700; margin-bottom: 8px; }
        .stat-val { font-size: 26px; font-weight: 800; }
        .filter-bar { background-color: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px; }
        .search-box { flex: 1; min-width: 280px; }
        .search-input { width: 100%; background-color: #0b0f19; border: 1px solid #374151; border-radius: 8px; padding: 10px 14px; color: #fff; font-size: 14px; outline: none; transition: border-color 0.2s; }
        .search-input:focus { border-color: var(--cyan); }
        .pill-group { display: flex; gap: 8px; flex-wrap: wrap; }
        .pill { background-color: #1f2937; color: var(--text-dim); border: 1px solid #374151; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .pill.active { background-color: var(--cyan); color: #0b0f19; border-color: var(--cyan); }
        .table-card { background-color: var(--card); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
        th { background-color: #161e2e; color: var(--text-dim); font-weight: 700; padding: 12px 16px; border-bottom: 1px solid var(--border); text-transform: uppercase; font-size: 11px; }
        td { padding: 14px 16px; border-bottom: 1px solid #1f2937; vertical-align: middle; }
        tr:hover td { background-color: #161e2e; }
        .badge { display: inline-flex; align-items: center; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }
        .badge-green { background-color: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
        .badge-cyan { background-color: rgba(6, 182, 212, 0.15); color: #22d3ee; border: 1px solid rgba(6, 182, 212, 0.3); }
        .badge-purple { background-color: rgba(139, 92, 246, 0.15); color: #a78bfa; border: 1px solid rgba(139, 92, 246, 0.3); }
        .badge-yellow { background-color: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
        .badge-red { background-color: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
        .btn { background-color: #1f2937; color: #fff; border: 1px solid #374151; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s; display: inline-flex; align-items: center; gap: 6px; }
        .btn:hover { background-color: #374151; }
        .btn-green { background: linear-gradient(135deg, var(--green) 0%, #059669 100%); border: none; }
        .btn-primary { background: linear-gradient(135deg, var(--cyan) 0%, var(--blue) 100%); border: none; }
        .btn-purple { background: linear-gradient(135deg, var(--purple) 0%, #6d28d9 100%); border: none; }
        .code-box { font-family: monospace