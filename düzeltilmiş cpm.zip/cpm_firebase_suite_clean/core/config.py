# -*- coding: utf-8 -*-
"""
=============================================================================
⚙️ CORE / CONFIG & SESSION MANAGEMENT (DÜZELTİLMİŞ)
=============================================================================
"""

import os
import json
from .colors import p_error

DEFAULT_API_KEY = "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM"
SESSION_FILE = "session.json"
CONFIG_FILE = "config.json"
USERS_FILE = "user.txt"
RESULTS_DIR = "results"
CF_BASE_URL = "https://europe-west1-cp-multiplayer.cloudfunctions.net"
OGAMES_BASE_URL = "https://cpm-1.ogames.kz/api"
STATS_KEY = "320b93f3-e7f4-410a-a52c-e24da363ad04"

class Config:
    api_key = DEFAULT_API_KEY
    project_id = None
    rtdb_url = None

    @classmethod
    def load(cls):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    c = json.load(f)
                    cls.api_key = c.get("api_key", cls.api_key)
                    cls.project_id = c.get("project_id", cls.project_id)
                    cls.rtdb_url = c.get("rtdb_url", cls.rtdb_url)
            except Exception:
                pass

    @classmethod
    def save(cls):
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump({
                    "api_key": cls.api_key,
                    "project_id": cls.project_id,
                    "rtdb_url": cls.rtdb_url
                }, f, indent=2)
        except Exception:
            pass

    @classmethod
    def get_api_key(cls):
        return cls.api_key

    @classmethod
    def set_api_key(cls, new_key):
        cls.api_key = new_key
        cls.save()

    @classmethod
    def get_project_id(cls):
        if cls.project_id:
            return cls.project_id
        
        sess = load_session()
        if sess and sess.get("idToken"):
            from .jwt_utils import decode_jwt
            decoded = decode_jwt(sess["idToken"])
            if decoded and decoded.get("project_id"):
                cls.project_id = decoded["project_id"]
                cls.save()
                return cls.project_id
        
        cls.project_id = "cpm-2-7cea1"
        return cls.project_id

    @classmethod
    def set_project_id(cls, pid):
        cls.project_id = pid
        cls.save()

    @classmethod
    def get_rtdb_url(cls):
        if cls.rtdb_url:
            return cls.rtdb_url
        pid = cls.get_project_id()
        return f"https://{pid}-default-rtdb.europe-west1.firebasedatabase.app"

    @classmethod
    def set_rtdb_url(cls, url):
        cls.rtdb_url = url
        cls.save()

Config.load()


def save_session(data):
    try:
        with open(SESSION_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        p_error(f"Oturum kaydedilemedi: {e}")
        return False


def load_session():
    if not os.path.exists(SESSION_FILE):
        return None
    try:
        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def get_active_id_token(auto_refresh=True):
    sess = load_session()
    if not sess:
        return None
    
    id_token = sess.get("idToken") or sess.get("id_token")
    refresh_tok = sess.get("refreshToken") or sess.get("refresh_token")

    if not id_token:
        return None

    if auto_refresh and refresh_tok:
        from .jwt_utils import decode_jwt
        jwt_info = decode_jwt(id_token)
        if jwt_info and jwt_info.get("is_expired"):
            from .auth import refresh_token_request
            new_sess, _ = refresh_token_request(refresh_tok)
            if new_sess and "id_token" in new_sess:
                id_token = new_sess["id_token"]

    return id_token