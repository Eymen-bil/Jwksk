# -*- coding: utf-8 -*-
"""
=============================================================================
🛡️ CORE / ROTATING PROXY MANAGER
=============================================================================
Firebase ve CPM isteklerinde rate-limit (TOO_MANY_ATTEMPTS_TRY_LATER)
engeline takılmamak için HTTP / HTTPS / SOCKS5 proxy havuzu ve rotasyon motoru.
=============================================================================
"""

import os
import random
import urllib.request
from .colors import p_info, p_warn, p_success

PROXIES_FILE = "proxies.txt"

class ProxyManager:
    _proxies = []
    _current_index = 0
    _enabled = False

    @classmethod
    def load_proxies(cls, file_path=PROXIES_FILE):
        cls._proxies = []
        if not os.path.exists(file_path):
            return 0

        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                # Format: ip:port veya protocol://user:pass@ip:port
                if not line.startswith(("http://", "https://", "socks5://", "socks4://")):
                    line = f"http://{line}"
                cls._proxies.append(line)

        cls._enabled = len(cls._proxies) > 0
        return len(cls._proxies)

    @classmethod
    def get_proxy(cls):
        if not cls._proxies:
            return None
        proxy = cls._proxies[cls._current_index % len(cls._proxies)]
        cls._current_index += 1
        return proxy

    @classmethod
    def get_random_proxy(cls):
        if not cls._proxies:
            return None
        return random.choice(cls._proxies)

    @classmethod
    def is_enabled(cls):
        return cls._enabled and len(cls._proxies) > 0

    @classmethod
    def count(cls):
        return len(cls._proxies)


# Başlangıçta varsa yükle
ProxyManager.load_proxies()
