# -*- coding: utf-8 -*-
"""
=============================================================================
⚡ CORE / SMART QUERY ENGINE (AKILLI HESAP & GARAJ FİLTRELEME MOTORU)
=============================================================================
Taranmış veya kaydedilmiş yüzlerce hesap arasından tek komutla belirli
araçlara (F1, Chiron), sirenlere, çizimlere, seviyeye, klan ve değerleme
kriterlerine göre anında filtreleme, arama ve dışa aktarma yapar.
=============================================================================
"""

import os
import json
from .colors import C, p_header, p_success, p_warn, p_error, p_info
from .config import RESULTS_DIR
from .valuator import valuate_account, parse_car_details

def find_all_available_account_data(file_path=None):
    """Sorgulama için mevcut hesap listesini yükler."""
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            pass

    # 1. valid_accounts.json
    if os.path.exists("valid_accounts.json"):
        try:
            with open("valid_accounts.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list) and data:
                    return data
        except Exception:
            pass

    # 2. results/ altındaki en güncel JSON
    if os.path.exists(RESULTS_DIR):
        json_files = []
        for root, _, files in os.walk(RESULTS_DIR):
            for file in files:
                if file.endswith(".json") and ("valid" in file or "accounts" in file):
                    json_files.append(os.path.join(root, file))
        if json_files:
            json_files.sort(key=os.path.getmtime, reverse=True)
            try:
                with open(json_files[0], "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
            except Exception:
                pass
    return []


def check_account_matches_query(acc, filters):
    """Bir hesabın verilen filtre kriterlerine uyup uymadığını denetler."""
    if not isinstance(acc, dict):
        return False

    val = acc.get("valuation") or valuate_account(acc)
    total_cars = acc.get("cpm_total_cars", 0) or 0
    level = acc.get("cpm_level", 0) or 0
    reports = acc.get("cpm_reports", 0) if acc.get("cpm_reports") is not None else 0
    can_play = acc.get("cpm_can_play", 1)
    clan_id = acc.get("cpm_clan_id")
    est_tl = val.get("estimated_tl", 0)
    tier = val.get("valuation_tier", "").upper()
    police_count = val.get("police_car_count", 0)
    vinyl_count = val.get("vinyl_car_count", 0)

    # Araç ID'leri listesi (garajdan veya açık arabalardan)
    car_ids = set()
    garage = acc.get("garage_cars") or acc.get("cpm_cars") or []
    if isinstance(garage, list):
        for c in garage:
            if isinstance(c, dict):
                cid = c.get("CarID") or c.get("car_id")
                if cid is not None:
                    car_ids.add(int(cid))
            elif isinstance(c, int):
                car_ids.add(c)

    unlocked = acc.get("cpm_unlocked_ids") or []
    if isinstance(unlocked, list):
        for u in unlocked:
            if isinstance(u, int):
                car_ids.add(u)

    # 1. Min / Max Araç Sayısı
    min_cars = filters.get("min_cars")
    if min_cars is not None and total_cars < min_cars:
        return False

    max_cars = filters.get("max_cars")
    if max_cars is not None and total_cars > max_cars:
        return False

    # 2. Min Seviye
    min_level = filters.get("min_level")
    if min_level is not None and level < min_level:
        return False

    # 3. Min Tahmini TL Değeri
    min_value = filters.get("min_value")
    if min_value is not None and est_tl < min_value:
        return False

    # 4. F1 (Formula 1 - ID: 100) Şartı
    if filters.get("has_f1"):
        if 100 not in car_ids:
            return False

    # 5. Belirli Araç ID Şartı (Örn: Chiron 80, Agera 90, Supra 5)
    target_car_id = filters.get("car_id")
    if target_car_id is not None:
        if isinstance(target_car_id, int) and target_car_id not in car_ids:
            return False
        elif isinstance(target_car_id, list) and not any(cid in car_ids for cid in target_car_id):
            return False

    # 6. Polis Sireni (Çakar) Şartı
    if filters.get("has_siren") or filters.get("has_police"):
        if police_count <= 0:
            return False

    # 7. Özel Çizim (Vinyl) Şartı
    if filters.get("has_vinyl"):
        if vinyl_count <= 0:
            return False

    # 8. Klan Üyeliği Şartı
    if filters.get("has_clan"):
        if not clan_id:
            return False

    # 9. Temiz / 0 Şikayet Şartı
    if filters.get("clean_only"):
        if reports != 0 or can_play != 1:
            return False

    # 10. Değerleme Seviyesi (Tier) Şartı
    req_tier = filters.get("tier")
    if req_tier:
        if req_tier.upper() not in tier:
            return False

    # 11. Genel Arama (Metin arama)
    search_q = filters.get("search")
    if search_q:
        search_q = search_q.lower()
        acc_str = json.dumps(acc, ensure_ascii=False).lower()
        if search_q not in acc_str:
            return False

    return True


def query_accounts(accounts, filters):
    """Verilen hesap listesini filtreleyip eşleşenleri döndürür."""
    matched = []
    for a in accounts:
        if check_account_matches_query(a, filters):
            if "valuation" not in a:
                a["valuation"] = valuate_account(a)
            matched.append(a)
    return matched


def execute_account_query(filters, file_path=None, output_path=None, as_json=False):
    """
    CLI veya TUI üzerinden sorguyu çalıştırır, sonuç tablosunu basar
    ve istenirse dosyaya kaydeder.
    """
    accounts = find_all_available_account_data(file_path)
    if not accounts:
        if as_json:
            print(json.dumps({"error": "Sorgulanacak hesap verisi bulunamadı."}, indent=2))
        else:
            p_warn("Sorgulanacak geçerli hesap verisi bulunamadı. Lütfen önce checker çalıştırın veya -f ile dosya belirtin.")
        return []

    results = query_accounts(accounts, filters)

    if as_json:
        print(json.dumps(results, indent=2, ensure_ascii=False))
        return results

    # Başlık ve Filtre Kriterleri Özeti
    p_header(f"⚡ AKILLI HESAP SORGULAMA MOTORU (Eşleşen: {len(results)} / {len(accounts)} Hesap)")
    
    active_filters_str = []
    if filters.get("min_cars"): active_filters_str.append(f"Min Araç: {filters['min_cars']}")
    if filters.get("max_cars"): active_filters_str.append(f"Max Araç: {filters['max_cars']}")
    if filters.get("min_level"): active_filters_str.append(f"Min Seviye: {filters['min_level']}")
    if filters.get("has_f1"): active_filters_str.append("🏎️ F1 (ID 100) Şartı")
    if filters.get("car_id"): active_filters_str.append(f"🎯 Araç ID: {filters['car_id']}")
    if filters.get("has_siren"): active_filters_str.append("🚨 Sirenli (Çakarlı)")
    if filters.get("has_vinyl"): active_filters_str.append("🎨 Çizimli (Vinyl)")
    if filters.get("has_clan"): active_filters_str.append("👥 Klan Üyesi")
    if filters.get("clean_only"): active_filters_str.append("🛡️ 0 Şikayet (Temiz)")
    if filters.get("min_value"): active_filters_str.append(f"Min Değer: {filters['min_value']} ₺")
    if filters.get("tier"): active_filters_str.append(f"Tier: {filters['tier']}")
    if filters.get("search"): active_filters_str.append(f"Arama: '{filters['search']}'")

    if active_filters_str:
        print(f"  {C.BOLD}Uygulanan Filtreler:{C.RESET} {', '.join(active_filters_str)}\n")

    if not results:
        p_warn("Belirtilen kriterlere uyan hiçbir hesap bulunamadı.")
        return []

    # Sonuç Tablosu
    print(f"  {'#':<3} | {'E-Posta : Şifre':<38} | {'Araç':<6} | {'Seviye':<6} | {'Siren':<7} | {'Çizim':<7} | {'Tier / Puan':<18} | {'Tahmini ₺'}")
    print(f"  {'-'*110}")

    for idx, a in enumerate(results, 1):
        em_pw = f"{a.get('email', '')}:{a.get('password', '')}"
        em_pw_display = em_pw if len(em_pw) <= 38 else em_pw[:35] + "..."
        cars = a.get("cpm_total_cars", 0) or 0
        lvl = a.get("cpm_level")
        lvl_str = f"Lv.{lvl}" if lvl is not None else "Lv.-"
        val = a.get("valuation", {})
        siren_cnt = val.get("police_car_count", 0)
        vinyl_cnt = val.get("vinyl_car_count", 0)
        tier_str = val.get("valuation_tier", "BRONZE")
        est_tl = f"{val.get('estimated_tl', 0):,} ₺"

        siren_display = f"{C.GREEN}{siren_cnt} Adet{C.RESET}" if siren_cnt > 0 else f"{C.DIM}Yok{C.RESET}"
        vinyl_display = f"{C.MAGENTA}{vinyl_cnt} Adet{C.RESET}" if vinyl_cnt > 0 else f"{C.DIM}Yok{C.RESET}"
        
        tier_color = C.MAGENTA if "GOD" in tier_str or "MYTHIC" in tier_str else (C.YELLOW if "VIP" in tier_str else C.CYAN)

        print(f"  {idx:<3} | {em_pw_display:<38} | {cars:<6} | {lvl_str:<6} | {siren_display:<16} | {vinyl_display:<16} | {tier_color}{tier_str:<18}{C.RESET} | {C.GREEN}{est_tl}{C.RESET}")

        if idx >= 50 and len(results) > 55:
            remaining = len(results) - idx
            print(f"\n  {C.YELLOW}... ve {remaining} hesap daha eşleşti.{C.RESET} (Tümünü kaydetmek için: -o sonuc.txt)")
            break

    print()

    # Dosyaya kaydetme
    if output_path:
        if output_path.endswith(".json"):
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
        else:
            with open(output_path, "w", encoding="utf-8") as f:
                for a in results:
                    f.write(f"{a.get('email')}:{a.get('password')}\n")
        p_success(f"{len(results)} adet filtrelenen hesap '{output_path}' dosyasına kaydedildi!")

    return results
