# -*- coding: utf-8 -*-
"""
=============================================================================
📊 CORE / HTML DASHBOARD & JSON REPORTER
=============================================================================
"""

import os
import json
import re
import html
from datetime import datetime

def save_compact_json(data, file_path):
    """Sayı dizilerini (Araç ID'lerini) alt alta yerine tek satırda yan yana yazar."""
    raw = json.dumps(data, indent=2, ensure_ascii=False)
    cleaned = re.sub(r'\[\s*([0-9,\s]+?)\s*\]', lambda m: '[' + ', '.join(re.findall(r'\d+', m.group(1))) + ']', raw)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(cleaned)


def generate_html_dashboard(json_data, output_html_path, title="CPM & Firebase Hesap Raporu"):
    """JSON hesap verisinden modern, interaktif bir HTML Dashboard raporu üretir."""
    if isinstance(json_data, str):
        if os.path.exists(json_data):
            with open(json_data, "r", encoding="utf-8") as f:
                accounts = json.load(f)
        else:
            accounts = json.loads(json_data)
    else:
        accounts = json_data

    if not isinstance(accounts, list):
        accounts = [accounts]

    total_acc = len(accounts)
    valid_acc = sum(1 for a in accounts if a.get("idToken") or a.get("uid"))
    total_cars_sum = sum(a.get("cpm_total_cars", 0) for a in accounts)
    avg_level = round(sum(a.get("cpm_level", 0) for a in accounts if a.get("cpm_level")) / max(1, valid_acc), 1)
    vip_ultra_count = sum(1 for a in accounts if (a.get("cpm_total_cars") or 0) >= 150)
    vip_gold_count = sum(1 for a in accounts if 50 <= (a.get("cpm_total_cars") or 0) < 150)
    clan_count = sum(1 for a in accounts if a.get("cpm_clan_id"))

    now_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    accounts_json_str = json.dumps(accounts, ensure_ascii=False)

    html_template = f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html.escape(title)}</title>
    <style>
        :root {{
            --bg: #0b0f19;
            --card-bg: #111827;
            --card-border: #1f2937;
            --text-primary: #f9fafb;
            --text-secondary: #9ca3af;
            --accent-cyan: #06b6d4;
            --accent-green: #10b981;
            --accent-red: #ef4444;
            --accent-yellow: #f59e0b;
            --accent-purple: #8b5cf6;
            --accent-blue: #3b82f6;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, sans-serif; }}
        body {{ background-color: var(--bg); color: var(--text-primary); padding: 24px; min-height: 100vh; }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        .header {{ display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--card-border); }}
        .title-group h1 {{ font-size: 26px; font-weight: 800; background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 50%, #8b5cf6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; display: flex; align-items: center; gap: 10px; }}
        .title-group p {{ color: var(--text-secondary); font-size: 13px; margin-top: 4px; }}
        .header-actions {{ display: flex; gap: 10px; flex-wrap: wrap; }}
        .btn {{ background-color: #1f2937; color: #fff; border: 1px solid #374151; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s; display: inline-flex; align-items: center; gap: 6px; }}
        .btn:hover {{ background-color: #374151; border-color: #4b5563; }}
        .btn-primary {{ background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%); border: none; }}
        .btn-green {{ background: linear-gradient(135deg, #10b981 0%, #059669 100%); border: none; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }}
        .stat-card {{ background-color: var(--card-bg); border: 1px solid var(--card-border); border-radius: 12px; padding: 16px; display: flex; flex-direction: column; position: relative; overflow: hidden; }}
        .stat-card::before {{ content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: var(--accent-cyan); }}
        .stat-card.green::before {{ background: var(--accent-green); }}
        .stat-card.purple::before {{ background: var(--accent-purple); }}
        .stat-card.yellow::before {{ background: var(--accent-yellow); }}
        .stat-label {{ color: var(--text-secondary); font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }}
        .stat-val {{ font-size: 26px; font-weight: 800; color: var(--text-primary); }}
        .filter-bar {{ background-color: var(--card-bg); border: 1px solid var(--card-border); border-radius: 12px; padding: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px; }}
        .search-box {{ flex: 1; min-width: 260px; }}
        .search-input {{ width: 100%; background-color: #0b0f19; border: 1px solid #374151; border-radius: 8px; padding: 10px 14px; color: #fff; font-size: 14px; outline: none; transition: border-color 0.2s; }}
        .search-input:focus {{ border-color: var(--accent-cyan); }}
        .pill-group {{ display: flex; gap: 8px; flex-wrap: wrap; }}
        .pill {{ background-color: #1f2937; color: var(--text-secondary); border: 1px solid #374151; padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; }}
        .pill.active {{ background-color: var(--accent-cyan); color: #0b0f19; border-color: var(--accent-cyan); }}
        .table-card {{ background-color: var(--card-bg); border: 1px solid var(--card-border); border-radius: 12px; overflow: hidden; }}
        .table-wrap {{ overflow-x: auto; }}
        table {{ width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }}
        th {{ background-color: #161e2e; color: var(--text-secondary); font-weight: 700; padding: 12px 16px; border-bottom: 1px solid var(--card-border); text-transform: uppercase; letter-spacing: 0.5px; font-size: 11px; }}
        td {{ padding: 14px 16px; border-bottom: 1px solid #1f2937; vertical-align: middle; }}
        tr:hover td {{ background-color: #161e2e; }}
        .badge {{ display: inline-flex; align-items: center; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }}
        .badge-green {{ background-color: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }}
        .badge-cyan {{ background-color: rgba(6, 182, 212, 0.15); color: #22d3ee; border: 1px solid rgba(6, 182, 212, 0.3); }}
        .badge-purple {{ background-color: rgba(139, 92, 246, 0.15); color: #a78bfa; border: 1px solid rgba(139, 92, 246, 0.3); }}
        .badge-yellow {{ background-color: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }}
        .code-box {{ font-family: monospace; background-color: #0b0f19; padding: 4px 8px; border-radius: 4px; color: #e5e7eb; display: inline-flex; align-items: center; gap: 6px; }}
        .copy-btn {{ background: none; border: none; color: var(--text-secondary); cursor: pointer; font-size: 12px; }}
        .copy-btn:hover {{ color: var(--accent-cyan); }}
        #toast {{ position: fixed; bottom: 24px; right: 24px; background: #10b981; color: #fff; padding: 10px 18px; border-radius: 8px; font-size: 13px; font-weight: 600; display: none; z-index: 999; box-shadow: 0 4px 12px rgba(0,0,0,0.5); }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="title-group">
                <h1>🔥 CPM & Firebase Hesap Analiz Paneli</h1>
                <p>Oluşturulma Tarihi: {now_str} • Toplam Hesap: {total_acc}</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-green" onclick="copyAllAccounts()">📋 Tüm Hesapları Kopyala (email:şifre)</button>
                <button class="btn btn-primary" onclick="exportJSON()">💾 Filtrelenenleri JSON İndir</button>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card green">
                <div class="stat-label">Geçerli Hesaplar</div>
                <div class="stat-val">{valid_acc} <span style="font-size: 14px; color: var(--text-secondary);">/ {total_acc}</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Toplam Araç Sayısı</div>
                <div class="stat-val">{total_cars_sum}</div>
            </div>
            <div class="stat-card purple">
                <div class="stat-label">👑 VIP Ultra (150+ Araç)</div>
                <div class="stat-val">{vip_ultra_count}</div>
            </div>
            <div class="stat-card yellow">
                <div class="stat-label">💎 VIP Gold (50+ Araç)</div>
                <div class="stat-val">{vip_gold_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Ortalama Seviye</div>
                <div class="stat-val">Lv. {avg_level}</div>
            </div>
        </div>

        <div class="filter-bar">
            <div class="search-box">
                <input type="text" id="searchInput" class="search-input" placeholder="🔍 E-posta, UID, Seviye veya Araç ID ara..." onkeyup="filterTable()">
            </div>
            <div class="pill-group">
                <button class="pill active" onclick="setPillFilter('all', this)">Tümü ({valid_acc})</button>
                <button class="pill" onclick="setPillFilter('vip', this)">👑 VIP Hesaplar</button>
                <button class="pill" onclick="setPillFilter('clan', this)">👥 Klan Üyeleri ({clan_count})</button>
                <button class="pill" onclick="setPillFilter('custom', this)">🚗 Modifiyeli Garaj</button>
            </div>
        </div>

        <div class="table-card">
            <div class="table-wrap">
                <table id="accountsTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Hesap (E-Posta : Şifre)</th>
                            <th>Seviye</th>
                            <th>Toplam Araç</th>
                            <th>VIP Durumu</th>
                            <th>Klan</th>
                            <th>Kayıt / Son Giriş</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="toast">Kopyalandı!</div>

    <script>
        const rawData = {accounts_json_str};
        let currentFilter = 'all';

        function renderTable(data) {{
            const tbody = document.getElementById('tableBody');
            tbody.innerHTML = '';

            data.forEach((acc, idx) => {{
                const cars = acc.cpm_total_cars || 0;
                const unl = acc.cpm_unlocked_cars || 0;
                const cust = acc.cpm_custom_cars || (acc.cpm_cars ? acc.cpm_cars.length : 0);
                const lvl = acc.cpm_level !== null && acc.cpm_level !== undefined ? acc.cpm_level : '-';
                
                let vipBadge = '<span class="badge badge-cyan">BRONZE</span>';
                if (cars >= 150) vipBadge = '<span class="badge badge-purple">👑 VIP ULTRA</span>';
                else if (cars >= 50) vipBadge = '<span class="badge badge-yellow">💎 VIP GOLD</span>';
                else if (cars >= 20) vipBadge = '<span class="badge badge-green">🥈 SILVER</span>';

                const clanBadge = acc.cpm_clan_id ? `<span class="badge badge-purple">ID: ${{acc.cpm_clan_id}}</span>` : '<span style="color: #6b7280;">-</span>';
                const prof = acc.firebase_profile || {{}};
                const created = prof.createdAt ? prof.createdAt.split(' ')[0] : '-';
                const lastLogin = prof.lastLoginAt ? prof.lastLoginAt.split(' ')[0] : '-';

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong>#${{idx + 1}}</strong></td>
                    <td>
                        <div class="code-box">
                            <span>${{acc.email}} : ${{acc.password}}</span>
                            <button class="copy-btn" onclick="copyText('${{acc.email}}:${{acc.password}}')" title="Hesabı Kopyala">📋</button>
                        </div>
                    </td>
                    <td><span class="badge badge-green">Lv. ${{lvl}}</span></td>
                    <td>
                        <strong>${{cars}}</strong> adet
                        <div style="font-size: 11px; color: #9ca3af;">Açık: ${{unl}} | Garaj: ${{cust}}</div>
                    </td>
                    <td>${{vipBadge}}</td>
                    <td>${{clanBadge}}</td>
                    <td style="font-size: 12px; color: #9ca3af;">
                        <div>Kayıt: ${{created}}</div>
                        <div>Giriş: ${{lastLogin}}</div>
                    </td>
                    <td>
                        <button class="btn" style="padding: 4px 8px; font-size: 11px;" onclick="copyText('${{acc.idToken || ''}}')">🔑 Token</button>
                    </td>
                `;
                tbody.appendChild(tr);
            }});
        }}

        function copyText(text) {{
            if (!text) return;
            navigator.clipboard.writeText(text).then(() => {{
                const t = document.getElementById('toast');
                t.style.display = 'block';
                setTimeout(() => {{ t.style.display = 'none'; }}, 2000);
            }});
        }}

        function copyAllAccounts() {{
            const txt = rawData.map(a => `${{a.email}}:${{a.password}}`).join('\\n');
            copyText(txt);
        }}

        function exportJSON() {{
            const query = document.getElementById('searchInput').value.toLowerCase();
            const filtered = rawData.filter(a => {{
                const matchSearch = JSON.stringify(a).toLowerCase().includes(query);
                if (!matchSearch) return false;
                if (currentFilter === 'vip') return (a.cpm_total_cars || 0) >= 50;
                if (currentFilter === 'clan') return !!a.cpm_clan_id;
                if (currentFilter === 'custom') return (a.cpm_custom_cars || 0) > 0;
                return true;
            }});

            const blob = new Blob([JSON.stringify(filtered, null, 2)], {{ type: 'application/json' }});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `cpm_filtered_accounts_${{Date.now()}}.json`;
            a.click();
        }}

        function setPillFilter(type, el) {{
            document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
            el.classList.add('active');
            currentFilter = type;
            filterTable();
        }}

        function filterTable() {{
            const query = document.getElementById('searchInput').value.toLowerCase();
            const filtered = rawData.filter(a => {{
                const matchSearch = JSON.stringify(a).toLowerCase().includes(query);
                if (!matchSearch) return false;
                if (currentFilter === 'vip') return (a.cpm_total_cars || 0) >= 50;
                if (currentFilter === 'clan') return !!a.cpm_clan_id;
                if (currentFilter === 'custom') return (a.cpm_custom_cars || 0) > 0;
                return true;
            }});
            renderTable(filtered);
        }}

        renderTable(rawData);
    </script>
</body>
</html>"""

    with open(output_html_path, "w", encoding="utf-8") as f:
        f.write(html_template)
    return output_html_path
