# -*- coding: utf-8 -*-
"""
=============================================================================
🗄️ CORE / FIRESTORE & REALTIME DATABASE (RTDB) REST CLIENT (DÜZELTİLMİŞ)
=============================================================================
"""

import json
from .config import Config, get_active_id_token
from .http import http_request

def python_to_firestore_value(val):
    if val is None:
        return {"nullValue": None}
    elif isinstance(val, bool):
        return {"booleanValue": val}
    elif isinstance(val, int):
        return {"integerValue": str(val)}
    elif isinstance(val, float):
        return {"doubleValue": val}
    elif isinstance(val, str):
        return {"stringValue": val}
    elif isinstance(val, list):
        return {"arrayValue": {"values": [python_to_firestore_value(v) for v in val]}}
    elif isinstance(val, dict):
        return {"mapValue": {"fields": {k: python_to_firestore_value(v) for k, v in val.items()}}}
    return {"stringValue": str(val)}


def firestore_value_to_python(val_obj):
    if not isinstance(val_obj, dict):
        return val_obj
    if "stringValue" in val_obj:
        return val_obj["stringValue"]
    if "integerValue" in val_obj:
        try:
            return int(val_obj["integerValue"])
        except Exception:
            return val_obj["integerValue"]
    if "doubleValue" in val_obj:
        return float(val_obj["doubleValue"])
    if "booleanValue" in val_obj:
        return bool(val_obj["booleanValue"])
    if "nullValue" in val_obj:
        return None
    if "mapValue" in val_obj:
        fields = val_obj["mapValue"].get("fields", {})
        return {k: firestore_value_to_python(v) for k, v in fields.items()}
    if "arrayValue" in val_obj:
        values = val_obj["arrayValue"].get("values", [])
        return [firestore_value_to_python(v) for v in values]
    return val_obj


def firestore_doc_to_dict(doc_data):
    if not doc_data or "fields" not in doc_data:
        return {}
    return {k: firestore_value_to_python(v) for k, v in doc_data["fields"].items()}


class FirestoreClient:
    @staticmethod
    def _base_url():
        pid = Config.get_project_id()
        return f"https://firestore.googleapis.com/v1/projects/{pid}/databases/(default)/documents"

    @staticmethod
    def _headers(id_token=None):
        tok = id_token or get_active_id_token()
        headers = {"Content-Type": "application/json"}
        if tok:
            headers["Authorization"] = f"Bearer {tok}"
        return headers

    @classmethod
    def list_documents(cls, collection_path, page_size=50, id_token=None):
        url = f"{cls._base_url()}/{collection_path}?pageSize={page_size}"
        res, err = http_request(url, method="GET", headers=cls._headers(id_token))
        if err:
            return None, err
        docs = res.get("documents", [])
        parsed = []
        for d in docs:
            doc_name = d.get("name", "").split("/")[-1]
            parsed.append({
                "id": doc_name,
                "createTime": d.get("createTime"),
                "updateTime": d.get("updateTime"),
                "data": firestore_doc_to_dict(d)
            })
        return parsed, None

    @classmethod
    def get_document(cls, collection_path, doc_id, id_token=None):
        url = f"{cls._base_url()}/{collection_path}/{doc_id}"
        res, err = http_request(url, method="GET", headers=cls._headers(id_token))
        if err:
            return None, err
        return {
            "id": doc_id,
            "createTime": res.get("createTime"),
            "updateTime": res.get("updateTime"),
            "data": firestore_doc_to_dict(res)
        }, None

    @classmethod
    def set_document(cls, collection_path, doc_id, data_dict, id_token=None):
        url = f"{cls._base_url()}/{collection_path}/{doc_id}"
        firestore_fields = {k: python_to_firestore_value(v) for k, v in data_dict.items()}
        payload = {"fields": firestore_fields}
        return http_request(url, method="PATCH", payload=payload, headers=cls._headers(id_token))

    @classmethod
    def delete_document(cls, collection_path, doc_id, id_token=None):
        url = f"{cls._base_url()}/{collection_path}/{doc_id}"
        return http_request(url, method="DELETE", headers=cls._headers(id_token))


class RTDBClient:
    @staticmethod
    def _build_url(path, id_token=None):
        base = Config.get_rtdb_url().rstrip("/")
        clean_path = path.strip("/")
        tok = id_token or get_active_id_token()
        if tok:
            if clean_path:
                return f"{base}/{clean_path}.json?access_token={tok}"
            else:
                return f"{base}/.json?access_token={tok}"
        else:
            if clean_path:
                return f"{base}/{clean_path}.json"
            else:
                return f"{base}/.json"

    @staticmethod
    def _headers(id_token=None):
        tok = id_token or get_active_id_token()
        headers = {"Content-Type": "application/json"}
        if tok:
            headers["Authorization"] = f"Bearer {tok}"
        return headers

    @classmethod
    def get_data(cls, path="", id_token=None):
        url = cls._build_url(path, id_token)
        return http_request(url, method="GET", headers=cls._headers(id_token))

    @classmethod
    def set_data(cls, path, data, id_token=None):
        url = cls._build_url(path, id_token)
        return http_request(url, method="PUT", payload=data, headers=cls._headers(id_token))

    @classmethod
    def push_data(cls, path, data, id_token=None):
        url = cls._build_url(path, id_token)
        return http_request(url, method="POST", payload=data, headers=cls._headers(id_token))

    @classmethod
    def delete_data(cls, path, id_token=None):
        url = cls._build_url(path, id_token)
        return http_request(url, method="DELETE", headers=cls._headers(id_token))