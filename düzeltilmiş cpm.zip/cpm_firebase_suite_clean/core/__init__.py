# -*- coding: utf-8 -*-
"""
=============================================================================
🔥 CPM & FIREBASE MASTER SUITE - CORE PACKAGE
=============================================================================
"""

from .colors import C, init_terminal, p_info, p_success, p_warn, p_error, p_header
from .config import (
    Config, DEFAULT_API_KEY, SESSION_FILE, CONFIG_FILE, USERS_FILE, RESULTS_DIR,
    CF_BASE_URL, OGAMES_BASE_URL, STATS_KEY,
    save_session, load_session, get_active_id_token
)
from .http import http_request, http_post, format_timestamp, translate_error
from .jwt_utils import decode_jwt, print_jwt_analysis
from .auth import (
    login_request, register_request, anonymous_login_request,
    send_password_reset_request, send_email_verification_request,
    update_profile_request, change_password_request, change_email_request, delete_account_request,
    lookup_account_request, refresh_token_request, inspect_single_account,
    show_saved_active_accounts, lockdown_account, generate_batch_accounts
)
from .cpm import (
    cpm_headers, cpm_ogames_headers, get_user_connection, save_player_records,
    boost_account, get_all_cars, get_car_status, get_deleted_cars,
    get_clan_info, get_daily_tasks, get_live_online_map,
    export_garage_to_file, compare_two_garages
)
from .security import generate_device_id, check_sponge_device, check_account_safety
from .database import FirestoreClient, RTDBClient
from .reporter import generate_html_dashboard, save_compact_json
from .valuator import CPM_CAR_CATALOG, decode_license_plate, parse_car_details, valuate_account
from .proxy import ProxyManager
from .web_server import start_local_web_dashboard
from .batch import (
    parse_user_file, run_batch_checker, run_batch_inspector,
    run_account_switcher, run_batch_boost, run_batch_change_passwords,
    export_categorized_accounts, run_batch_migrate_accounts
)
from .query import query_accounts, execute_account_query, find_all_available_account_data

__version__ = "2.3.0"
__all__ = [
    "C", "init_terminal", "p_info", "p_success", "p_warn", "p_error", "p_header",
    "Config", "DEFAULT_API_KEY", "SESSION_FILE", "CONFIG_FILE", "USERS_FILE", "RESULTS_DIR",
    "CF_BASE_URL", "OGAMES_BASE_URL", "STATS_KEY",
    "save_session", "load_session", "get_active_id_token",
    "http_request", "http_post", "format_timestamp", "translate_error",
    "decode_jwt", "print_jwt_analysis",
    "login_request", "register_request", "anonymous_login_request",
    "send_password_reset_request", "send_email_verification_request",
    "update_profile_request", "change_password_request", "change_email_request", "delete_account_request",
    "lookup_account_request", "refresh_token_request", "inspect_single_account",
    "show_saved_active_accounts", "lockdown_account", "generate_batch_accounts",
    "cpm_headers", "cpm_ogames_headers", "get_user_connection", "save_player_records",
    "boost_account", "get_all_cars", "get_car_status", "get_deleted_cars",
    "get_clan_info", "get_daily_tasks", "get_live_online_map",
    "export_garage_to_file", "compare_two_garages",
    "generate_device_id", "check_sponge_device", "check_account_safety",
    "FirestoreClient", "RTDBClient",
    "generate_html_dashboard", "save_compact_json",
    "CPM_CAR_CATALOG", "decode_license_plate", "parse_car_details", "valuate_account",
    "ProxyManager", "start_local_web_dashboard",
    "parse_user_file", "run_batch_checker", "run_batch_inspector",
    "run_account_switcher", "run_batch_boost", "run_batch_change_passwords",
    "export_categorized_accounts", "run_batch_migrate_accounts",
    "query_accounts", "execute_account_query", "find_all_available_account_data"
]
